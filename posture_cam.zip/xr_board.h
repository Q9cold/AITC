#pragma once

#include <string.h>
#include "math.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/i2c.h"
#include "driver/spi_master.h"
#include "driver/ledc.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_lcd_types.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "esp_camera.h"

#ifdef __cplusplus
extern "C"
{
#endif

/******************************************************************************/
/***************************  I2C ↓ *******************************************/
#define BSP_I2C_SDA (GPIO_NUM_1) // SDA引脚
#define BSP_I2C_SCL (GPIO_NUM_2) // SCL引脚

#define BSP_I2C_NUM (0)        // I2C外设
#define BSP_I2C_FREQ_HZ 100000 // 100kHz

/******************************************************************************/
/***************************   I2S  ↓    **************************************/

/* Example configurations */
#define EXAMPLE_RECV_BUF_SIZE (2400)
#define EXAMPLE_SAMPLE_RATE (16000)
#define EXAMPLE_MCLK_MULTIPLE (384) // If not using 24-bit data width, 256 should be enough
#define EXAMPLE_MCLK_FREQ_HZ (EXAMPLE_SAMPLE_RATE * EXAMPLE_MCLK_MULTIPLE)
#define EXAMPLE_VOICE_VOLUME (70)

/* I2S port and GPIOs */
#define I2S_NUM (0)
#define I2S_MCK_IO (GPIO_NUM_38)
#define I2S_BCK_IO (GPIO_NUM_14)
#define I2S_WS_IO (GPIO_NUM_13)
#define I2S_DO_IO (GPIO_NUM_45)
#define I2S_DI_IO (GPIO_NUM_12)

/***********************************************************/
/****************    LCD显示屏 ↓   *************************/
#define BSP_LCD_PIXEL_CLOCK_HZ (80 * 1000 * 1000)
#define BSP_LCD_SPI_NUM (SPI3_HOST)
#define LCD_CMD_BITS (8)
#define LCD_PARAM_BITS (8)
#define BSP_LCD_BITS_PER_PIXEL (16)
#define LCD_LEDC_CH LEDC_CHANNEL_0

#define BSP_LCD_H_RES (320)
#define BSP_LCD_V_RES (240)

#define BSP_LCD_SPI_MOSI (GPIO_NUM_42)
#define BSP_LCD_SPI_CLK (GPIO_NUM_41)
#define BSP_LCD_SPI_CS (GPIO_NUM_11)
#define BSP_LCD_DC (GPIO_NUM_40)
#define BSP_LCD_RST (GPIO_NUM_NC)
#define BSP_LCD_BACKLIGHT (GPIO_NUM_39)

    esp_err_t bsp_display_brightness_init(void);
    esp_err_t bsp_display_brightness_set(int brightness_percent);
    esp_err_t bsp_display_backlight_off(void);
    esp_err_t bsp_display_backlight_on(void);
    esp_err_t bsp_lcd_init(void);
    void lcd_set_color(uint16_t color);
    void lcd_draw_pictrue(int x_start, int y_start, int x_end, int y_end, const unsigned char *gImage);
    void lcd_draw_bitmap(int x_start, int y_start, int x_end, int y_end, const void *color_data);
/***************    LCD显示屏 ↑   *************************/
/***********************************************************/

/***********************************************************/
/****************    摄像头 ↓   ****************************/
#define CAMERA_MODULE_NAME "ESP32-S3"

#define CAMERA_PIN_PWDN 9
#define CAMERA_PIN_RESET -1
#define CAMERA_PIN_XCLK 8
#define CAMERA_PIN_SIOD 1
#define CAMERA_PIN_SIOC 2

#define CAMERA_PIN_D7 3
#define CAMERA_PIN_D6 18
#define CAMERA_PIN_D5 17
#define CAMERA_PIN_D4 15
#define CAMERA_PIN_D3 6
#define CAMERA_PIN_D2 4
#define CAMERA_PIN_D1 5
#define CAMERA_PIN_D0 7
#define CAMERA_PIN_VSYNC 10
#define CAMERA_PIN_HREF 46
#define CAMERA_PIN_PCLK 16

#define XCLK_FREQ_HZ 12000000

    void bsp_camera_init(void);
    /********************    摄像头 ↑   *************************/
    /***********************************************************/

#ifdef __cplusplus
}
#endif