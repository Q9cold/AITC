#pragma once

#include <list>
#include "dl_detect_define.hpp"
#include "esp_camera.h"

/**
 * @brief Draw detection result on RGB565 image.
 * 
 * @param image_ptr     image
 * @param image_height  height of image
 * @param image_width   width of image
 * @param results       detection results
 */
void draw_detection_result(uint16_t *image_ptr, int image_height, int image_width, std::list<dl::detect::result_t> &results);

/**
 * @brief Draw detection result on RGB888 image.
 * 
 * @param image_ptr     image
 * @param image_height  height of image
 * @param image_width   width of image
 * @param results       detection results
 */

void draw_detection_result(uint8_t *image_ptr, int image_height, int image_width, std::list<dl::detect::result_t> &results);

/**
 * @brief Print detection result in terminal
 * 
 * @param results detection results
 */
void print_detection_result(std::list<dl::detect::result_t> &results);

/**
 * @brief Decode fb , 
 *        - if fb->format == PIXFORMAT_RGB565, then return fb->buf
 *        - else, then return a new memory with RGB888, don't forget to free it
 * 
 * @param fb 
 */
void *app_camera_decode(camera_fb_t *fb);

/**
 * @brief 在图像上绘制距离信息（RGB565）
 * 
 * @param image_ptr     图像数据
 * @param image_height  图像高度
 * @param image_width   图像宽度
 * @param distance_cm   距离（厘米）
 * @param is_safe       是否安全距离
 */
void draw_distance_info(uint16_t *image_ptr, int image_height, int image_width, float distance_cm, bool is_safe);

/**
 * @brief 在图像上绘制距离信息（RGB888）
 * 
 * @param image_ptr     图像数据
 * @param image_height  图像高度
 * @param image_width   图像宽度
 * @param distance_cm   距离（厘米）
 * @param is_safe       是否安全距离
 */
void draw_distance_info(uint8_t *image_ptr, int image_height, int image_width, float distance_cm, bool is_safe);

/**
 * @brief 在RGB565图像上绘制警告横幅
 *
 * @param image_ptr     图像数据
 * @param image_height  图像高度
 * @param image_width   图像宽度
 * @param message       警告消息
 */
void draw_warning_banner(uint16_t *image_ptr, int image_height, int image_width, const char *message);

