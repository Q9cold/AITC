#include <stdio.h>
#include "xr_board.h"
#include "yingwu.h"
#include "xr_ai_process.hpp"

#include "app_wifi.h"
#include "app_httpd.hpp"
#include "app_mdns.h"
#include "app_udp_landmark.h"

#define PRESS_IP "10.45.232.45"   // PressPosture 的 IP

extern "C" void app_main(void)
{
    app_wifi_main();

    udp_landmark_init(PRESS_IP);                   // UDP 发送面部关键点给 PressPosture

    vTaskDelay(500 / portTICK_PERIOD_MS);            // 延时500毫秒
    bsp_camera_init();                               // 摄像头初始化
    app_mdns_main();
    app_camera_ai_lcd();
}