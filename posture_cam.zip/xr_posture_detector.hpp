#pragma once

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 坐姿检测器初始化
 * @param ipd_cm           用户瞳距（cm），成人默认 6.3
 * @param cam_height_cm    摄像头距桌面高度（cm），由支架决定
 * @param cam_tilt_deg     摄像头仰角（度，正值 = 抬头），由支架决定
 * @param safe_distance_cm 水平安全距离阈值（cm）
 */
void posture_detector_init(float ipd_cm, float cam_height_cm,
                           float cam_tilt_deg, float safe_distance_cm);

/**
 * @brief 计算人眼到桌面的空间坐标（每帧调用）
 *
 * 第一步：用瞳距求 3D 直线距离 R
 *   R = (focal_length_px × ipd_cm) / pixel_ipd
 *
 * 第二步：用眼位置求视线仰角 α
 *   α = tilt + atan((center_y - eye_y) / focal_length_px)
 *
 * 第三步：三角分解求水平距离
 *   D = R × cos(α)     ← 人到摄像头的水平距离（判断依据）
 *
 * @param pixel_ipd       双眼像素间距
 * @param eye_y           双眼中心 Y 坐标（像素）
 * @param image_height    图像高度（像素）
 * @param focal_length_px 焦距（像素单位）
 * @return 水平距离 D（cm）
 */
float posture_detector_calc_distance(float pixel_ipd, int eye_y,
                                      int image_height, float focal_length_px);

void posture_detector_set_safe_distance(float distance_cm);
float posture_detector_get_safe_distance(void);
void posture_detector_set_ipd(float ipd_cm);

bool posture_detector_is_safe(void);
float posture_detector_get_current_distance(void);
float posture_detector_get_3d_distance(void);  // 3D直线距离 R（摄像头→人眼）
float posture_detector_get_eye_height(void);   // 眼距桌面高度 H_eye
bool posture_detector_is_alerting(void);
void posture_detector_clear_alert(void);
void posture_detector_set_alert_enabled(bool enabled);
bool posture_detector_get_alert_enabled(void);

#ifdef __cplusplus
}
#endif
