#include "app_udp_landmark.h"
#include "facial_landmark_logger.hpp"
#include "esp_log.h"
#include "lwip/sockets.h"
#include <string.h>

static const char *TAG = "udp_landmark";
static int  s_sock = -1;
static char s_press_ip[32] = {0};

void udp_landmark_init(const char *press_ip)
{
    if (!press_ip || !press_ip[0]) {
        ESP_LOGE(TAG, "need press IP");
        return;
    }
    strncpy(s_press_ip, press_ip, sizeof(s_press_ip) - 1);

    s_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (s_sock < 0) {
        ESP_LOGE(TAG, "socket fail");
        return;
    }
    ESP_LOGI(TAG, "ready -> %s:%d", s_press_ip, LANDMARK_PORT);
}

void udp_landmark_send(const float *landmarks)
{
    if (s_sock < 0 || !landmarks || !s_press_ip[0]) return;

    struct sockaddr_in dest = {
        .sin_family = AF_INET,
        .sin_port   = htons(LANDMARK_PORT),
    };
    inet_aton(s_press_ip, &dest.sin_addr);

    sendto(s_sock, landmarks, 15 * sizeof(float), 0,
           (struct sockaddr *)&dest, sizeof(dest));
}

void udp_landmark_send_latest(void)
{
    const facial_landmark_data_t *data = facial_landmark_data_get_latest();
    if (!data || !data->face_detected) return;

    float landmarks[15];
    const keypoint_3d_t *k = data->kp3d;
    landmarks[0]  = k[3].X;   // right_eye
    landmarks[1]  = k[3].Y;
    landmarks[2]  = k[3].Z;
    landmarks[3]  = k[1].X;   // mouth_left
    landmarks[4]  = k[1].Y;
    landmarks[5]  = k[1].Z;
    landmarks[6]  = k[2].X;   // nose
    landmarks[7]  = k[2].Y;
    landmarks[8]  = k[2].Z;
    landmarks[9]  = k[0].X;   // left_eye
    landmarks[10] = k[0].Y;
    landmarks[11] = k[0].Z;
    landmarks[12] = k[4].X;   // mouth_right
    landmarks[13] = k[4].Y;
    landmarks[14] = k[4].Z;

    udp_landmark_send(landmarks);
}