#pragma once

#include <stdint.h>
#include <stdbool.h>
#include <sys/time.h>
#include <list>
#include "dl_detect_define.hpp"

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// 单个关键点的3D世界坐标（桌面坐标系）
//   X: 左右, 0=摄像头正前方, +右 -左 (cm)
//   Y: 高度, 距桌面 (cm)
//   Z: 水平距离, 从摄像头向前 (cm)
// ============================================================
typedef struct {
    float X, Y, Z;
} keypoint_3d_t;

// ============================================================
// 五官关键点数据（线程安全共享数据结构）
// ============================================================
typedef struct {
    struct timeval timestamp;       // 帧时间戳（从开机算起）
    uint32_t frame_count;           // 帧序号
    bool face_detected;             // 是否检测到人脸
    int keypoints[10];              // 原始2D像素坐标: 左眼/左嘴角/鼻子/右眼/右嘴角
    keypoint_3d_t kp3d[5];          // 5个关键点的3D世界坐标 (Y=距桌面高度)
} facial_landmark_data_t;

// ============================================================
// API
// ============================================================

void facial_landmark_data_init(void);

/** 更新人脸关键点，同时将2D像素坐标转为3D世界坐标 */
void facial_landmark_data_update(struct timeval timestamp,
    const std::list<dl::detect::result_t> &results,
    float R_cm, float tilt_rad, float focal_px, float cam_height_cm);

void facial_landmark_data_clear(void);

const facial_landmark_data_t* facial_landmark_data_get_latest(void);

#ifdef __cplusplus
}
#endif
