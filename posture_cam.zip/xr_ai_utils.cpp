#include "xr_ai_utils.hpp"

#include "esp_log.h"
#include "esp_camera.h"

#include "dl_image.hpp"

static const char *TAG = "ai_utils";

// +-------+--------------------+----------+
// |       |       RGB565       |  RGB888  |
// +=======+====================+==========+
// |  Red  | 0b0000000011111000 | 0x0000FF |
// +-------+--------------------+----------+
// | Green | 0b1110000000000111 | 0x00FF00 |
// +-------+--------------------+----------+
// |  Blue | 0b0001111100000000 | 0xFF0000 |
// +-------+--------------------+----------+

void draw_detection_result(uint16_t *image_ptr, int image_height, int image_width, std::list<dl::detect::result_t> &results)
{
    int i = 0;
    for (std::list<dl::detect::result_t>::iterator prediction = results.begin(); prediction != results.end(); prediction++, i++)
    {
        dl::image::draw_hollow_rectangle(image_ptr, image_height, image_width,
                                         DL_MAX(prediction->box[0], 0),
                                         DL_MAX(prediction->box[1], 0),
                                         DL_MAX(prediction->box[2], 0),
                                         DL_MAX(prediction->box[3], 0),
                                         0b1110000000000111);

        if (prediction->keypoint.size() == 10)
        {
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[0], 0), DL_MAX(prediction->keypoint[1], 0), 4, 0b0000000011111000); // left eye
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[2], 0), DL_MAX(prediction->keypoint[3], 0), 4, 0b0000000011111000); // mouth left corner
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[4], 0), DL_MAX(prediction->keypoint[5], 0), 4, 0b1110000000000111); // nose
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[6], 0), DL_MAX(prediction->keypoint[7], 0), 4, 0b0001111100000000); // right eye
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[8], 0), DL_MAX(prediction->keypoint[9], 0), 4, 0b0001111100000000); // mouth right corner
        }
    }
}

void draw_detection_result(uint8_t *image_ptr, int image_height, int image_width, std::list<dl::detect::result_t> &results)
{
    int i = 0;
    for (std::list<dl::detect::result_t>::iterator prediction = results.begin(); prediction != results.end(); prediction++, i++)
    {
        dl::image::draw_hollow_rectangle(image_ptr, image_height, image_width,
                                         DL_MAX(prediction->box[0], 0),
                                         DL_MAX(prediction->box[1], 0),
                                         DL_MAX(prediction->box[2], 0),
                                         DL_MAX(prediction->box[3], 0),
                                         0x00FF00);

        if (prediction->keypoint.size() == 10)
        {
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[0], 0), DL_MAX(prediction->keypoint[1], 0), 4, 0x0000FF); // left eye
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[2], 0), DL_MAX(prediction->keypoint[3], 0), 4, 0x0000FF); // mouth left corner
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[4], 0), DL_MAX(prediction->keypoint[5], 0), 4, 0x00FF00); // nose
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[6], 0), DL_MAX(prediction->keypoint[7], 0), 4, 0xFF0000); // right eye
            dl::image::draw_point(image_ptr, image_height, image_width, DL_MAX(prediction->keypoint[8], 0), DL_MAX(prediction->keypoint[9], 0), 4, 0xFF0000); // mouth right corner
        }
    }
}

void print_detection_result(std::list<dl::detect::result_t> &results)
{
    int i = 0;
    for (std::list<dl::detect::result_t>::iterator prediction = results.begin(); prediction != results.end(); prediction++, i++)
    {
        ESP_LOGI("detection_result", "[%2d]: (%3d, %3d, %3d, %3d)", i, prediction->box[0], prediction->box[1], prediction->box[2], prediction->box[3]);

        if (prediction->keypoint.size() == 10)
        {
            ESP_LOGI("detection_result", "      left eye: (%3d, %3d), right eye: (%3d, %3d), nose: (%3d, %3d), mouth left: (%3d, %3d), mouth right: (%3d, %3d)",
                     prediction->keypoint[0], prediction->keypoint[1],  // left eye
                     prediction->keypoint[6], prediction->keypoint[7],  // right eye
                     prediction->keypoint[4], prediction->keypoint[5],  // nose
                     prediction->keypoint[2], prediction->keypoint[3],  // mouth left corner
                     prediction->keypoint[8], prediction->keypoint[9]); // mouth right corner
        }
    }
}

void *app_camera_decode(camera_fb_t *fb)
{
    if (fb->format == PIXFORMAT_RGB565)
    {
        return (void *)fb->buf;
    }
    else
    {
        uint8_t *image_ptr = (uint8_t *)malloc(fb->height * fb->width * 3 * sizeof(uint8_t));
        if (image_ptr)
        {
            if (fmt2rgb888(fb->buf, fb->len, fb->format, image_ptr))
            {
                return (void *)image_ptr;
            }
            else
            {
                ESP_LOGE(TAG, "fmt2rgb888 failed");
                dl::tool::free_aligned(image_ptr);
            }
        }
        else
            {
                ESP_LOGE(TAG, "malloc memory for image rgb888 failed");
            }
        }
        return NULL;
}

// ============================================================
// 坐姿距离信息绘制函数
// ============================================================

// RGB565 颜色定义
#define RGB565_RED    0xF800
#define RGB565_GREEN  0x07E0
#define RGB565_BLUE   0x001F
#define RGB565_WHITE  0xFFFF
#define RGB565_YELLOW 0xFFE0

/**
 * @brief 在RGB565图像上绘制字符（简单实现，使用dl_image库的绘制点功能拼凑简单文本）
 *        由于dl_image没有字符绘制功能，我们用像素级操作画简单的数字和文字
 *        这里使用fb_gfx如果可用，否则用简单的像素绘制
 */
static void draw_char_rgb565(uint16_t *image, int h, int w, int x, int y, char c, uint16_t color)
{
        // 简单的5x7点阵字符，仅实现数字0-9、小数点、cm、空格等
        // 使用dl::image::draw_point来绘制点阵
        // 这里为了简化，使用fb_gfx提供的字符串打印
        // 但如果fb_gfx不可用，跳过字符绘制
        // 实际项目中可以接入fb_gfx或自定义点阵字体
        // 这里留空，后续可以完善
        (void)image;
        (void)h;
        (void)w;
        (void)x;
        (void)y;
        (void)c;
        (void)color;
}

/**
 * @brief RGB565 绘制简单字符串（通过像素操作绘制大号数字）
 *        使用简单的矩形块组合模拟数字显示
 */
static void draw_big_digit_rgb565(uint16_t *image, int h, int w, int start_x, int start_y, 
                                       char digit, int size, uint16_t color)
{
        // 简单数字的7段显示模式，size控制大小
        // 因为时间关系，使用dl_image::draw_filled_rectangle画大号数字
        // 这里使用fb_gfx提供的功能
}

void draw_distance_info(uint16_t *image_ptr, int image_height, int image_width, 
                             float distance_cm, bool is_safe)
{
        if (!image_ptr || image_height <= 0 || image_width <= 0 || distance_cm < 0) {
            return;
        }

                uint16_t color = is_safe ? RGB565_GREEN : RGB565_RED;
    
        // 在图像顶部绘制距离信息条
        int bar_height = 20;
        int bar_y = 0;
    
        // 绘制半透明背景条（用横线填充模拟）
        for (int y = bar_y; y < bar_y + bar_height; y++) {
            for (int x = 0; x < image_width; x++) {
                // 简单混合：暗色半透明背景
                uint16_t pixel = image_ptr[y * image_width + x];
                // 降低亮度模拟半透明
                uint16_t r = (pixel >> 11) & 0x1F;
                uint16_t g = (pixel >> 5) & 0x3F;
                uint16_t b = pixel & 0x1F;
                r = r > 5 ? r - 5 : 0;
                g = g > 10 ? g - 10 : 0;
                b = b > 5 ? b - 5 : 0;
                image_ptr[y * image_width + x] = (r << 11) | (g << 5) | b;
            }
        }
    
        // 如果是在LCD上，可以使用fb_gfx打印文字
        // 这里我们使用dl::image的绘图功能绘制简单的距离指示
    
        // 在左上角画一个小矩形指示状态（代替圆点，因为dl::image没有draw_filled_circle）
        int indicator_x = 6;
        int indicator_y = bar_height / 2 - 3;
        int indicator_size = 6;
        for (int dy = 0; dy < indicator_size && indicator_y + dy < image_height; dy++) {
            for (int dx = 0; dx < indicator_size && indicator_x + dx < image_width; dx++) {
                image_ptr[(indicator_y + dy) * image_width + (indicator_x + dx)] = color;
            }
        }
    
        // 在中间画一条参考线（安全距离线）
        // 在图像右侧绘制距离刻度
        int scale_x = image_width - 8;
        for (int y = bar_height; y < image_height; y += 4) {
            // 画一个简易的刻度条
            uint16_t scale_color = RGB565_YELLOW;
            if (y < image_height / 3) scale_color = RGB565_GREEN;
            else if (y < image_height * 2 / 3) scale_color = RGB565_YELLOW;
            else scale_color = RGB565_RED;
        
            dl::image::draw_point(image_ptr, image_height, image_width, 
                                  scale_x, y, 2, scale_color);
        }
    
        ESP_LOGD(TAG, "Distance drawn: %.1fcm, safe=%d", distance_cm, is_safe);
}

void draw_distance_info(uint8_t *image_ptr, int image_height, int image_width, 
                             float distance_cm, bool is_safe)
{
        if (!image_ptr || image_height <= 0 || image_width <= 0 || distance_cm < 0) {
            return;
        }
    
        uint8_t r = is_safe ? 0x00 : 0xFF;
        uint8_t g = is_safe ? 0xFF : 0x00;
        uint8_t b = 0x00;
    
        // 在RGB888图像顶部绘制信息
        int bar_height = 20;
        for (int y = 0; y < bar_height && y < image_height; y++) {
            for (int x = 0; x < image_width; x++) {
                int idx = (y * image_width + x) * 3;
                // 背景变暗
                image_ptr[idx]     = image_ptr[idx] / 2;
                image_ptr[idx + 1] = image_ptr[idx + 1] / 2;
                image_ptr[idx + 2] = image_ptr[idx + 2] / 2;
            }
        }
    
        // 画状态指示点
        int indicator_x = 10;
        int indicator_y = bar_height / 2;
        for (int dy = -4; dy <= 4; dy++) {
            for (int dx = -4; dx <= 4; dx++) {
                if (dx*dx + dy*dy <= 16) {
                    int px = indicator_x + dx;
                    int py = indicator_y + dy;
                    if (px >= 0 && px < image_width && py >= 0 && py < image_height) {
                        int idx = (py * image_width + px) * 3;
                        image_ptr[idx]     = r;
                        image_ptr[idx + 1] = g;
                        image_ptr[idx + 2] = b;
                    }
                }
            }
        }
}

void draw_warning_banner(uint16_t *image_ptr, int image_height, int image_width, 
                              const char *message)
{
        if (!image_ptr || !message || image_height <= 0 || image_width <= 0) {
            return;
        }
    
        // 在图像中央绘制红色警告横幅
        int banner_height = 30;
        int banner_y = image_height / 2 - banner_height / 2;
        int banner_x = image_width / 4;
        int banner_w = image_width / 2;
    
        // 红色横幅背景
        for (int y = banner_y; y < banner_y + banner_height && y < image_height; y++) {
            for (int x = banner_x; x < banner_x + banner_w && x < image_width; x++) {
                image_ptr[y * image_width + x] = RGB565_RED;
            }
        }
    
        // 横幅边框 - 白色
        for (int x = banner_x; x < banner_x + banner_w && x < image_width; x++) {
            if (banner_y > 0) 
                image_ptr[banner_y * image_width + x] = RGB565_WHITE;
            if (banner_y + banner_height - 1 < image_height)
                image_ptr[(banner_y + banner_height - 1) * image_width + x] = RGB565_WHITE;
        }
        for (int y = banner_y; y < banner_y + banner_height && y < image_height; y++) {
            if (banner_x > 0)
                image_ptr[y * image_width + banner_x] = RGB565_WHITE;
            if (banner_x + banner_w - 1 < image_width)
                image_ptr[y * image_width + banner_x + banner_w - 1] = RGB565_WHITE;
        }
    
        ESP_LOGI(TAG, "Warning: %s", message);
}