#include "xr_posture_detector.hpp"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include <math.h>

static const char *TAG = "posture_detector";

// ============================================================
// 常量
// ============================================================
#define ALERT_GPIO            GPIO_NUM_21
#define ALERT_ACTIVE_LEVEL    1
#define ALERT_THRESHOLD_COUNT 3
#define DISTANCE_MIN_CM       5.0f
#define DISTANCE_MAX_CM       200.0f
#define DEFAULT_IPD_CM        6.3f

// ============================================================
// 状态
// ============================================================
static struct {
    float ipd_cm;              // 用户瞳距
    float cam_height_cm;       // 摄像头距桌面高度（支架固定）
    float cam_tilt_deg;        // 摄像头仰角（支架固定）
    float safe_distance_cm;    // 水平安全距离阈值
    float current_distance_cm;
    float current_3d_distance_cm; // 3D直线距离 R（摄像头→人眼）
    float current_eye_height_cm;  // 眼距桌面高度 H_eye
    bool  is_safe;
    bool  alert_enabled;
    bool  is_alerting;
    int   alert_count;
} s_ctx;

// ============================================================
// GPIO
// ============================================================
static void gpio_alert_init(void)
{
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << ALERT_GPIO),
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    gpio_config(&io_conf);
    gpio_set_level(ALERT_GPIO, 0);
}

static void gpio_alert_set(bool active)
{
    gpio_set_level(ALERT_GPIO, active ? ALERT_ACTIVE_LEVEL
                                      : (ALERT_ACTIVE_LEVEL ^ 1));
}

static void gpio_alert_task(void *arg)
{
    bool last_state = false;
    while (1) {
        bool should_alert = s_ctx.is_alerting && s_ctx.alert_enabled;
        if (should_alert != last_state) {
            gpio_alert_set(should_alert);
            last_state = should_alert;
            ESP_LOGI(TAG, "GPIO alert %s", should_alert ? "ON" : "OFF");
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

// ============================================================
// 公开 API
// ============================================================

void posture_detector_init(float ipd_cm, float cam_height_cm,
                           float cam_tilt_deg, float safe_distance_cm)
{
    s_ctx.ipd_cm           = ipd_cm;
    s_ctx.cam_height_cm    = cam_height_cm;
    s_ctx.cam_tilt_deg     = cam_tilt_deg;
    s_ctx.safe_distance_cm = safe_distance_cm;
    s_ctx.current_distance_cm = -1.0f;
    s_ctx.is_safe     = true;
    s_ctx.is_alerting = false;
    s_ctx.alert_count = 0;

    gpio_alert_init();
    xTaskCreate(gpio_alert_task, "alert_gpio", 2048, NULL, 2, NULL);

    ESP_LOGI(TAG, "Init: IPD=%.1f H_cam=%.1f tilt=%.1f safe=%.1f",
             ipd_cm, cam_height_cm, cam_tilt_deg, safe_distance_cm);
}

float posture_detector_calc_distance(float pixel_ipd, int eye_y,
                                      int image_height, float focal_length_px)
{
    if (pixel_ipd <= 0.0f || focal_length_px <= 0.0f) {
        return s_ctx.current_distance_cm;
    }

    // ── 第一步：瞳距 → 人眼到摄像头的 3D 直线距离 R ──
    float R = (focal_length_px * s_ctx.ipd_cm) / pixel_ipd;

    // ── 第二步：眼位置 → 人眼相对水平面的仰角 α ──
    float center_y   = image_height / 2.0f;
    float pixel_offset = center_y - (float)eye_y;
    float angle_from_axis_rad = atanf(pixel_offset / focal_length_px);
    float tilt_rad = s_ctx.cam_tilt_deg * (float)M_PI / 180.0f;
    float alpha_rad = tilt_rad + angle_from_axis_rad;
    // α = 摄像头仰角 + 眼偏离光轴的角度

    // ── 第三步：三角分解 → 水平距离 D ──
    // D = R × cos(α)
    float D;
    if (alpha_rad <= 0.0f) {
        D = DISTANCE_MAX_CM;  // 眼低于水平面（极少见），钳位到最大
    } else {
        D = R * cosf(alpha_rad);
    }

    // 钳位
    if (D < DISTANCE_MIN_CM) D = DISTANCE_MIN_CM;
    if (D > DISTANCE_MAX_CM) D = DISTANCE_MAX_CM;

    s_ctx.current_distance_cm = D;
    s_ctx.current_3d_distance_cm = R;

    // 眼距桌面高度
    float H_eye = s_ctx.cam_height_cm + R * sinf(alpha_rad);
    s_ctx.current_eye_height_cm = H_eye;

    ESP_LOGD(TAG, "IPD=%.1fpx R=%.1f α=%.1f° D=%.1f H_eye=%.1f",
             pixel_ipd, R, alpha_rad * 180.0f / (float)M_PI, D, H_eye);

    // ── 报警判断 ──
    if (D < s_ctx.safe_distance_cm) {
        s_ctx.alert_count++;
        if (s_ctx.alert_count >= ALERT_THRESHOLD_COUNT) {
            s_ctx.is_safe     = false;
            s_ctx.is_alerting = true;
        }
    } else {
        s_ctx.alert_count   = 0;
        s_ctx.is_safe       = true;
        s_ctx.is_alerting   = false;
    }

    return D;
}

void posture_detector_set_safe_distance(float d) { s_ctx.safe_distance_cm = d; }
float posture_detector_get_safe_distance(void)   { return s_ctx.safe_distance_cm; }
void posture_detector_set_ipd(float ipd_cm)      { s_ctx.ipd_cm = ipd_cm; }
bool posture_detector_is_safe(void)              { return s_ctx.is_safe; }
float posture_detector_get_current_distance(void) { return s_ctx.current_distance_cm; }
float posture_detector_get_3d_distance(void)      { return s_ctx.current_3d_distance_cm; }
float posture_detector_get_eye_height(void)       { return s_ctx.current_eye_height_cm; }
bool posture_detector_is_alerting(void)           { return s_ctx.is_alerting; }

void posture_detector_clear_alert(void)
{
    s_ctx.is_alerting = false;
    s_ctx.alert_count = 0;
    s_ctx.is_safe     = true;
    gpio_alert_set(false);
}

void posture_detector_set_alert_enabled(bool enabled)
{
    s_ctx.alert_enabled = enabled;
    if (!enabled) gpio_alert_set(false);
}

bool posture_detector_get_alert_enabled(void)
{
    return s_ctx.alert_enabled;
}
