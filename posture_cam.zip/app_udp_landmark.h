#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define LANDMARK_PORT 8890

void udp_landmark_init(const char *press_ip);
void udp_landmark_send(const float *landmarks);   // 15 floats, 60 bytes
void udp_landmark_send_latest(void);              // 从共享数据读取并发送

#ifdef __cplusplus
}
#endif