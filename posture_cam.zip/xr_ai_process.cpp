#include "xr_ai_process.hpp"
#include "esp_log.h"
#include "esp_camera.h"
#include "esp_timer.h"
#include <math.h>
#include "dl_image.hpp"
#include "human_face_detect_msr01.hpp"
#include "human_face_detect_mnp01.hpp"
#include "xr_ai_utils.hpp"
#include "esp_camera.h"
#include "xr_board.h"

#include "app_httpd.hpp"
#include "xr_posture_detector.hpp"
#include "app_udp_landmark.h"
#include "facial_landmark_logger.hpp"

static const char *TAG = "posture_detector";

// 发送频率控制：UDP 面部关键点最小发送间隔（毫秒）
#define UDP_SEND_INTERVAL_MS  500

static QueueHandle_t xQueueLCDFrame = NULL;
static QueueHandle_t xQueueAIFrame = NULL;

static bool gEvent = true;
static bool gReturnFB = true;

// GC2145 QVGA(320×240) — 焦距（像素单位）
// 标定公式: FOCAL_LENGTH_PX = ipd_px × 真实距离(cm) / 真实瞳距(cm)
#define FOCAL_LENGTH_PX    321.4f   // 标定后修改此值

// 摄像头支架参数（3D 打印固定）
#define CAM_HEIGHT_CM       31.5f   // 摄像头距桌面高度
#define CAM_TILT_DEG        0.0f    // 仰角（正值 = 抬头）

// 坐姿检测参数
#define DEFAULT_IPD_CM      6.3f     // 成人平均瞳距（cm）
#define SAFE_DISTANCE_CM    40.0f    // 水平安全距离阈值（cm）

// AI处理任务（集成坐姿检测）
static void task_process_ai(void *arg)
{
    camera_fb_t *frame = NULL;
    HumanFaceDetectMSR01 detector(0.3F, 0.3F, 10, 0.3F);
    HumanFaceDetectMNP01 detector2(0.4F, 0.3F, 10);
    int64_t last_udp_send_us = 0;

    while (true)
    {
        if (gEvent)
        {
            if (xQueueReceive(xQueueAIFrame, &frame, portMAX_DELAY))
            {
                // RGB565 直接用于人脸检测
                std::list<dl::detect::result_t> &detect_candidates = detector.infer((uint16_t *)frame->buf, {(int)frame->height, (int)frame->width, 3});
                std::list<dl::detect::result_t> &detect_results = detector2.infer((uint16_t *)frame->buf, {(int)frame->height, (int)frame->width, 3}, detect_candidates);

                if (detect_results.size() > 0)
                {
                    // 绘制人脸检测框
                    draw_detection_result((uint16_t *)frame->buf, frame->height, frame->width, detect_results);
                    print_detection_result(detect_results);

                    // ---- 坐姿距离检测 ----
                    auto &first_face = detect_results.front();
                    if (first_face.keypoint.size() >= 10) {
                        // 瞳距计算：双眼像素间距
                        float left_eye_x  = first_face.keypoint[0];
                        float left_eye_y  = first_face.keypoint[1];
                        float right_eye_x = first_face.keypoint[6];
                        float right_eye_y = first_face.keypoint[7];

                        float pixel_ipd = sqrtf(
                            (left_eye_x - right_eye_x) * (left_eye_x - right_eye_x) +
                            (left_eye_y - right_eye_y) * (left_eye_y - right_eye_y)
                        );
                        int eye_center_y = (int)(left_eye_y + right_eye_y) / 2;

                        float distance = posture_detector_calc_distance(
                            pixel_ipd, eye_center_y,
                            frame->height, FOCAL_LENGTH_PX
                        );

                        bool is_safe = posture_detector_is_safe();
                        bool is_alerting = posture_detector_is_alerting();
                        float safe_dist = posture_detector_get_safe_distance();

                        // 串口输出坐姿检测参数
                        ESP_LOGI(TAG, "posture_distance = %.1f", distance);
                        ESP_LOGI(TAG, "posture_is_safe = %d", is_safe);
                        ESP_LOGI(TAG, "posture_is_alerting = %d", is_alerting);
                        ESP_LOGI(TAG, "posture_safe_distance = %.1f", safe_dist);

                        // 在RGB565图像上绘制距离
                        draw_distance_info((uint16_t *)frame->buf, frame->height, frame->width, distance, is_safe);

                        if (!is_safe) {
                            draw_warning_banner((uint16_t *)frame->buf, frame->height, frame->width, "TOO CLOSE!");
                        }

                        // 存储五官关键点数据 + 转3D世界坐标（供 HTTP /facial_landmarks 查询）
                        float R = posture_detector_get_3d_distance();
                        float tilt_rad = CAM_TILT_DEG * M_PI / 180.0f;
                        facial_landmark_data_update(frame->timestamp, detect_results,
                            R, tilt_rad, FOCAL_LENGTH_PX, CAM_HEIGHT_CM);

                        // 通过 UDP 发送面部关键点3D坐标给 PressPosture（限流）
                        int64_t now_us = esp_timer_get_time();
                        if (now_us - last_udp_send_us >= UDP_SEND_INTERVAL_MS * 1000) {
                            udp_landmark_send_latest();
                            last_udp_send_us = now_us;
                        }
                    }
                }
                else
                {
                    // 未检测到人脸
                    facial_landmark_data_clear();
                    float last_distance = posture_detector_get_current_distance();
                    if (last_distance > 0) {
                        ESP_LOGI(TAG, "posture_distance = %.1f (no face)", last_distance);
                    }
                }

                // 返回帧给stream
                if (gReturnFB)
                {
                    esp_camera_fb_return(frame);
                }
                else
                {
                    free(frame);
                }
            }
        }
    }
}

// 摄像头处理任务
static void task_process_camera(void *arg)
{
    while (true)
    {
        camera_fb_t *frame = esp_camera_fb_get();
        if (frame)
        {
            xQueueSend(xQueueAIFrame, &frame, portMAX_DELAY);
        }
        // 防止watchdog，每次取帧后让出CPU
        vTaskDelay(1);
    }
}

// 初始化
void app_camera_ai_lcd(void)
{
    xQueueLCDFrame = xQueueCreate(2, sizeof(camera_fb_t *));
    xQueueAIFrame = xQueueCreate(2, sizeof(camera_fb_t *));

    // 初始化坐姿检测器（瞳距法 + 三角分解求水平距离）
    posture_detector_init(DEFAULT_IPD_CM, CAM_HEIGHT_CM, CAM_TILT_DEG,
                          SAFE_DISTANCE_CM);
    ESP_LOGI(TAG, "Posture detector: IPD=%.1f H_cam=%.0f tilt=%.0f safe=%.0f",
             DEFAULT_IPD_CM, CAM_HEIGHT_CM, CAM_TILT_DEG, SAFE_DISTANCE_CM);

    // 初始化五官关键点共享数据
    facial_landmark_data_init();

    xTaskCreatePinnedToCore(task_process_camera, "task_process_camera", 3 * 1024, NULL, 5, NULL, 1);
    xTaskCreatePinnedToCore(task_process_ai, "task_process_ai", 8 * 1024, NULL, 5, NULL, 1);
    register_httpd(xQueueAIFrame, NULL, true);
}