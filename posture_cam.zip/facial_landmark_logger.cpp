#include "facial_landmark_logger.hpp"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <cmath>
#include <cstring>

static const char *TAG = "facial_landmark";

// ============================================================
// 共享数据（FreeRTOS mutex 保护）
// ============================================================
static facial_landmark_data_t s_data;
static SemaphoreHandle_t s_mutex = NULL;

// 图像中心（QVGA 320×240）
#define CX  160.0f
#define CY  120.0f

// ============================================================
// 初始化
// ============================================================
void facial_landmark_data_init(void)
{
    s_mutex = xSemaphoreCreateMutex();
    if (s_mutex == NULL) {
        ESP_LOGE(TAG, "Failed to create mutex");
        return;
    }
    memset(&s_data, 0, sizeof(s_data));
    s_data.face_detected = false;
    ESP_LOGI(TAG, "Initialized");
}

// ============================================================
// 单个像素 → 3D世界坐标（6步法）
//
// 坐标系: X=左右 +右, Y=距桌面高度, Z=向前水平距离 (cm)
// ============================================================
static keypoint_3d_t pixel_to_3d(int px, int py,
                                  float R, float focal_px,
                                  float cos_theta, float sin_theta,
                                  float cam_height_cm)
{
    // 1. 方向向量（相机坐标系）
    //    图像Y轴↓，世界Y轴↑，故 ny = (CY - py)/f
    float nx = ((float)px - CX) / focal_px;
    float ny = (CY - (float)py) / focal_px;
    float nz = 1.0f;

    // 2. 归一化
    float norm = sqrtf(nx*nx + ny*ny + nz*nz);
    nx /= norm;
    ny /= norm;
    nz /= norm;

    // 3. 缩放为相机坐标（斜距 R）
    float Xc = nx * R;
    float Yc = ny * R;
    float Zc = nz * R;

    // 4. 绕X轴旋转（摄像头仰角 θ）→ 世界坐标
    float Xw = Xc;
    float Yw =  Yc * cos_theta + Zc * sin_theta;
    float Zw = -Yc * sin_theta + Zc * cos_theta;

    // 5. 平移到桌面原点
    keypoint_3d_t kp;
    kp.X = Xw;
    kp.Y = cam_height_cm + Yw;
    kp.Z = Zw;
    return kp;
}

// ============================================================
// 更新人脸关键点数据（AI 任务调用，检测到人脸时）
// ============================================================
void facial_landmark_data_update(struct timeval timestamp,
    const std::list<dl::detect::result_t> &results,
    float R_cm, float tilt_rad, float focal_px, float cam_height_cm)
{
    if (s_mutex == NULL || results.empty()) return;

    const auto &face = results.front();
    if (face.keypoint.size() < 10) return;

    // 提取5个关键点的2D像素坐标
    // 索引: 0,1=左眼  2,3=左嘴角  4,5=鼻子  6,7=右眼  8,9=右嘴角
    int kp[10];
    for (int i = 0; i < 10; i++) {
        kp[i] = face.keypoint[i];
    }

    // 预计算三角函数
    float cos_tilt = cosf(tilt_rad);
    float sin_tilt = sinf(tilt_rad);

    // 全部转为3D世界坐标
    keypoint_3d_t kp3d[5];
    for (int i = 0; i < 5; i++) {
        kp3d[i] = pixel_to_3d(kp[i*2], kp[i*2+1],
                              R_cm, focal_px, cos_tilt, sin_tilt, cam_height_cm);
    }

    // ---- 写入共享内存（临界区） ----
    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        s_data.timestamp = timestamp;
        s_data.frame_count++;
        s_data.face_detected = true;
        memcpy(s_data.keypoints, kp, sizeof(kp));
        memcpy(s_data.kp3d, kp3d, sizeof(kp3d));

        xSemaphoreGive(s_mutex);
    }
}

// ============================================================
// 清除人脸数据
// ============================================================
void facial_landmark_data_clear(void)
{
    if (s_mutex == NULL) return;

    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        s_data.face_detected = false;
        memset(s_data.keypoints, 0, sizeof(s_data.keypoints));
        memset(s_data.kp3d, 0, sizeof(s_data.kp3d));

        xSemaphoreGive(s_mutex);
    }
}

// ============================================================
// 获取最新数据拷贝
// ============================================================
const facial_landmark_data_t* facial_landmark_data_get_latest(void)
{
    static facial_landmark_data_t s_copy;

    if (s_mutex == NULL) {
        memset(&s_copy, 0, sizeof(s_copy));
        s_copy.face_detected = false;
        return &s_copy;
    }

    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        memcpy(&s_copy, &s_data, sizeof(facial_landmark_data_t));
        xSemaphoreGive(s_mutex);
    }

    return &s_copy;
}
