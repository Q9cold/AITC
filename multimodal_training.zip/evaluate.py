"""
4_evaluate.py - 模型评估与可视化 (修正中文乱码)
"""
import os
import sys
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ===== 设置中文字体（Windows） =====
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import get_score_names

def evaluate_model():
    """评估模型性能"""

    print("=" * 60)
    print("模型评估")
    print("=" * 60)

    # 1. 加载模型和数据
    print("\n加载模型和数据...")
    model = tf.keras.models.load_model('models/best_model.h5')

    data = np.load('models/preprocessed_data.npz')
    X_vis_test = data['X_vis_test']
    X_press_test = data['X_press_test']
    y_test = data['y_test']

    print(f"测试集: {len(X_vis_test)} 样本")

    # 2. 推理
    print("\n推理测试集...")
    y_pred_list = model.predict([X_vis_test, X_press_test])
    y_pred = np.column_stack([pred.flatten() for pred in y_pred_list]) * 100

    # 3. 计算各项指标
    score_names = get_score_names()

    # 中英文对照
    name_map = {
        'forward_lean': '前倾',
        'backward_lean': '后仰',
        'lateral_lean': '侧倾',
        'head_twist': '扭转',
        'pressure_balance': '平衡',
        'pressure_center': '居中',
        'pressure_uniformity': '均匀',
        'posture_stability': '稳定',
        'health_score': '健康'
    }

    # 英文短标签（用于图表）
    short_names = ['Fwd', 'Bwd', 'Lat', 'Twist', 'Bal', 'Center', 'Unif', 'Stab', 'Health']

    print("\n" + "=" * 60)
    print("各维度评估指标")
    print("=" * 60)

    results = []
    for i, name in enumerate(score_names):
        mae = mean_absolute_error(y_test[:, i], y_pred[:, i])
        rmse = np.sqrt(mean_squared_error(y_test[:, i], y_pred[:, i]))
        r2 = r2_score(y_test[:, i], y_pred[:, i])

        results.append({'name': name, 'MAE': mae, 'RMSE': rmse, 'R2': r2})

        print(f"\n{name_map.get(name, name)}:")
        print(f"  MAE: {mae:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  R²: {r2:.4f}")

    # 4. 总体指标
    overall_mae = np.mean([r['MAE'] for r in results])
    overall_rmse = np.mean([r['RMSE'] for r in results])
    overall_r2 = np.mean([r['R2'] for r in results])

    print("\n" + "=" * 60)
    print("总体指标")
    print("=" * 60)
    print(f"平均 MAE: {overall_mae:.4f}")
    print(f"平均 RMSE: {overall_rmse:.4f}")
    print(f"平均 R²: {overall_r2:.4f}")

    # 5. 可视化 - MAE对比图（使用英文标签避免乱码）
    print("\n生成MAE对比图...")

    plt.figure(figsize=(12, 6))
    mae_values = [r['MAE'] for r in results]

    # 从红到绿的渐变色
    colors = plt.cm.RdYlGn_r(np.array(mae_values) / max(mae_values))

    bars = plt.bar(short_names, mae_values, color=colors)
    plt.axhline(y=np.mean(mae_values), color='red', linestyle='--',
                label=f'Avg MAE = {np.mean(mae_values):.2f}')
    plt.xlabel('Score Dimension')
    plt.ylabel('MAE')
    plt.title('MAE Comparison by Dimension')
    plt.xticks(rotation=45, ha='right')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 在柱子上显示数值
    for bar, val in zip(bars, mae_values):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
                f'{val:.2f}', ha='center', va='bottom', fontsize=9)

    plt.tight_layout()

    # 保存
    os.makedirs('models/figures', exist_ok=True)
    plt.savefig('models/figures/mae_comparison.png', dpi=150)
    plt.close()
    print("✅ MAE对比图已保存: models/figures/mae_comparison.png")

    # 6. 散点图
    print("\n生成散点图...")
    fig, axes = plt.subplots(3, 3, figsize=(15, 12))
    axes = axes.flatten()

    for i, name in enumerate(score_names):
        ax = axes[i]
        ax.scatter(y_test[:, i], y_pred[:, i], alpha=0.5, s=10)

        min_val = min(y_test[:, i].min(), y_pred[:, i].min())
        max_val = max(y_test[:, i].max(), y_pred[:, i].max())
        ax.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2)

        ax.set_xlabel('True')
        ax.set_ylabel('Predicted')
        ax.set_title(f'{short_names[i]}\nMAE={results[i]["MAE"]:.2f}, R²={results[i]["R2"]:.3f}')
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('models/figures/evaluation_scatter.png', dpi=150)
    plt.close()
    print("✅ 散点图已保存: models/figures/evaluation_scatter.png")

    # 7. 误差分布图
    print("\n生成误差分布图...")
    fig, axes = plt.subplots(3, 3, figsize=(15, 12))
    axes = axes.flatten()

    for i, name in enumerate(score_names):
        ax = axes[i]
        errors = y_pred[:, i] - y_test[:, i]

        sns.histplot(errors, kde=True, ax=ax, bins=30)
        ax.axvline(0, color='r', linestyle='--', linewidth=2)
        ax.set_xlabel('Error')
        ax.set_ylabel('Frequency')
        ax.set_title(f'{short_names[i]}\nMean={errors.mean():.2f}, Std={errors.std():.2f}')
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('models/figures/evaluation_errors.png', dpi=150)
    plt.close()
    print("✅ 误差分布图已保存: models/figures/evaluation_errors.png")

    # 8. 生成评估报告
    print("\n生成评估报告...")

    report_path = 'models/evaluation_report.txt'
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write("模型评估报告\n")
        f.write("=" * 60 + "\n\n")

        f.write(f"测试集样本数: {len(X_vis_test)}\n\n")

        f.write("各维度评估指标:\n")
        f.write("-" * 50 + "\n")
        f.write(f"{'维度':<20} {'MAE':<10} {'RMSE':<10} {'R²':<10}\n")
        f.write("-" * 50 + "\n")
        for r in results:
            display_name = name_map.get(r['name'], r['name'])
            f.write(f"{display_name:<20} {r['MAE']:.4f}     {r['RMSE']:.4f}     {r['R2']:.4f}\n")

        f.write("\n" + "-" * 50 + "\n")
        f.write(f"平均 MAE: {overall_mae:.4f}\n")
        f.write(f"平均 RMSE: {overall_rmse:.4f}\n")
        f.write(f"平均 R²: {overall_r2:.4f}\n")

    print(f"✅ 评估报告已保存: {report_path}")
    print("\n🎉 评估完成!")


if __name__ == "__main__":
    evaluate_model()