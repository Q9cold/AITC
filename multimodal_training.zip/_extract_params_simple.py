import joblib
import numpy as np
import json
import os

vis_scaler = joblib.load('models/vis_scaler.pkl')
press_scaler = joblib.load('models/press_scaler.pkl')

print("=== Visual Scaler (StandardScaler) ===")
print(f"mean len: {len(vis_scaler.mean_)}")
print(f"mean first 5: {[round(x,4) for x in vis_scaler.mean_.tolist()[:5]]}")
print(f"scale len: {len(vis_scaler.scale_)}")
print(f"scale first 5: {[round(x,4) for x in vis_scaler.scale_.tolist()[:5]]}")

print()
print("=== Pressure Scaler (RobustScaler) ===")
print(f"center len: {len(press_scaler.center_)}")
print(f"center first 5: {[round(x,4) for x in press_scaler.center_.tolist()[:5]]}")
print(f"scale len: {len(press_scaler.scale_)}")
print(f"scale first 5: {[round(x,4) for x in press_scaler.scale_.tolist()[:5]]}")

# Read TFLite model binary
tflite_path = 'models/posture_model_quantized.tflite'
tflite_size = os.path.getsize(tflite_path)
print(f"\nTFLite model size: {tflite_size} bytes ({tflite_size/1024:.2f} KB)")

# Generate C header for model data
with open(tflite_path, 'rb') as fin:
    model_bytes = fin.read()

c_header_path = '../main/model_data.h'
os.makedirs(os.path.dirname(c_header_path), exist_ok=True)

with open(c_header_path, 'w') as f:
    f.write('#ifndef MODEL_DATA_H\n')
    f.write('#define MODEL_DATA_H\n\n')
    f.write('#include <stdint.h>\n\n')
    f.write(f'const unsigned char g_model_data[] = {{\n  ')
    for i, byte in enumerate(model_bytes):
        f.write(f'0x{byte:02x}, ')
        if (i + 1) % 16 == 0:
            f.write('\n  ')
    f.write('\n};\n\n')
    f.write(f'const unsigned int g_model_data_len = {len(model_bytes)};\n\n')
    f.write('#endif\n')

print(f'C header generated: {c_header_path}')

# Save scaler params as JSON for reference
result = {
    'vis_scaler_mean': [round(x, 6) for x in vis_scaler.mean_.tolist()],
    'vis_scaler_scale': [round(x, 6) for x in vis_scaler.scale_.tolist()],
    'press_scaler_center': [round(x, 6) for x in press_scaler.center_.tolist()],
    'press_scaler_scale': [round(x, 6) for x in press_scaler.scale_.tolist()],
}
with open('models/model_params.json', 'w') as f:
    json.dump(result, f, indent=2)
print("Params JSON saved.")