import joblib
import numpy as np
import tensorflow as tf

vis_scaler = joblib.load('models/vis_scaler.pkl')
press_scaler = joblib.load('models/press_scaler.pkl')

print('=== Visual Scaler (StandardScaler) ===')
print('mean (15):')
print(vis_scaler.mean_.tolist())
print('scale (15):')
print(vis_scaler.scale_.tolist())

print()
print('=== Pressure Scaler (RobustScaler) ===')
print('center (256, first 10):')
print(press_scaler.center_.tolist()[:10])
print('scale (256, first 10):')
print(press_scaler.scale_.tolist()[:10])

print()
print('=== TFLite Model Details ===')
interpreter = tf.lite.Interpreter(model_path='models/posture_model_quantized.tflite')
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

for i, inp in enumerate(input_details):
    print(f'Input {i}: name={inp["name"]}, shape={inp["shape"]}, dtype={inp["dtype"]}')
    q = inp.get('quantization_parameters', {})
    print(f'  scales={q.get("scales", "N/A")}')
    print(f'  zero_points={q.get("zero_points", "N/A")}')

for i, out in enumerate(output_details):
    print(f'Output {i}: name={out["name"]}, shape={out["shape"]}, dtype={out["dtype"]}')
    q = out.get('quantization_parameters', {})
    print(f'  scales={q.get("scales", "N/A")}')
    print(f'  zero_points={q.get("zero_points", "N/A")}')

print(f'Total tensor arena: {interpreter.arena_required_size()}')