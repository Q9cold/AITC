import struct, json

def read_flatbuffer_i32(buf, offset):
    return struct.unpack_from('<i', buf, offset)[0]

def read_flatbuffer_u16(buf, offset):
    return struct.unpack_from('<H', buf, offset)[0]

def read_flatbuffer_f32(buf, offset):
    return struct.unpack_from('<f', buf, offset)[0]

def read_flatbuffer_u32(buf, offset):
    return struct.unpack_from('<I', buf, offset)[0]

def read_string(buf, offset):
    slen = read_flatbuffer_u32(buf, offset)
    return buf[offset+4:offset+4+slen].decode('utf-8')

def read_vector(buf, offset):
    vlen = read_flatbuffer_u32(buf, offset)
    return offset + 4, vlen

def parse_table(buf, table_offset):
    """Parse a flatbuffer table, return dict of field_id -> (offset, type_hint)"""
    vtable_offset = table_offset - read_flatbuffer_i32(buf, table_offset)
    vtable_size = read_flatbuffer_u16(buf, vtable_offset)
    table_size = read_flatbuffer_u16(buf, vtable_offset + 2)
    
    fields = {}
    for field_id in range(100):
        field_vtable_offset = 4 + field_id * 2
        if field_vtable_offset >= vtable_size:
            break
        field_offset = read_flatbuffer_u16(buf, vtable_offset + field_vtable_offset)
        if field_offset == 0:
            continue
        # field_offset is relative to table start
        fields[field_id] = table_offset + field_offset
    
    return fields, table_size

def parse_tflite(tflite_path):
    with open(tflite_path, 'rb') as f:
        buf = f.read()
    
    # Root offset is at position 0 (first 4 bytes after "TFL3" magic for newer format)
    # Actually, TFLite files start with 4 bytes offset then "TFL3" magic
    root_offset = read_flatbuffer_u32(buf, 0)
    
    # Parse Model table
    model_fields, _ = parse_table(buf, root_offset)
    
    # Get subgraphs vector (field 6)
    if 6 not in model_fields:
        print("ERROR: Model has no subgraphs")
        return
    
    subgraph_vec_offset, num_subgraphs = read_vector(buf, model_fields[6])
    print(f"Number of subgraphs: {num_subgraphs}")
    
    if num_subgraphs == 0:
        return
    
    # First subgraph
    subgraph_offset_val = read_flatbuffer_u32(buf, subgraph_vec_offset)
    sg_fields, _ = parse_table(buf, subgraph_offset_val)
    
    # Get tensors (field 0)
    if 0 not in sg_fields:
        print("ERROR: SubGraph has no tensors")
        return
    
    tensor_vec_offset, num_tensors = read_vector(buf, sg_fields[0])
    print(f"Number of tensors: {num_tensors}")
    
    # Get inputs (field 2) and outputs (field 4)
    input_indices = []
    if 2 in sg_fields:
        inp_vec, num_inputs = read_vector(buf, sg_fields[2])
        for i in range(num_inputs):
            input_indices.append(read_flatbuffer_i32(buf, inp_vec + i*4))
    print(f"Input tensor indices: {input_indices}")
    
    output_indices = []
    if 4 in sg_fields:
        out_vec, num_outputs = read_vector(buf, sg_fields[4])
        for i in range(num_outputs):
            output_indices.append(read_flatbuffer_i32(buf, out_vec + i*4))
    print(f"Output tensor indices: {output_indices}")
    
    # Parse each tensor
    tensors = []
    for ti in range(num_tensors):
        tensor_offset_val = read_flatbuffer_u32(buf, tensor_vec_offset + ti * 4)
        t_fields, _ = parse_table(buf, tensor_offset_val)
        
        tensor_info = {'index': ti}
        
        # Name (field 6)
        if 6 in t_fields:
            tensor_info['name'] = read_string(buf, t_fields[6])
        else:
            tensor_info['name'] = f'tensor_{ti}'
        
        # Type (field 2) - TensorType enum
        if 2 in t_fields:
            tensor_info['type'] = read_flatbuffer_i32(buf, t_fields[2])
        else:
            tensor_info['type'] = 0
        
        # Shape (field 0)
        if 0 in t_fields:
            shape_vec, num_dims = read_vector(buf, t_fields[0])
            shape = []
            for d in range(num_dims):
                shape.append(read_flatbuffer_i32(buf, shape_vec + d*4))
            tensor_info['shape'] = shape
        else:
            tensor_info['shape'] = []
        
        # Quantization (field 8)
        if 8 in t_fields:
            q_offset = read_flatbuffer_u32(buf, t_fields[8])
            q_fields, _ = parse_table(buf, q_offset)
            
            q_info = {}
            # scale (field 4)
            if 4 in q_fields:
                scale_vec, num_scales = read_vector(buf, q_fields[4])
                scales = []
                for s in range(num_scales):
                    scales.append(read_flatbuffer_f32(buf, scale_vec + s*4))
                q_info['scales'] = scales
            
            # zero_point (field 6)
            if 6 in q_fields:
                zp_vec, num_zp = read_vector(buf, q_fields[6])
                zero_points = []
                for z in range(num_zp):
                    zero_points.append(read_flatbuffer_i32(buf, zp_vec + z*4))
                q_info['zero_points'] = zero_points
            
            tensor_info['quantization'] = q_info
        
        tensors.append(tensor_info)
    
    # Print input tensors
    print("\n=== INPUT TENSORS ===")
    for idx in input_indices:
        t = tensors[idx]
        print(f"  [{idx}] {t['name']}: shape={t['shape']} type={t['type']}")
        if 'quantization' in t:
            print(f"       scales={t['quantization'].get('scales',[])}")
            print(f"       zero_points={t['quantization'].get('zero_points',[])}")
    
    print("\n=== OUTPUT TENSORS ===")
    for idx in output_indices:
        t = tensors[idx]
        print(f"  [{idx}] {t['name']}: shape={t['shape']} type={t['type']}")
        if 'quantization' in t:
            print(f"       scales={t['quantization'].get('scales',[])}")
            print(f"       zero_points={t['quantization'].get('zero_points',[])}")
    
    # Save as JSON
    result = {
        'inputs': [],
        'outputs': []
    }
    for idx in input_indices:
        t = tensors[idx]
        entry = {
            'name': t['name'],
            'shape': t['shape'],
            'type': t['type'],
            'scales': t.get('quantization', {}).get('scales', []),
            'zero_points': t.get('quantization', {}).get('zero_points', [])
        }
        result['inputs'].append(entry)
    for idx in output_indices:
        t = tensors[idx]
        entry = {
            'name': t['name'],
            'shape': t['shape'],
            'type': t['type'],
            'scales': t.get('quantization', {}).get('scales', []),
            'zero_points': t.get('quantization', {}).get('zero_points', [])
        }
        result['outputs'].append(entry)
    
    with open('models/tflite_params.json', 'w') as f:
        json.dump(result, f, indent=2)
    print("\nSaved to models/tflite_params.json")

if __name__ == '__main__':
    parse_tflite('models/posture_model_quantized.tflite')