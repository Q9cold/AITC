import json, os

tflite_path = 'models/posture_model_quantized.tflite'

import tensorflow as tf
interpreter = tf.lite.Interpreter(model_path=tflite_path)
interpreter.allocate_tensors()
inp = interpreter.get_input_details()
out = interpreter.get_output_details()

result = {'inputs': [], 'outputs': []}
for i in inp:
    q = i.get('quantization_parameters', {})
    result['inputs'].append({
        'name': i['name'],
        'shape': [int(x) for x in i['shape'].tolist()],
        'dtype': str(i['dtype']),
        'scales': [float(x) for x in q.get('scales', [])],
        'zero_points': [int(x) for x in q.get('zero_points', [])],
    })
for o in out:
    q = o.get('quantization_parameters', {})
    result['outputs'].append({
        'name': o['name'],
        'shape': [int(x) for x in o['shape'].tolist()],
        'dtype': str(o['dtype']),
        'scales': [float(x) for x in q.get('scales', [])],
        'zero_points': [int(x) for x in q.get('zero_points', [])],
    })

with open('models/tflite_params.json', 'w') as f:
    json.dump(result, f, indent=2)

print("=== TFLite Model Info ===")
for i in result['inputs']:
    print(f"Input {i['name']}: shape={i['shape']} dtype={i['dtype']} scale={i['scales']} zp={i['zero_points']}")
for o in result['outputs']:
    print(f"Output {o['name']}: shape={o['shape']} dtype={o['dtype']} scale={o['scales']} zp={o['zero_points']}")
print("Done!")