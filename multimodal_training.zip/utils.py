"""
utils.py - 通用工具函数 (支持CSV)
"""
import numpy as np
import pandas as pd
from scipy.ndimage import center_of_mass
import joblib
import os
import warnings
warnings.filterwarnings('ignore')

class PostureScoreGenerator:
    """从原始数据生成连续评分标签"""

    def __init__(self, window_size=10):
        self.buffer = []
        self.window_size = window_size

    def _sigmoid(self, x, center=0, scale=1):
        """Sigmoid函数映射到0-1"""
        return 1 / (1 + np.exp(-(x - center) / scale))

    def compute_visual_scores(self, visual_features):
        """
        从15维视觉特征计算评分
        visual_features: [right_eye_X,Y,Z, mouth_left_X,Y,Z, nose_X,Y,Z,
                         left_eye_X,Y,Z, mouth_right_X,Y,Z]
        """
        # 提取关键点
        re_x, re_y, re_z = visual_features[0], visual_features[1], visual_features[2]
        ml_x, ml_y, ml_z = visual_features[3], visual_features[4], visual_features[5]
        n_x, n_y, n_z = visual_features[6], visual_features[7], visual_features[8]
        le_x, le_y, le_z = visual_features[9], visual_features[10], visual_features[11]
        mr_x, mr_y, mr_z = visual_features[12], visual_features[13], visual_features[14]

        # 计算参考点
        eye_center_x = (re_x + le_x) / 2
        eye_center_y = (re_y + le_y) / 2
        eye_center_z = (re_z + le_z) / 2

        # 1. 前倾程度
        forward_raw = (n_z - eye_center_z) * 10
        forward_score = self._sigmoid(forward_raw, 0, 2) * 100

        # 2. 后仰程度
        backward_raw = (eye_center_z - n_z) * 10
        backward_score = self._sigmoid(backward_raw, 0, 2) * 100

        # 3. 侧倾程度
        lateral_raw = abs(n_x - eye_center_x)
        lateral_score = self._sigmoid(lateral_raw, 0, 3) * 100

        # 4. 头部扭转
        twist_raw = abs(re_z - le_z) * 5
        twist_score = self._sigmoid(twist_raw, 0, 2) * 100

        # 5. 面部端正度
        eye_sym = 1 - abs(re_x - le_x) / 10
        mouth_sym = 1 - abs(ml_x - mr_x) / 10
        face_sym = (eye_sym + mouth_sym) / 2
        face_sym_score = max(0, min(100, face_sym * 100))

        return {
            'forward_lean': forward_score,
            'backward_lean': backward_score,
            'lateral_lean': lateral_score,
            'head_twist': twist_score,
            'face_symmetry': face_sym_score
        }

    def compute_pressure_scores(self, pressure_data):
        """从256维压力数据计算评分"""
        # 重塑为16x16
        pressure_map = np.array(pressure_data).reshape(16, 16)

        # 归一化
        if pressure_map.max() > 0:
            pressure_map = pressure_map / pressure_map.max()

        total = pressure_map.sum()

        # 1. 压力中心
        if total > 0:
            com_y, com_x = center_of_mass(pressure_map)
        else:
            com_x, com_y = 7.5, 7.5

        center_dist = np.sqrt((com_x - 7.5)**2 + (com_y - 7.5)**2)
        center_score = max(0, 100 - center_dist * 15)

        # 2. 左右平衡度
        left_half = pressure_map[:, :8].sum()
        right_half = pressure_map[:, 8:].sum()
        if left_half + right_half > 0:
            balance_ratio = left_half / (left_half + right_half)
            balance_score = 100 - abs(balance_ratio - 0.5) * 200
        else:
            balance_score = 50

        # 3. 前后平衡度
        front_half = pressure_map[:8, :].sum()
        back_half = pressure_map[8:, :].sum()
        if front_half + back_half > 0:
            front_ratio = front_half / (front_half + back_half)
            front_score = 100 - abs(front_ratio - 0.5) * 200
        else:
            front_score = 50

        # 4. 压力分布均匀度
        if total > 0:
            prob = pressure_map.flatten() / total
            prob = prob[prob > 0]
            entropy = -np.sum(prob * np.log2(prob + 1e-10))
            max_entropy = np.log2(256)
            uniformity = min(100, (entropy / max_entropy) * 100)
        else:
            uniformity = 0

        # 5. 压力峰值集中度
        peak = pressure_map.max()
        mean = pressure_map.mean()
        if mean > 0:
            concentration = peak / mean
            concentration_score = max(0, 100 - (concentration - 1) * 20)
        else:
            concentration_score = 100

        return {
            'pressure_center': center_score,
            'pressure_balance': balance_score,
            'pressure_front_back': front_score,
            'pressure_uniformity': uniformity,
            'pressure_concentration': concentration_score
        }

    def compute_fusion_scores(self, visual_scores, pressure_scores, history=None):
        """融合视觉和压力评分"""
        # 1. 综合端正度
        upright_score = (
            visual_scores.get('face_symmetry', 50) * 0.3 +
            pressure_scores.get('pressure_balance', 50) * 0.4 +
            (100 - visual_scores.get('lateral_lean', 0)) * 0.3
        )

        # 2. 综合稳定性
        if history is not None and len(history) > 1:
            stability_scores = []
            for key in ['forward_lean', 'lateral_lean', 'pressure_center', 'pressure_balance']:
                if key in history[0]:
                    values = [h.get(key, 50) for h in history]
                    stability_scores.append(np.std(values))
            if stability_scores:
                avg_std = np.mean(stability_scores)
                stability_score = max(0, 100 - avg_std * 2)
            else:
                stability_score = 80
        else:
            stability_score = 80

        # 3. 健康综合评分
        all_scores = {**visual_scores, **pressure_scores}

        health_weights = {
            'forward_lean': 1.5,
            'backward_lean': 0.8,
            'lateral_lean': 1.2,
            'head_twist': 0.8,
            'pressure_balance': 1.5,
            'pressure_center': 1.0,
            'pressure_uniformity': 1.0,
        }

        total_weight = 0
        weighted_sum = 0
        for key, weight in health_weights.items():
            if key in all_scores:
                score = all_scores[key]
                # 有害维度反转
                if key in ['forward_lean', 'lateral_lean', 'head_twist']:
                    score = 100 - score
                weighted_sum += score * weight
                total_weight += weight

        health_score = weighted_sum / total_weight if total_weight > 0 else 50

        all_scores['posture_stability'] = stability_score
        all_scores['health_score'] = health_score
        all_scores['upright_score'] = upright_score

        return all_scores

    def process_frame(self, visual_data, pressure_data, update_history=True):
        """处理单帧数据"""
        visual_scores = self.compute_visual_scores(visual_data)
        pressure_scores = self.compute_pressure_scores(pressure_data)

        if update_history:
            self.buffer.append({**visual_scores, **pressure_scores})
            if len(self.buffer) > self.window_size:
                self.buffer.pop(0)

        fusion_scores = self.compute_fusion_scores(
            visual_scores, pressure_scores, self.buffer
        )

        return fusion_scores


def get_score_vector(scores):
    """按固定顺序提取评分向量"""
    score_names = [
        'forward_lean', 'backward_lean', 'lateral_lean',
        'head_twist', 'pressure_balance', 'pressure_center',
        'pressure_uniformity', 'posture_stability', 'health_score'
    ]
    return np.array([scores.get(name, 50) for name in score_names])


def get_score_names():
    """获取评分名称列表"""
    return [
        'forward_lean', 'backward_lean', 'lateral_lean',
        'head_twist', 'pressure_balance', 'pressure_center',
        'pressure_uniformity', 'posture_stability', 'health_score'
    ]


def prepare_training_data_from_csv(csv_path):
    """
    从CSV文件准备训练数据
    支持两种格式:
    1. 标准格式: 包含 sen_0 ~ sen_255 和视觉关键点列
    2. 带标签格式: 包含 lean, curve 等标签列
    """
    # 读取CSV
    df = pd.read_csv(csv_path)

    print(f"✅ 读取CSV文件: {csv_path}")
    print(f"   数据形状: {df.shape}")
    print(f"   列名: {df.columns.tolist()[:10]}...")

    # 检查并处理可能的列名变化
    # 压力传感器列: sen_0 ~ sen_255
    pressure_cols = [f'sen_{i}' for i in range(256)]

    # 检查是否存在所有压力列
    existing_pressure_cols = [col for col in pressure_cols if col in df.columns]
    if len(existing_pressure_cols) < 256:
        print(f"⚠️ 警告: 只找到 {len(existing_pressure_cols)} 个压力传感器列")
        # 尝试查找其他可能的列名
        alt_pressure_cols = [col for col in df.columns if col.startswith('sen_') or col.startswith('sensor_')]
        if len(alt_pressure_cols) >= 256:
            pressure_cols = alt_pressure_cols[:256]
            print(f"   使用替代列名: {pressure_cols[:5]}...")
        else:
            raise ValueError(f"找不到256个压力传感器列，当前找到: {len(alt_pressure_cols)}")

    # 视觉特征列
    vis_cols = [
        'right_eye_X', 'right_eye_Y', 'right_eye_Z',
        'mouth_left_X', 'mouth_left_Y', 'mouth_left_Z',
        'nose_X', 'nose_Y', 'nose_Z',
        'left_eye_X', 'left_eye_Y', 'left_eye_Z',
        'mouth_right_X', 'mouth_right_Y', 'mouth_right_Z'
    ]

    # 检查视觉列是否存在
    existing_vis_cols = [col for col in vis_cols if col in df.columns]
    if len(existing_vis_cols) < 15:
        print(f"⚠️ 警告: 只找到 {len(existing_vis_cols)} 个视觉特征列")
        # 尝试查找替代列名
        alt_vis_cols = [col for col in df.columns if any(x in col.lower() for x in ['eye', 'nose', 'mouth'])]
        if len(alt_vis_cols) >= 15:
            vis_cols = alt_vis_cols[:15]
            print(f"   使用替代列名: {vis_cols[:5]}...")
        else:
            raise ValueError(f"找不到15个视觉特征列，当前找到: {len(alt_vis_cols)}")

    # 提取数据
    pressure_data = df[pressure_cols].values.astype(np.float32)
    visual_data = df[vis_cols].values.astype(np.float32)

    # 检查是否有NaN
    if np.isnan(pressure_data).any():
        print("⚠️ 压力数据包含NaN，使用0填充")
        pressure_data = np.nan_to_num(pressure_data, 0)
    if np.isnan(visual_data).any():
        print("⚠️ 视觉数据包含NaN，使用0填充")
        visual_data = np.nan_to_num(visual_data, 0)

    # 生成评分标签
    print("\n生成评分标签...")
    score_gen = PostureScoreGenerator()
    all_scores = []

    for i in range(len(df)):
        try:
            scores = score_gen.process_frame(visual_data[i], pressure_data[i])
            score_vector = get_score_vector(scores)
            all_scores.append(score_vector)
        except Exception as e:
            print(f"⚠️ 处理第 {i} 帧时出错: {e}")
            # 使用默认值
            all_scores.append(np.array([50] * 9))

    score_labels = np.array(all_scores)

    print(f"\n✅ 数据加载完成:")
    print(f"   总帧数: {len(df)}")
    print(f"   视觉特征维度: {visual_data.shape[1]}")
    print(f"   压力特征维度: {pressure_data.shape[1]}")
    print(f"   评分标签维度: {score_labels.shape[1]}")
    print(f"   评分范围: [{score_labels.min():.2f}, {score_labels.max():.2f}]")

    return visual_data, pressure_data, score_labels


def prepare_training_data_from_excel(excel_path):
    """从Excel文件准备训练数据 (兼容旧版本)"""
    df = pd.read_excel(excel_path)

    # 提取压力特征
    pressure_cols = [f'sen_{i}' for i in range(256)]
    pressure_data = df[pressure_cols].values.astype(np.float32)

    # 提取视觉特征
    vis_cols = [
        'right_eye_X', 'right_eye_Y', 'right_eye_Z',
        'mouth_left_X', 'mouth_left_Y', 'mouth_left_Z',
        'nose_X', 'nose_Y', 'nose_Z',
        'left_eye_X', 'left_eye_Y', 'left_eye_Z',
        'mouth_right_X', 'mouth_right_Y', 'mouth_right_Z'
    ]
    visual_data = df[vis_cols].values.astype(np.float32)

    # 生成评分标签
    score_gen = PostureScoreGenerator()
    all_scores = []

    for i in range(len(df)):
        scores = score_gen.process_frame(visual_data[i], pressure_data[i])
        score_vector = get_score_vector(scores)
        all_scores.append(score_vector)

    score_labels = np.array(all_scores)

    print(f"✅ 加载数据: {len(df)} 帧")
    print(f"   视觉特征维度: {visual_data.shape[1]}")
    print(f"   压力特征维度: {pressure_data.shape[1]}")
    print(f"   评分标签维度: {score_labels.shape[1]}")
    print(f"   评分范围: [{score_labels.min():.2f}, {score_labels.max():.2f}]")

    return visual_data, pressure_data, score_labels