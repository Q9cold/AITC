import pandas as pd
import numpy as np

# ==================== 1. 读取数据 ====================
df_pressure = pd.read_csv('SB_C175D80_d2_24082023_1013.csv')

print(f"原始数据行数: {len(df_pressure)}")
print(f"原始数据列数: {len(df_pressure.columns)}")
print(f"唯一 time 数量: {df_pressure['time'].nunique()}")

# ==================== 2. 按 time 分组，取平均值 ====================
# 所有传感器列：sen_0 ~ sen_255
sensor_cols = [f'sen_{i}' for i in range(0, 256)]

# 按 time 分组，对所有传感器列取平均
df_pressure_per_time = df_pressure.groupby('time', as_index=False)[sensor_cols].mean()

print(f"降采样后行数: {len(df_pressure_per_time)}")
print(f"降采样后列数: {len(df_pressure_per_time.columns)}")

# ==================== 3. 所有数值保留一位小数 ====================
# 对传感器列（sen_0 ~ sen_255）保留一位小数
for col in sensor_cols:
    df_pressure_per_time[col] = df_pressure_per_time[col].round(1)

print("\n保留一位小数后的前5行数据:")
print(df_pressure_per_time.head())

# ==================== 4. 保存结果 ====================
df_pressure_per_time.to_csv('pressure_data.csv', index=False, float_format='%.1f')
print("\n已保存为 pressure_data.csv")