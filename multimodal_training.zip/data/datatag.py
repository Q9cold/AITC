import pandas as pd

# ==================== 1. 读取数据 ====================
# 压力数据（已降采样，每行一个时间戳）
df_pressure = pd.read_csv('pressure_data.csv')
# 标签数据
df_labels = pd.read_csv('SB_C175D80_d2.csv')

print(f"压力数据行数: {len(df_pressure)}")
print(f"标签数据行数: {len(df_labels)}")

# ==================== 2. 确保时间列类型一致 ====================
# 压力数据中的 time 列
df_pressure['time'] = df_pressure['time'].astype(int)
# 标签数据中的 Time(s) 列
df_labels['Time(s)'] = df_labels['Time(s)'].astype(int)

# ==================== 3. 按 time 列进行合并 ====================
# 内连接：只保留两边都有的时间点
df_merged = pd.merge(
    df_pressure,
    df_labels[['Time(s)', 'lean', 'curve']],  # 只保留需要的标签列
    left_on='time',
    right_on='Time(s)',
    how='inner'  # 内连接，只保留匹配上的行
)

# 删除重复的 Time(s) 列（因为已经和 time 列相同）
df_merged = df_merged.drop(columns=['Time(s)'])

print(f"合并后数据行数: {len(df_merged)}")
print(f"合并后数据列数: {len(df_merged.columns)}")

# ==================== 4. 查看合并结果 ====================
print("\n合并后前5行数据:")
print(df_merged.head())

print("\n合并后列名:")
print(df_merged.columns.tolist())

# ==================== 5. 保存合并后的数据 ====================
df_merged.to_csv('date_tag.csv', index=False)
print("\n已保存为 data_tag.csv")