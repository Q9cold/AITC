import pandas as pd
import numpy as np
from pathlib import Path


def merge_visual_to_sensor(visual_file, sensor_file, output_file=None):
    """
    通过lean和curve匹配，将视觉数据合并到传感器数据
    特殊规则：如果传感器lean=0且curve=0，则视觉数据全部填0
    """

    # 读取数据
    print(f"读取视觉数据: {visual_file}")
    visual_df = pd.read_csv(visual_file)

    print(f"读取传感器数据: {sensor_file}")
    sensor_df = pd.read_csv(sensor_file)

    print(f"\n视觉数据形状: {visual_df.shape}")
    print(f"传感器数据形状: {sensor_df.shape}")

    # 检查必要的列是否存在
    visual_cols = [
        'right_eye_X', 'right_eye_Y', 'right_eye_Z',
        'mouth_left_X', 'mouth_left_Y', 'mouth_left_Z',
        'nose_X', 'nose_Y', 'nose_Z',
        'left_eye_X', 'left_eye_Y', 'left_eye_Z',
        'mouth_right_X', 'mouth_right_Y', 'mouth_right_Z'
    ]

    # 检查列是否存在
    missing_cols = [col for col in visual_cols if col not in visual_df.columns]
    if missing_cols:
        print(f"警告：视觉数据缺少以下列: {missing_cols}")
        visual_cols = [col for col in visual_cols if col in visual_df.columns]

    # 检查lean和curve列
    if 'lean' not in visual_df.columns or 'curve' not in visual_df.columns:
        raise ValueError("视觉数据必须包含'lean'和'curve'列")

    if 'lean' not in sensor_df.columns or 'curve' not in sensor_df.columns:
        raise ValueError("传感器数据必须包含'lean'和'curve'列")

    print(f"\n视觉数据中的lean值: {visual_df['lean'].unique()}")
    print(f"视觉数据中的curve值: {visual_df['curve'].unique()}")
    print(f"传感器数据中的lean值: {sensor_df['lean'].unique()}")
    print(f"传感器数据中的curve值: {sensor_df['curve'].unique()}")

    # 创建匹配键
    visual_df['match_key'] = visual_df['lean'].astype(str) + '_' + visual_df['curve'].astype(str)
    sensor_df['match_key'] = sensor_df['lean'].astype(str) + '_' + sensor_df['curve'].astype(str)

    # 特殊处理：标记lean=0且curve=0的行
    sensor_df['is_zero'] = (sensor_df['lean'] == 0) & (sensor_df['curve'] == 0)

    # 先初始化所有视觉列，填充为0
    for col in visual_cols:
        if col not in sensor_df.columns:
            sensor_df[col] = 0

    # 找到共同的匹配键（排除0_0组合）
    common_keys = set(visual_df['match_key']) & set(sensor_df['match_key'])
    # 如果0_0在common_keys中，移除它（因为我们用特殊规则处理）
    if '0_0' in common_keys:
        common_keys.remove('0_0')

    print(f"\n需要匹配的键（排除0_0）: {common_keys}")

    # 如果传感器是0_0，保持视觉数据为0（已经在初始化时设为0）
    zero_rows = sensor_df[sensor_df['is_zero']]
    print(f"\n传感器 lean=0, curve=0 的行数: {len(zero_rows)}")
    print("这些行的视觉数据将保持为0")

    # 处理非零匹配的数据
    result_dfs = []

    # 先处理0_0的数据（保持为0）
    zero_data = sensor_df[sensor_df['is_zero']].copy()
    if len(zero_data) > 0:
        result_dfs.append(zero_data)

    # 处理其他匹配的数据
    for key in common_keys:
        print(f"\n处理匹配键: {key}")

        # 获取对应的数据（排除0_0）
        visual_subset = visual_df[visual_df['match_key'] == key].copy()
        sensor_subset = sensor_df[(sensor_df['match_key'] == key) & (~sensor_df['is_zero'])].copy()

        print(f"  视觉数据行数: {len(visual_subset)}")
        print(f"  传感器数据行数: {len(sensor_subset)}")

        if len(visual_subset) == 0:
            print(f"  警告：匹配键 {key} 没有视觉数据")
            # 如果没有视觉数据，填充0
            for col in visual_cols:
                sensor_subset[col] = 0
            result_dfs.append(sensor_subset)
            continue

        if len(sensor_subset) == 0:
            print(f"  跳过（没有传感器数据）")
            continue

        # 为这个组分配视觉数据
        merged_group = assign_visual_data(visual_subset, sensor_subset, visual_cols)
        result_dfs.append(merged_group)

    # 处理没有匹配的传感器数据（且不是0_0）
    unmatched_sensor = sensor_df[(~sensor_df['match_key'].isin(common_keys)) & (~sensor_df['is_zero'])]
    if len(unmatched_sensor) > 0:
        print(f"\n处理未匹配的传感器数据: {len(unmatched_sensor)} 行")
        # 对未匹配的数据，填充0
        for col in visual_cols:
            unmatched_sensor[col] = 0
        result_dfs.append(unmatched_sensor)

    # 合并所有结果
    if result_dfs:
        final_df = pd.concat(result_dfs, ignore_index=True)
    else:
        final_df = sensor_df.copy()
        print("警告：没有生成任何合并数据")

    # 删除临时列
    for col in ['match_key', 'is_zero']:
        if col in final_df.columns:
            final_df.drop(col, axis=1, inplace=True)

    # 确保所有视觉列都存在
    for col in visual_cols:
        if col not in final_df.columns:
            final_df[col] = 0

    print(f"\n合并完成！最终数据形状: {final_df.shape}")

    # 显示统计信息
    print("\n视觉数据列统计:")
    for col in visual_cols:
        if col in final_df.columns:
            non_zero = (final_df[col] != 0).sum()
            zero_count = (final_df[col] == 0).sum()
            print(f"  {col}: 非零={non_zero}, 零={zero_count} (总{len(final_df)})")

    # 保存结果
    if output_file:
        final_df.to_csv(output_file, index=False)
        print(f"\n数据已保存到: {output_file}")
    else:
        output_file = f"merged_{Path(sensor_file).stem}_{Path(visual_file).stem}.csv"
        final_df.to_csv(output_file, index=False)
        print(f"\n数据已保存到: {output_file}")

    return final_df


def assign_visual_data(visual_subset, sensor_subset, visual_cols):
    """
    将视觉数据均匀分配到传感器数据的每一行
    """
    n_visual = len(visual_subset)
    n_sensor = len(sensor_subset)

    if n_visual == 0:
        print("  警告：视觉数据为空，填充0")
        for col in visual_cols:
            sensor_subset[col] = 0
        return sensor_subset

    if n_sensor == 0:
        return sensor_subset

    # 创建结果数据框
    result_df = sensor_subset.copy()

    # 如果视觉数据行数等于传感器数据行数，直接一一对应
    if n_visual == n_sensor:
        print(f"  视觉数据和传感器数据行数相同 ({n_visual})，直接对应")
        for i in range(n_visual):
            for col in visual_cols:
                if col in visual_subset.columns:
                    result_df.loc[i, col] = visual_subset.iloc[i][col]

    # 如果视觉数据行数多于传感器数据行数，采样
    elif n_visual > n_sensor:
        print(f"  视觉数据 ({n_visual}) 多于传感器数据 ({n_sensor})，进行采样")
        indices = np.linspace(0, n_visual - 1, n_sensor, dtype=int)
        for i, idx in enumerate(indices):
            for col in visual_cols:
                if col in visual_subset.columns:
                    result_df.loc[i, col] = visual_subset.iloc[idx][col]

    # 如果视觉数据行数少于传感器数据行数，均匀分配
    else:  # n_visual < n_sensor
        print(f"  视觉数据 ({n_visual}) 少于传感器数据 ({n_sensor})，均匀分配")
        sensor_indices = np.linspace(0, n_visual - 1, n_sensor)
        visual_indices = np.round(sensor_indices).astype(int)

        for i, vis_idx in enumerate(visual_indices):
            for col in visual_cols:
                if col in visual_subset.columns:
                    result_df.loc[i, col] = visual_subset.iloc[vis_idx][col]

    return result_df


# 使用示例
if __name__ == "__main__":
    # 设置文件路径
    visual_file = "posture_data.csv"  # 你的视觉数据文件
    sensor_file = "date_tag.csv"# 你的传感器数据文件
    output_file = "../combine_data.csv"  # 输出文件

    # 执行合并
    try:
        merged_df = merge_visual_to_sensor(visual_file, sensor_file, output_file)

        # 显示前几行
        print("\n" + "=" * 50)
        print("前5行数据:")
        print(merged_df.head())

        # 显示特定的行（包含0_0的）
        zero_rows = merged_df[(merged_df['lean'] == 0) & (merged_df['curve'] == 0)]
        if len(zero_rows) > 0:
            print(f"\nlean=0, curve=0 的行:")
            print(zero_rows[['lean', 'curve'] + visual_cols[:3]].head())  # 只显示前3列

    except Exception as e:
        print(f"错误: {e}")
        import traceback

        traceback.print_exc()