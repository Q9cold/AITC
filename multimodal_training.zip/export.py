"""
3_quantize_export.py - 模型量化与导出 (修正版本)
"""
import os
import sys
import numpy as np
import tensorflow as tf
import joblib

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import get_score_names

def quantize_and_export():
    """量化模型并导出为TFLite"""

    print("=" * 60)
    print("模型量化与导出")
    print("=" * 60)

    # 1. 加载模型和数据
    print("\n加载模型...")
    model = tf.keras.models.load_model('models/best_model.h5')

    print("加载数据...")
    data = np.load('models/preprocessed_data.npz')
    X_vis_val = data['X_vis_val']
    X_press_val = data['X_press_val']

    # 2. 生成代表性数据集（用于量化校准）
    print("\n生成代表性数据集...")

    def representative_dataset():
        # 从验证集中采样
        num_samples = min(200, len(X_vis_val))
        indices = np.random.choice(len(X_vis_val), num_samples, replace=False)
        for i in indices:
            vis_sample = X_vis_val[i:i+1].astype(np.float32)
            press_sample = X_press_val[i:i+1].astype(np.float32)
            yield [vis_sample, press_sample]

    # 3. 转换为INT8量化模型
    print("\n转换为INT8量化模型...")

    converter = tf.lite.TFLiteConverter.from_keras_model(model)

    # 量化配置
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = representative_dataset
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8

    # 转换
    try:
        tflite_model = converter.convert()
    except Exception as e:
        print(f"⚠️ INT8量化失败: {e}")
        print("尝试使用FP16量化...")

        # 降级到FP16量化
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        converter.target_spec.supported_types = [tf.float16]
        tflite_model = converter.convert()

    # 4. 保存量化模型
    print("\n保存模型...")

    tflite_path = 'models/posture_model_quantized.tflite'
    with open(tflite_path, 'wb') as f:
        f.write(tflite_model)

    size_kb = os.path.getsize(tflite_path) / 1024
    size_mb = size_kb / 1024

    print(f"✅ 量化模型已保存: {tflite_path}")
    print(f"   模型大小: {size_kb:.2f} KB ({size_mb:.2f} MB)")

    # 5. 生成C++头文件
    print("\n生成C++头文件...")

    cpp_path = 'esp32/model_data.h'
    os.makedirs(os.path.dirname(cpp_path), exist_ok=True)

    with open(cpp_path, 'w') as f:
        f.write('#ifndef MODEL_DATA_H\n')
        f.write('#define MODEL_DATA_H\n\n')
        f.write('#include <stdint.h>\n\n')
        f.write('const unsigned char model_data[] = {\n  ')

        for i, byte in enumerate(tflite_model):
            f.write(f'0x{byte:02x}, ')
            if (i + 1) % 16 == 0:
                f.write('\n  ')

        f.write('\n};\n\n')
        f.write(f'const unsigned int model_data_len = {len(tflite_model)};\n\n')
        f.write('#endif\n')

    print(f"✅ C++头文件已生成: {cpp_path}")

    # 6. 测试量化模型
    print("\n测试量化模型...")

    # 加载量化模型进行推理测试
    interpreter = tf.lite.Interpreter(model_path=tflite_path)
    interpreter.allocate_tensors()

    # 获取输入输出详情
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    print(f"输入张量数量: {len(input_details)}")
    print(f"输出张量数量: {len(output_details)}")

    # 测试单样本推理
    test_idx = 0
    vis_sample = X_vis_val[test_idx:test_idx+1].astype(np.float32)
    press_sample = X_press_val[test_idx:test_idx+1].astype(np.float32)

    # 量化输入
    vis_quant = (vis_sample / np.max(np.abs(vis_sample) + 1e-6) * 127).astype(np.int8)
    press_quant = (press_sample / np.max(np.abs(press_sample) + 1e-6) * 127).astype(np.int8)

    # 设置输入
    interpreter.set_tensor(input_details[0]['index'], vis_quant)
    interpreter.set_tensor(input_details[1]['index'], press_quant)

    # 推理
    interpreter.invoke()

    # 获取输出
    score_names = get_score_names()
    print("\n推理结果示例 (0-1范围，需要乘以100):")
    for i, name in enumerate(score_names):
        if i < len(output_details):
            output = interpreter.get_tensor(output_details[i]['index'])
            score = output[0][0]  # 已经是0-1范围
            print(f"  {name}: {score:.4f} -> {score * 100:.2f}")

    # 7. 生成使用说明
    print("\n" + "=" * 60)
    print("部署说明")
    print("=" * 60)
    print("""
    1. 将 model_data.h 复制到 ESP32-S3 项目的 src/ 目录
    2. 将 posture_inference.h 复制到 ESP32-S3 项目的 src/ 目录
    3. 在 Arduino IDE 中打开 esp32_posture.ino
    4. 编译并上传到 ESP32-S3
    5. 串口监视器将显示坐姿评分结果
    
    注意事项:
    - 确保 ESP32-S3 有足够的 Flash 空间 (至少 2MB)
    - Tensor Arena 大小设置为 55KB
    - 推理频率建议 5-10Hz
    - 模型输出范围是 0-1，需要乘以100得到0-100的评分
    """)

    print("\n🎉 量化导出完成!")


if __name__ == "__main__":
    quantize_and_export()