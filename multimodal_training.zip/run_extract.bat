@echo off
cd /d c:\codes\embed\press\multimodal
python _extract_params_simple.py
pause