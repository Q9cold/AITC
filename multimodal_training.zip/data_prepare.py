"""
1_data_prepare.py - 数据准备与预处理 (支持CSV)
"""
import os
import sys
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import train_test_split
import joblib

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import prepare_training_data_from_csv

def main():
    # 创建模型保存目录
    os.makedirs('../models', exist_ok=True)

    # 1. 加载数据
    print("=" * 60)
    print("Step 1: 加载CSV数据并生成评分标签")
    print("=" * 60)

    csv_path = 'combine_data.csv'  # 改为CSV格式
    visual_data, pressure_data, score_labels = prepare_training_data_from_csv(csv_path)

    # 2. 数据标准化
    print("\n" + "=" * 60)
    print("Step 2: 数据标准化")
    print("=" * 60)

    # 视觉特征使用StandardScaler
    vis_scaler = StandardScaler()
    visual_norm = vis_scaler.fit_transform(visual_data)

    # 压力特征使用RobustScaler（对异常值鲁棒）
    press_scaler = RobustScaler()
    pressure_norm = press_scaler.fit_transform(pressure_data)

    print(f"✅ 视觉特征标准化完成: mean={visual_norm.mean():.3f}, std={visual_norm.std():.3f}")
    print(f"✅ 压力特征标准化完成: mean={pressure_norm.mean():.3f}, std={pressure_norm.std():.3f}")

    # 3. 划分数据集
    print("\n" + "=" * 60)
    print("Step 3: 划分训练/验证/测试集")
    print("=" * 60)

    X_vis_train, X_vis_temp, X_press_train, X_press_temp, y_train, y_temp = train_test_split(
        visual_norm, pressure_norm, score_labels,
        test_size=0.3, random_state=42
    )

    X_vis_val, X_vis_test, X_press_val, X_press_test, y_val, y_test = train_test_split(
        X_vis_temp, X_press_temp, y_temp,
        test_size=0.5, random_state=42
    )

    print(f"训练集: {len(X_vis_train)} 样本")
    print(f"验证集: {len(X_vis_val)} 样本")
    print(f"测试集: {len(X_vis_test)} 样本")

    # 4. 保存处理后的数据
    print("\n" + "=" * 60)
    print("Step 4: 保存预处理数据")
    print("=" * 60)

    data_dict = {
        'X_vis_train': X_vis_train,
        'X_vis_val': X_vis_val,
        'X_vis_test': X_vis_test,
        'X_press_train': X_press_train,
        'X_press_val': X_press_val,
        'X_press_test': X_press_test,
        'y_train': y_train,
        'y_val': y_val,
        'y_test': y_test
    }

    np.savez('models/preprocessed_data.npz', **data_dict)
    joblib.dump(vis_scaler, 'models/vis_scaler.pkl')
    joblib.dump(press_scaler, 'models/press_scaler.pkl')

    print("✅ 预处理数据已保存到: models/preprocessed_data.npz")
    print("✅ 标准化器已保存到: models/vis_scaler.pkl, models/press_scaler.pkl")

    # 5. 数据统计信息
    print("\n" + "=" * 60)
    print("数据统计信息")
    print("=" * 60)
    print(f"视觉特征均值: {visual_norm.mean(axis=0)[:5]}...")
    print(f"视觉特征标准差: {visual_norm.std(axis=0)[:5]}...")
    print(f"压力特征中位数: {np.median(pressure_norm, axis=0)[:5]}...")
    print(f"评分标签均值: {score_labels.mean(axis=0)}")
    print(f"评分标签标准差: {score_labels.std(axis=0)}")

    print("\n🎉 数据准备完成!")

if __name__ == "__main__":
    main()