import joblib
import numpy as np
import tensorflow as tf
import json

vis_scaler = joblib.load('models/vis_scaler.pkl')
press_scaler = joblib.load('models/press_scaler.pkl')

interpreter = tf.lite.Interpreter(model_path='models/posture_model_quantized.tflite')
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

result = {
    'vis_scaler_mean': [round(x, 6) for x in vis_scaler.mean_.tolist()],
    'vis_scaler_scale': [round(x, 6) for x in vis_scaler.scale_.tolist()],
    'press_scaler_center': [round(x, 6) for x in press_scaler.center_.tolist()],
    'press_scaler_scale': [round(x, 6) for x in press_scaler.scale_.tolist()],
    'arena_size': interpreter.arena_required_size(),
    'inputs': [],
    'outputs': [],
}

for i, inp in enumerate(input_details):
    q = inp.get('quantization_parameters', {})
    result['inputs'].append({
        'name': inp['name'],
        'shape': [int(x) for x in inp['shape'].tolist()],
        'dtype': str(inp['dtype']),
        'scales': [float(x) for x in q.get('scales', [])] if 'scales' in q else [],
        'zero_points': [int(x) for x in q.get('zero_points', [])] if 'zero_points' in q else [],
    })

for i, out in enumerate(output_details):
    q = out.get('quantization_parameters', {})
    result['outputs'].append({
        'name': out['name'],
        'shape': [int(x) for x in out['shape'].tolist()],
        'dtype': str(out['dtype']),
        'scales': [float(x) for x in q.get('scales', [])] if 'scales' in q else [],
        'zero_points': [int(x) for x in q.get('zero_points', [])] if 'zero_points' in q else [],
    })

with open('models/model_params.json', 'w') as f:
    json.dump(result, f, indent=2)

print("Done! model_params.json written.")
print(f"Arena size: {result['arena_size']}")
for inp in result['inputs']:
    print(f"Input: {inp['name']} shape={inp['shape']} dtype={inp['dtype']}")
    print(f"  scale={inp['scales']} zp={inp['zero_points']}")
for out in result['outputs']:
    print(f"Output: {out['name']} shape={out['shape']} dtype={out['dtype']}")
    print(f"  scale={out['scales']} zp={out['zero_points']}")