/**
 * @file ui_warning.c
 * @brief 视距/坐姿告警弹窗 — 带 X 关闭，10 秒自动消失
 */
#include "ui_warning.h"
#include "ui_common.h"
#include "cn_eye_warn.h"
#include "cn_posture_warn.h"
#include "warn_eye.h"
#include "warn_posture.h"
#include "esp_heap_caps.h"
#include <string.h>

// —— 旧版：坐姿距离全屏覆盖层 ——
static lv_obj_t *s_overlay = NULL;
static lv_obj_t *s_dist_label = NULL;
static lv_timer_t *s_auto_hide_timer = NULL;
static bool s_shown = false;

static void overlay_click_cb(lv_event_t *e) { ui_warning_hide(); }
static void auto_hide_cb(lv_timer_t *t) { ui_warning_hide(); }

lv_obj_t *ui_warning_create(void)
{
    s_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_overlay, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(s_overlay, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_overlay, overlay_click_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *cont = lv_obj_create(s_overlay);
    lv_obj_set_size(cont, 400, 200);
    lv_obj_align(cont, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(cont, UI_COLOR_CARD_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(cont, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(cont, 20, LV_PART_MAIN);
    lv_obj_set_style_border_width(cont, 3, LV_PART_MAIN);
    lv_obj_set_style_border_color(cont, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_clear_flag(cont, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *title = lv_label_create(cont);
    lv_label_set_text(title, "!! Bad Posture!");
    lv_obj_set_style_text_color(title, UI_COLOR_ALERT_RED, 0);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_30, 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 20);

    s_dist_label = lv_label_create(cont);
    lv_label_set_text(s_dist_label, "Distance: --.- cm");
    lv_obj_set_style_text_color(s_dist_label, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(s_dist_label, &lv_font_montserrat_20, 0);
    lv_obj_align(s_dist_label, LV_ALIGN_CENTER, 0, 20);

    lv_obj_add_flag(s_overlay, LV_OBJ_FLAG_HIDDEN);
    return s_overlay;
}

void ui_warning_show(float d) {
    if (!s_overlay) return;
    char b[32]; snprintf(b, sizeof(b), "Distance: %.1f cm", (double)d);
    lv_label_set_text(s_dist_label, b);
    lv_obj_clear_flag(s_overlay, LV_OBJ_FLAG_HIDDEN);
    lv_obj_set_style_bg_opa(s_overlay, LV_OPA_70, LV_PART_MAIN);
    s_shown = true;
    if (s_auto_hide_timer) lv_timer_del(s_auto_hide_timer);
    s_auto_hide_timer = lv_timer_create(auto_hide_cb, 5000, NULL);
    lv_timer_set_repeat_count(s_auto_hide_timer, 1);
}
void ui_warning_hide(void) {
    if (!s_overlay) return;
    lv_obj_add_flag(s_overlay, LV_OBJ_FLAG_HIDDEN);
    s_shown = false;
    if (s_auto_hide_timer) { lv_timer_del(s_auto_hide_timer); s_auto_hide_timer = NULL; }
}
bool ui_warning_is_shown(void) { return s_shown; }

// —— 新版：视距/坐姿弹窗告警 ——
static lv_obj_t *s_warn_overlay = NULL;
static lv_timer_t *s_warn_timer = NULL;

static void warn_close(lv_event_t *e)
{
    if (s_warn_overlay) lv_obj_add_flag(s_warn_overlay, LV_OBJ_FLAG_HIDDEN);
    if (s_warn_timer) { lv_timer_del(s_warn_timer); s_warn_timer = NULL; }
}

static void warn_auto_hide(lv_timer_t *t)
{
    if (s_warn_overlay) lv_obj_add_flag(s_warn_overlay, LV_OBJ_FLAG_HIDDEN);
    s_warn_timer = NULL;
}

static void show_warn_popup(const lv_img_dsc_t *text_dsc, const lv_img_dsc_t *img_dsc)
{
    if (s_warn_overlay) lv_obj_del(s_warn_overlay);
    if (s_warn_timer) { lv_timer_del(s_warn_timer); s_warn_timer = NULL; }

    s_warn_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_warn_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_warn_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_warn_overlay, LV_OPA_50, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_warn_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_warn_overlay, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *card = lv_obj_create(s_warn_overlay);
    lv_obj_set_size(card, 480, 300);
    lv_obj_align(card, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(card, UI_COLOR_CARD_BG, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 20, LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 3, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

    // X 按钮
    lv_obj_t *xb = lv_btn_create(card);
    lv_obj_set_size(xb, 30, 30);
    lv_obj_align(xb, LV_ALIGN_TOP_RIGHT, -8, 8);
    lv_obj_set_style_bg_color(xb, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(xb, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *xl = lv_label_create(xb);
    lv_label_set_text(xl, LV_SYMBOL_CLOSE);
    lv_obj_set_style_text_color(xl, lv_color_white(), 0);
    lv_obj_center(xl);
    lv_obj_add_event_cb(xb, warn_close, LV_EVENT_CLICKED, NULL);

    // 中文文字
    int cw = text_dsc->header.w, ch = text_dsc->header.h;
    lv_color_t *cb = heap_caps_malloc(cw * ch * 2, MALLOC_CAP_SPIRAM);
    if (cb) {
        memcpy(cb, text_dsc->data, cw * ch * 2);
        lv_obj_t *cv = lv_canvas_create(card);
        lv_canvas_set_buffer(cv, cb, cw, ch, LV_IMG_CF_TRUE_COLOR);
        lv_obj_set_size(cv, cw, ch);
        lv_obj_align(cv, LV_ALIGN_TOP_MID, 0, 15);
        lv_obj_set_style_pad_all(cv, 0, LV_PART_MAIN);
        lv_obj_set_style_border_width(cv, 0, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(cv, LV_OPA_TRANSP, LV_PART_MAIN);
    }
    // 配图
    int iw = img_dsc->header.w, ih = img_dsc->header.h;
    lv_color_t *ib = heap_caps_malloc(iw * ih * 2, MALLOC_CAP_SPIRAM);
    if (ib) {
        memcpy(ib, img_dsc->data, iw * ih * 2);
        lv_obj_t *iv = lv_canvas_create(card);
        lv_canvas_set_buffer(iv, ib, iw, ih, LV_IMG_CF_TRUE_COLOR);
        lv_obj_set_size(iv, iw, ih);
        lv_obj_align(iv, LV_ALIGN_BOTTOM_MID, 0, -10);
        lv_obj_set_style_pad_all(iv, 0, LV_PART_MAIN);
        lv_obj_set_style_border_width(iv, 0, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(iv, LV_OPA_TRANSP, LV_PART_MAIN);
    }

    s_warn_timer = lv_timer_create(warn_auto_hide, 10000, NULL);
    lv_timer_set_repeat_count(s_warn_timer, 1);
}

void ui_warning_show_eye(void)
{
    show_warn_popup(&cn_eye_warn_dsc, &warn_eye_dsc);
}

void ui_warning_show_posture(void)
{
    show_warn_popup(&cn_posture_warn_dsc, &warn_posture_dsc);
}
