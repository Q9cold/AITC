#pragma once
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t app_uart_cmd_init(void);
void app_uart_cmd_send_alert(const char *type);

#ifdef __cplusplus
}
#endif
