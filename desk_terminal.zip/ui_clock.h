/**
 * @file ui_clock.h
 * @brief 时钟页面 — 默认显示大字体数字时钟
 */

#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 创建时钟页面
 * @return 页面对象
 */
lv_obj_t *ui_clock_create(void);

/**
 * @brief 更新时钟时间显示
 */
void ui_clock_update(void);

/**
 * @brief 更新 BLE 连接状态指示
 */
void ui_clock_set_ble_status(bool connected);

#ifdef __cplusplus
}
#endif
