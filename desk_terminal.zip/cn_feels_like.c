#include "cn_feels_like.h"
extern const uint8_t cn_feels_like_map[];
const lv_img_dsc_t cn_feels_like_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 68,
    .header.h = 20,
    .data_size = 2720,
    .data = cn_feels_like_map,
};
