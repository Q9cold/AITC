/**
 * @file ui_manager.c
 * @brief UI 管理器实现
 */

#include "ui_manager.h"
#include "ui_common.h"
#include "ui_home.h"
#include "ui_warning.h"
#include "ui_stats.h"
#include "ui_settings.h"
#include "data_model.h"
#include "lvgl_port.h"
#include "app_uart_cmd.h"
#include "app_i2c_cmd.h"
#include "app_udp_cmd.h"

#include "esp_log.h"
#include <time.h>

static const char *TAG = "ui_manager";

// 屏幕列表
static lv_obj_t *s_screens[3] = {NULL};  // 0=时钟, 1=统计, 2=设置
static lv_obj_t *s_status_bar = NULL;
static lv_obj_t *s_tab_btns[3] = {NULL};
static int s_active_screen = 0;

// 状态追踪
static bool s_last_alerting = false;
static bool s_last_ble_connected = false;
static bool s_first_posture_received = false;
static bool s_last_press_bad = false;
static lv_obj_t *s_voice_toast = NULL;       // 语音命令 Toast 标签
static uint32_t s_voice_toast_time_ms = 0;   // Toast 显示开始时间

// ============================================================
// Tab 按钮点击回调
// ============================================================
static void tab_click_cb(lv_event_t *e)
{
    int idx = (int)(intptr_t)lv_event_get_user_data(e);
    if (idx < 0 || idx > 2) return;
    if (s_screens[idx] == NULL) return;

    s_active_screen = idx;

    // 隐藏所有屏幕
    for (int i = 0; i < 3; i++) {
        if (s_screens[i]) {
            lv_obj_add_flag(s_screens[i], LV_OBJ_FLAG_HIDDEN);
        }
    }

    // 显示目标屏幕
    lv_obj_clear_flag(s_screens[idx], LV_OBJ_FLAG_HIDDEN);

    // 高亮选中 Tab
    lv_color_t metal_on  = lv_color_hex(0x3A3A40);
    lv_color_t metal_off = lv_color_hex(0x252528);
    lv_color_t text_on   = lv_color_hex(0xDDDDDD);
    lv_color_t icon_on   = lv_color_hex(0x999999);
    lv_color_t icon_off  = lv_color_hex(0x666666);
    for (int i = 0; i < 3; i++) {
        if (s_tab_btns[i]) {
            lv_obj_set_style_bg_color(s_tab_btns[i],
                (i == idx) ? metal_on : metal_off, LV_PART_MAIN);
            lv_obj_set_style_shadow_width(s_tab_btns[i],
                (i == idx) ? 4 : 2, LV_PART_MAIN);
            // 文字 (child 0)
            lv_obj_t *lbl = lv_obj_get_child(s_tab_btns[i], 0);
            if (lbl) lv_obj_set_style_text_color(lbl,
                (i == idx) ? text_on : UI_COLOR_TEXT_GRAY, 0);
            // 图标 (child 1)
            lv_obj_t *ico = lv_obj_get_child(s_tab_btns[i], 1);
            if (ico) lv_obj_set_style_text_color(ico,
                (i == idx) ? icon_on : icon_off, 0);
        }
    }
}

// ============================================================
// 数据轮询 lv_timer（200ms 周期）
// ============================================================
static void data_poll_timer(lv_timer_t *timer)
{
    // 读取坐姿数据队列
    posture_data_t data;
    while (xQueueReceive(xQueuePostureData, &data, 0) == pdTRUE) {
        s_first_posture_received = true;

        // 调试输出
        ESP_LOGD(TAG, "Posture: dist=%.1f, safe=%d, alert=%d, seq=%lu",
                 data.distance_cm, data.is_safe, data.is_alerting,
                 (unsigned long)data.sequence_number);

        // 更新设置页面的同步值
        ui_settings_update_from_remote(data.safe_distance_cm, data.alert_enabled);

        // 告警状态变更
        if (data.is_alerting && !s_last_alerting) {
            ESP_LOGI(TAG, "ALERT triggered! distance=%.1f", data.distance_cm);
            ui_warning_show(data.distance_cm);
            app_i2c_cmd_send_alert(1);
            app_uart_cmd_send_alert("posture");
            app_udp_cmd_send_alert("posture");
        } else if (!data.is_alerting && s_last_alerting) {
            ESP_LOGI(TAG, "Alert cleared");
            ui_warning_hide();
        }

        // 持续告警期间更新距离
        if (data.is_alerting && ui_warning_is_shown()) {
            // warning overlay 的 distance label 已在 show 时设置
            // 可用 ui_warning_show 再次更新
            ui_warning_show(data.distance_cm);
        }

        s_last_alerting = data.is_alerting;
    }

    // 读取统计数据队列
    posture_stats_t stats;
    while (xQueueReceive(xQueuePostureStats, &stats, 0) == pdTRUE) {
        ui_stats_update(&stats);
    }
    // 无条件刷新监控时长（开机计时）
    ui_stats_update(NULL);

    // 读取语音命令队列（hello_esp UART → 显示 Toast）
    // 注意：LVGL 仅支持 Latin 字体，中文命令仅记录到串口日志
    voice_cmd_t vcmd;
    while (xQueueReceive(xQueueVoiceCmd, &vcmd, 0) == pdTRUE) {
        ESP_LOGI(TAG, "Voice command: \"%s\"", vcmd.text);
        if (s_voice_toast) {
            lv_label_set_text(s_voice_toast, "Voice Cmd");
            lv_obj_clear_flag(s_voice_toast, LV_OBJ_FLAG_HIDDEN);
            s_voice_toast_time_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
        }
    }

    // 语音 Toast 自动隐藏（10 秒，便于观察 I2C 通信）
    if (s_voice_toast && !lv_obj_has_flag(s_voice_toast, LV_OBJ_FLAG_HIDDEN)) {
        uint32_t now_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
        if (now_ms - s_voice_toast_time_ms > 10000) {
            lv_obj_add_flag(s_voice_toast, LV_OBJ_FLAG_HIDDEN);
        }
    }

    // 读取压力报警队列（press BLE → 触发警告）
    press_alert_t palert;
    while (xQueueReceive(xQueuePressAlert, &palert, 0) == pdTRUE) {
        ESP_LOGD(TAG, "Press alert: %s", palert.is_bad ? "BAD" : "OK");
        if (palert.is_bad && !s_last_press_bad) {
            ui_warning_show(0.0f);  // 压力报警，距离参数无意义
            s_last_press_bad = true;
            app_i2c_cmd_send_alert(2);
            app_uart_cmd_send_alert("press");
            app_udp_cmd_send_alert("press");
        } else if (!palert.is_bad && s_last_press_bad) {
            ui_warning_hide();
            s_last_press_bad = false;
        }
    }

    // 读取坐姿评分队列（PressPosture BLE → 更新圆环 + 告警检测）
    posture_scores_t scores;
    while (xQueueReceive(xQueuePostureScores, &scores, 0) == pdTRUE) {
        ui_home_set_posture_score(scores.health_score);
        if (!ui_settings_alert_enabled()) continue;  // 用户关闭告警开关

        // 视距告警: forward_lean < 40
        if (scores.forward_lean < 40.0f && scores.forward_lean > 0.0f) {
            ui_warning_show_eye();
            app_udp_cmd_send_alert("press");      // → rsp_alert_press.wav
            app_i2c_cmd_send_alert(2);
        }
        // 坐姿告警: health_score < 40
        if (scores.health_score < 40.0f && scores.health_score > 0.0f) {
            ui_warning_show_posture();
            app_udp_cmd_send_alert("posture");    // → rsp_alert_posture.wav
            app_i2c_cmd_send_alert(1);
        }
    }

    // 更新 BLE 连接状态
    ble_conn_status_t ble_status = data_model_get_ble_status();
    bool ble_connected = (ble_status == BLE_STATUS_CONNECTED);
    if (ble_connected != s_last_ble_connected) {
        s_last_ble_connected = ble_connected;
        ui_common_update_ble_icon(s_status_bar, ble_connected);
        ui_home_set_ble_status(ble_connected);
    }

    // 更新时钟
    ui_home_update();

    // 更新状态栏 WiFi 信号图标
    if (s_status_bar) {
        ui_common_update_wifi_icon(s_status_bar);
    }
}

// ============================================================
// 初始化
// ============================================================
void ui_manager_init(void)
{
    // 初始化主题
    ui_common_init();

    // 创建状态栏（置顶层）
    s_status_bar = ui_common_create_status_bar(lv_layer_top());
    lv_obj_align(s_status_bar, LV_ALIGN_TOP_MID, 0, 0);

    // 创建 3 个屏幕（放在活动屏幕上，由 Tab 切换可见性）
    lv_obj_t *parent = lv_scr_act();

    s_screens[0] = ui_home_create(lv_scr_act());
    lv_obj_align(s_screens[0], LV_ALIGN_TOP_MID, 0, 30);

    s_screens[1] = ui_stats_create(lv_scr_act());
    lv_obj_align(s_screens[1], LV_ALIGN_TOP_MID, 0, 30);
    lv_obj_add_flag(s_screens[1], LV_OBJ_FLAG_HIDDEN);

    s_screens[2] = ui_settings_create(lv_scr_act());
    lv_obj_align(s_screens[2], LV_ALIGN_TOP_MID, 0, 30);
    lv_obj_add_flag(s_screens[2], LV_OBJ_FLAG_HIDDEN);

    // 机械风底部控制台
    lv_color_t metal_bg  = lv_color_hex(0x1C1C1E);  // 枪铁底色
    lv_color_t metal_on  = lv_color_hex(0x3A3A40);  // 选中面板
    lv_color_t metal_off = lv_color_hex(0x252528);  // 未选中
    lv_color_t edge_hi   = lv_color_hex(0x4A4A50);  // 高光边

    lv_obj_t *tab_bar = lv_obj_create(parent);
    lv_obj_set_size(tab_bar, LV_HOR_RES, 50);
    lv_obj_align(tab_bar, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_set_style_bg_color(tab_bar, metal_bg, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(tab_bar, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(tab_bar, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(tab_bar, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(tab_bar, 6, LV_PART_MAIN);
    lv_obj_clear_flag(tab_bar, LV_OBJ_FLAG_SCROLLABLE);

    // 顶部高光线
    lv_obj_t *tb_edge = lv_obj_create(tab_bar);
    lv_obj_set_size(tb_edge, LV_HOR_RES, 1);
    lv_obj_set_style_bg_color(tb_edge, edge_hi, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(tb_edge, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(tb_edge, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(tb_edge, 0, LV_PART_MAIN);
    lv_obj_align(tb_edge, LV_ALIGN_TOP_MID, 0, 0);

    // 文字 + 图标
    static const char *tab_texts[]  = {"Home",   "Stats",    "Settings"};
    static const char *tab_icons[]  = {LV_SYMBOL_HOME, LV_SYMBOL_LIST, LV_SYMBOL_SETTINGS};
    int tab_w = (LV_HOR_RES - 24) / 3;

    for (int i = 0; i < 3; i++) {
        s_tab_btns[i] = lv_btn_create(tab_bar);
        lv_obj_set_size(s_tab_btns[i], tab_w, 38);
        lv_obj_set_style_bg_color(s_tab_btns[i],
            (i == 0) ? metal_on : metal_off, LV_PART_MAIN);
        lv_obj_set_flex_flow(s_tab_btns[i], LV_FLEX_FLOW_ROW);
        lv_obj_set_flex_align(s_tab_btns[i], LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
        lv_obj_align(s_tab_btns[i], LV_ALIGN_LEFT_MID, i * (tab_w + 6), 0);
        lv_obj_set_style_radius(s_tab_btns[i], 4, LV_PART_MAIN);
        lv_obj_set_style_border_width(s_tab_btns[i], 0, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(s_tab_btns[i], (i == 0) ? 4 : 2, LV_PART_MAIN);
        lv_obj_set_style_shadow_color(s_tab_btns[i], lv_color_hex(0x000000), LV_PART_MAIN);
        lv_obj_set_style_shadow_opa(s_tab_btns[i], LV_OPA_50, LV_PART_MAIN);
        lv_obj_set_style_shadow_ofs_y(s_tab_btns[i], 2, LV_PART_MAIN);
        lv_obj_set_style_pad_column(s_tab_btns[i], 6, LV_PART_MAIN);

        // 文字标签
        lv_obj_t *label = lv_label_create(s_tab_btns[i]);
        lv_label_set_text(label, tab_texts[i]);
        lv_obj_set_style_text_color(label,
            (i == 0) ? lv_color_hex(0xDDDDDD) : UI_COLOR_TEXT_GRAY, 0);
        lv_obj_set_style_text_font(label, &lv_font_montserrat_16, 0);

        // 图标
        lv_obj_t *icon = lv_label_create(s_tab_btns[i]);
        lv_label_set_text(icon, tab_icons[i]);
        lv_obj_set_style_text_color(icon,
            (i == 0) ? lv_color_hex(0x999999) : lv_color_hex(0x666666), 0);
        lv_obj_set_style_text_font(icon, &lv_font_montserrat_16, 0);

        lv_obj_add_event_cb(s_tab_btns[i], tab_click_cb, LV_EVENT_CLICKED,
                            (void *)(intptr_t)i);
    }

    // 创建警告覆盖层（置顶层，默认隐藏）
    ui_warning_create();

    // 创建语音命令 Toast（顶部居中，默认隐藏）
    s_voice_toast = lv_label_create(lv_layer_top());
    lv_obj_set_style_bg_color(s_voice_toast, UI_COLOR_ACCENT, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_voice_toast, LV_OPA_80, LV_PART_MAIN);
    lv_obj_set_style_text_color(s_voice_toast, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(s_voice_toast, &lv_font_montserrat_24, 0);
    lv_obj_set_style_pad_all(s_voice_toast, 12, LV_PART_MAIN);
    lv_obj_set_style_radius(s_voice_toast, 12, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_voice_toast, LV_OPA_90, LV_PART_MAIN);
    lv_label_set_text(s_voice_toast, "");
    lv_obj_align(s_voice_toast, LV_ALIGN_TOP_MID, 0, 35);
    lv_obj_add_flag(s_voice_toast, LV_OBJ_FLAG_HIDDEN);

    // 创建数据轮询定时器（200ms 周期）
    lv_timer_create(data_poll_timer, 200, NULL);

    ESP_LOGI(TAG, "UI Manager initialized");
}
