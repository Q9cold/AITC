#include "note_e.h"
extern const uint8_t note_e_map[];
const lv_img_dsc_t note_e_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 24,
    .header.h = 28,
    .data_size = 1344,
    .data = note_e_map,
};
