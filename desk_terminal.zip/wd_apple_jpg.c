#include "wd_apple_jpg.h"
extern const uint8_t wd_apple_jpg_map[];
const lv_img_dsc_t wd_apple_jpg_dsc = {
    .header.cf = LV_IMG_CF_RAW,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 200,
    .header.h = 180,
    .data_size = 22075,
    .data = wd_apple_jpg_map,
};
