/**
 * @file ui_common.h
 * @brief 公共 UI 工具 — 主题初始化、颜色、字体引用、状态栏
 */

#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// 颜色常量
// ============================================================
#define UI_COLOR_BG           lv_color_hex(0x1a1a2e)   // 深蓝黑背景
#define UI_COLOR_CARD_BG      lv_color_hex(0x16213e)   // 卡片背景
#define UI_COLOR_ACCENT        lv_color_hex(0x0f3460)   // 强调色
#define UI_COLOR_TEXT_WHITE    lv_color_hex(0xffffff)
#define UI_COLOR_TEXT_GRAY     lv_color_hex(0xcccccc)
#define UI_COLOR_SAFE_GREEN    lv_color_hex(0x00e676)   // 安全绿
#define UI_COLOR_ALERT_RED     lv_color_hex(0xff1744)   // 警报红
#define UI_COLOR_CONNECTED     lv_color_hex(0x00e676)   // BLE 已连接
#define UI_COLOR_DISCONNECTED  lv_color_hex(0xff5252)   // BLE 断开
#define UI_COLOR_CONNECTING    lv_color_hex(0xffd740)   // BLE 连接中

// ============================================================
// 函数声明
// ============================================================

/**
 * @brief 初始化 UI 主题和样式
 */
void ui_common_init(void);

/**
 * @brief 创建状态栏（顶部）
 * @param parent 父对象
 * @return 状态栏容器
 */
lv_obj_t *ui_common_create_status_bar(lv_obj_t *parent);

/**
 * @brief 更新状态栏 BLE 图标
 * @param connected   true=已连接, false=未连接
 */
void ui_common_update_ble_icon(lv_obj_t *status_bar, bool connected);

/**
 * @brief 更新状态栏 WiFi 信号图标（自动读取 RSSI，转 3 档显示）
 * @param status_bar  状态栏容器
 */
void ui_common_update_wifi_icon(lv_obj_t *status_bar);

/**
 * @brief 创建卡片样式容器
 */
lv_obj_t *ui_common_create_card(lv_obj_t *parent, int w, int h);

/**
 * @brief 创建标题文本
 */
lv_obj_t *ui_common_create_title(lv_obj_t *parent, const char *text);

#ifdef __cplusplus
}
#endif
