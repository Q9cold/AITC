/**
 * @file app_i2c_cmd.c
 * @brief I2C 主站通信 — 与 hello_esp I2C 从机通信
 */
#include "app_i2c_cmd.h"
#include "data_model.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "i2c_cmd";
#define I2C_MASTER_NUM    0
#define I2C_SLAVE_ADDR    0x2A
#define I2C_TIMEOUT_MS    100

static void __attribute__((unused)) i2c_poll_task(void *arg)
{
    bool seen_ack = false;
    while (1) {
        // 两步读 — 先读长度，再精确读文本（避免读到从机缓冲区外的 NACK）
        uint8_t len_byte = 0;
        esp_err_t err = i2c_master_read_from_device(
            I2C_MASTER_NUM, I2C_SLAVE_ADDR,
            &len_byte, 1, pdMS_TO_TICKS(I2C_TIMEOUT_MS));

        if (err == ESP_OK) {
            if (!seen_ack) {
                ESP_LOGI(TAG, "I2C ACK! Slave online at 0x%02X", I2C_SLAVE_ADDR);
                seen_ack = true;
            }
            if (len_byte >= 1 && len_byte <= 128) {
                uint8_t text[129] = {0};
                err = i2c_master_read_from_device(
                    I2C_MASTER_NUM, I2C_SLAVE_ADDR,
                    text, len_byte, pdMS_TO_TICKS(I2C_TIMEOUT_MS));
                if (err == ESP_OK) {
                    text[len_byte] = '\0';
                    ESP_LOGI(TAG, "Voice cmd: \"%s\"", (char *)text);
                    voice_cmd_t cmd = {0};
                    memcpy(cmd.text, text, len_byte < 127 ? len_byte : 127);
                    xQueueSend(xQueueVoiceCmd, &cmd, 0);
                }
            }
        }
        vTaskDelay(pdMS_TO_TICKS(10000));  // 低频轮询，不触发 ISR WDT
    }
}

static void i2c_scan_bus(void)
{
    ESP_LOGI(TAG, "=== I2C Bus Scan (I2C0 GPIO8/9) ===");
    int found = 0;
    for (uint8_t addr = 1; addr < 128; addr++) {
        if (addr < 0x08 || (addr >= 0x78 && addr <= 0x7F)) continue;
        uint8_t dummy = 0;
        if (i2c_master_write_to_device(I2C_MASTER_NUM, addr, &dummy, 1, pdMS_TO_TICKS(20)) == ESP_OK) {
            const char *name = "";
            if (addr == 0x14 || addr == 0x5D) name = " GT911";
            else if (addr == I2C_SLAVE_ADDR) name = " hello_esp";
            ESP_LOGI(TAG, "  [FOUND] 0x%02X%s", addr, name);
            found++;
        }
    }
    ESP_LOGI(TAG, "Scan done: %d device(s)", found);
}

esp_err_t app_i2c_cmd_init(void)
{
    i2c_scan_bus();
    // I2C 后台轮询由独立定时器驱动
    ESP_LOGI(TAG, "I2C master ready (slave at 0x%02X)", I2C_SLAVE_ADDR);
    return ESP_OK;
}

void app_i2c_cmd_send_alert(uint8_t alert)
{
    esp_err_t err = i2c_master_write_to_device(
        I2C_MASTER_NUM, I2C_SLAVE_ADDR, &alert, 1, pdMS_TO_TICKS(I2C_TIMEOUT_MS));
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "Alert sent: type=%d", alert);
    } else {
        ESP_LOGW(TAG, "Alert send NACK");
    }
}
