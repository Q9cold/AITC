#include "cn_health_score.h"
extern const uint8_t cn_health_score_map[];
const lv_img_dsc_t cn_health_score_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 112,
    .header.h = 21,
    .data_size = 4704,
    .data = cn_health_score_map,
};
