#include "app_weather.h"
#include "esp_log.h"
#include "esp_http_client.h"
#include "cJSON.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <stdio.h>

static const char *TAG = "weather";

// 默认坐标（郑州）— IP 定位失败时回退
static float  s_lat = 34.76f;
static float  s_lon = 113.65f;
static bool   s_geo_ok = false;
static weather_t s_weather = {0};

static char s_resp_buf[1536];
static int  s_resp_len = 0;

static esp_err_t http_event_cb(esp_http_client_event_t *evt)
{
    if (evt->event_id == HTTP_EVENT_ON_DATA && s_resp_len < 1535) {
        int cp = evt->data_len;
        if (s_resp_len + cp > 1535) cp = 1535 - s_resp_len;
        memcpy(s_resp_buf + s_resp_len, evt->data, cp);
        s_resp_len += cp;
    }
    return ESP_OK;
}

// ============================================================
// IP 定位 — http://ip-api.com/json/
// 返回: {"status":"success","lat":34.76,"lon":113.65,"city":"Zhengzhou",...}
// ============================================================
static void fetch_location(void)
{
    s_resp_len = 0;
    memset(s_resp_buf, 0, sizeof(s_resp_buf));

    esp_http_client_config_t cfg = {
        .url = "http://ip-api.com/json/",
        .timeout_ms = 5000,
        .event_handler = http_event_cb,
    };
    esp_http_client_handle_t cli = esp_http_client_init(&cfg);
    esp_err_t err = esp_http_client_perform(cli);
    int st = esp_http_client_get_status_code(cli);
    esp_http_client_cleanup(cli);

    if (err == ESP_OK && st == 200 && s_resp_len > 0) {
        s_resp_buf[s_resp_len] = 0;
        cJSON *root = cJSON_Parse(s_resp_buf);
        if (root) {
            cJSON *lat = cJSON_GetObjectItem(root, "lat");
            cJSON *lon = cJSON_GetObjectItem(root, "lon");
            cJSON *city = cJSON_GetObjectItem(root, "city");
            if (lat && lon && cJSON_IsNumber(lat) && cJSON_IsNumber(lon)) {
                s_lat = (float)lat->valuedouble;
                s_lon = (float)lon->valuedouble;
                s_geo_ok = true;
                const char *cn = city ? city->valuestring : "?";
                if (city && city->valuestring) {
                    strncpy(s_weather.city, city->valuestring,
                            sizeof(s_weather.city) - 1);
                }
                ESP_LOGI(TAG, "Location: %s (%.4f, %.4f)", cn,
                         (double)s_lat, (double)s_lon);
            }
            cJSON_Delete(root);
        }
    }
    if (!s_geo_ok)
        ESP_LOGW(TAG, "IP geo failed, fallback (%.2f,%.2f)",
                 (double)s_lat, (double)s_lon);
}

// ============================================================
// 天气拉取
// ============================================================
static void fetch_task(void *arg)
{
    vTaskDelay(pdMS_TO_TICKS(15000));
    ESP_LOGI(TAG, "Fetch task started");

    // 先定位
    fetch_location();

    while (1) {
        // 动态拼接 URL
        char url[512];
        snprintf(url, sizeof(url),
            "http://api.open-meteo.com/v1/forecast?"
            "latitude=%.4f&longitude=%.4f"
            "&current=temperature_2m,relative_humidity_2m,weather_code"
            ",apparent_temperature,wind_speed_10m"
            "&daily=temperature_2m_max,temperature_2m_min"
            ",precipitation_probability_max"
            "&forecast_days=1&timezone=auto",
            (double)s_lat, (double)s_lon);

        s_resp_len = 0;
        memset(s_resp_buf, 0, sizeof(s_resp_buf));

        esp_http_client_config_t cfg = {
            .url = url,
            .timeout_ms = 8000,
            .event_handler = http_event_cb,
        };
        esp_http_client_handle_t cli = esp_http_client_init(&cfg);
        esp_err_t err = esp_http_client_perform(cli);
        int st = esp_http_client_get_status_code(cli);
        ESP_LOGI(TAG, "HTTP: err=%d status=%d len=%d", err, st, s_resp_len);

        if (err == ESP_OK && st == 200 && s_resp_len > 0) {
            s_resp_buf[s_resp_len] = 0;
            cJSON *root = cJSON_Parse(s_resp_buf);
            if (root) {
                cJSON *cur = cJSON_GetObjectItem(root, "current");
                if (cur) {
                    cJSON *t = cJSON_GetObjectItem(cur, "temperature_2m");
                    cJSON *h = cJSON_GetObjectItem(cur, "relative_humidity_2m");
                    cJSON *w = cJSON_GetObjectItem(cur, "weather_code");
                    cJSON *fl = cJSON_GetObjectItem(cur, "apparent_temperature");
                    cJSON *ws = cJSON_GetObjectItem(cur, "wind_speed_10m");
                    if (t && h && w) {
                        s_weather.temp = (float)t->valuedouble;
                        s_weather.humidity = h->valueint;
                        s_weather.code = w->valueint;
                        s_weather.feels_like = (fl && !cJSON_IsNull(fl))
                            ? (float)fl->valuedouble : s_weather.temp;
                        s_weather.wind_speed = (ws && !cJSON_IsNull(ws))
                            ? (float)ws->valuedouble : 0.0f;
                    }
                }
                cJSON *daily = cJSON_GetObjectItem(root, "daily");
                if (daily) {
                    cJSON *dmax = cJSON_GetObjectItem(daily, "temperature_2m_max");
                    cJSON *dmin = cJSON_GetObjectItem(daily, "temperature_2m_min");
                    cJSON *dpre = cJSON_GetObjectItem(daily, "precipitation_probability_max");
                    if (dmax && cJSON_GetArraySize(dmax) > 0)
                        s_weather.daily_max = (float)cJSON_GetArrayItem(dmax, 0)->valuedouble;
                    if (dmin && cJSON_GetArraySize(dmin) > 0)
                        s_weather.daily_min = (float)cJSON_GetArrayItem(dmin, 0)->valuedouble;
                    if (dpre && cJSON_GetArraySize(dpre) > 0)
                        s_weather.precip_prob = cJSON_GetArrayItem(dpre, 0)->valueint;
                }
                s_weather.valid = true;
                ESP_LOGI(TAG, "OK: %.1fC %d%% code=%d fl=%.1f "
                    "ws=%.1f hi=%.1f lo=%.1f rain=%d%%",
                    (double)s_weather.temp, s_weather.humidity,
                    s_weather.code, (double)s_weather.feels_like,
                    (double)s_weather.wind_speed,
                    (double)s_weather.daily_max,
                    (double)s_weather.daily_min,
                    s_weather.precip_prob);
                cJSON_Delete(root);
            }
        }
        esp_http_client_cleanup(cli);
        vTaskDelay(pdMS_TO_TICKS(1800000));
    }
}

void app_weather_init(void)
{
    xTaskCreate(fetch_task, "weather", 8192, NULL, 4, NULL);
}
const weather_t *app_weather_get(void) { return &s_weather; }
