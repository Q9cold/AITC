#include "cn_sunny.h"
extern const uint8_t cn_sunny_map[];
const lv_img_dsc_t cn_sunny_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 26,
    .header.h = 25,
    .data_size = 1300,
    .data = cn_sunny_map,
};
