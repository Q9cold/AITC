#include "cn_humidity.h"
extern const uint8_t cn_humidity_map[];
const lv_img_dsc_t cn_humidity_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 36,
    .header.h = 20,
    .data_size = 1440,
    .data = cn_humidity_map,
};
