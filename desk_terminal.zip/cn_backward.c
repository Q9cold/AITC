#include "cn_backward.h"
extern const uint8_t cn_backward_map[];
const lv_img_dsc_t cn_backward_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 76,
    .header.h = 21,
    .data_size = 3192,
    .data = cn_backward_map,
};
