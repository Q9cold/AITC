#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const lv_img_dsc_t wd_car_jpg_dsc;
#ifdef __cplusplus
}
#endif
