#include "cn_dragon.h"
extern const uint8_t cn_dragon_map[];
const lv_img_dsc_t cn_dragon_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 24,
    .header.h = 23,
    .data_size = 1104,
    .data = cn_dragon_map,
};
