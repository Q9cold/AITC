#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t w_icon_rain_map[];
extern const lv_img_dsc_t w_icon_rain_dsc;
#ifdef __cplusplus
}
#endif
