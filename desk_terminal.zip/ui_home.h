/**
 * @file ui_home.h
 * @brief 首页 — 儿童友好桌面
 *
 * 包含：全屏背景图、半透明时钟卡片、三个功能按钮
 *       (播放音乐 / 播放动画 / 告警历史)
 */

#pragma once

#include "lvgl.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 创建首页
 * @return 页面对象
 */
lv_obj_t *ui_home_create(lv_obj_t *parent);

/**
 * @brief 更新时钟时间显示
 */
void ui_home_update(void);

/**
 * @brief 更新 BLE 连接状态指示
 * @param connected  true=已连接, false=搜索中
 */
void ui_home_set_ble_status(bool connected);

/**
 * @brief 更新姿态健康分圆环颜色
 * @param score  0-100 综合评分
 */
void ui_home_set_posture_score(float score);

#ifdef __cplusplus
}
#endif
