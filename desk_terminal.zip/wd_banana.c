#include "wd_banana.h"
extern const uint8_t wd_banana_map[];
const lv_img_dsc_t wd_banana_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 200,
    .header.h = 180,
    .data_size = 72000,
    .data = wd_banana_map,
};
