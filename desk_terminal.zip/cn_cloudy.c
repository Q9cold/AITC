#include "cn_cloudy.h"
extern const uint8_t cn_cloudy_map[];
const lv_img_dsc_t cn_cloudy_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 48,
    .header.h = 25,
    .data_size = 2400,
    .data = cn_cloudy_map,
};
