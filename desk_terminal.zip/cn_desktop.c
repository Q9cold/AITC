#include "cn_desktop.h"
extern const uint8_t cn_desktop_map[];
const lv_img_dsc_t cn_desktop_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 124,
    .header.h = 23,
    .data_size = 5704,
    .data = cn_desktop_map,
};
