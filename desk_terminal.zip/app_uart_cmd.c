#include "app_uart_cmd.h"
#include "data_model.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "driver/usb_serial_jtag.h"
#include "soc/usb_serial_jtag_struct.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include <string.h>
#include <stdio.h>

static const char *TAG_UART = "uart";

#define UART_NUM    UART_NUM_2
#define RX_PIN      13   // GPIO13 — SD MISO（SD_CS 已拉高，干净输入）
#define TX_PIN      4    // GPIO4  — 仅在 LCD 初始化时用过，之后空闲
#define BAUD        115200
#define BUF_SIZE    512

static void parse_cmd(const char *line, int len)
{
    if (len < 5 || strncmp(line, "CMD:", 4)) return;
    const char *text = line + 4;
    int tl = len - 4;
    while (tl > 0 && (text[tl-1]=='\n'||text[tl-1]=='\r')) tl--;
    if (tl <= 0 || tl > 127) return;
    voice_cmd_t cmd = {0};
    memcpy(cmd.text, text, tl);
    xQueueSend(xQueueVoiceCmd, &cmd, 0);
}

static void rx_task(void *arg)
{
    uint8_t *buf = malloc(BUF_SIZE);
    if (!buf) { vTaskDelete(NULL); return; }
    static char lb[256]; static int li = 0;
    while (1) {
        int n = uart_read_bytes(UART_NUM, buf, BUF_SIZE-1, pdMS_TO_TICKS(200));
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                char c = buf[i];
                if (c == '\n')      { lb[li]=0; parse_cmd(lb, li); li=0; }
                else if (c != '\r' && li < 255) lb[li++] = c;
                else if (li >= 255) li = 0;
            }
        }
    }
}

esp_err_t app_uart_cmd_init(void)
{
    return ESP_OK;
    // 释放 GPIO11/12 的 SPI 功能（传感器接口复用为 UART）
    gpio_reset_pin(TX_PIN);
    gpio_reset_pin(RX_PIN);

    uart_config_t cfg = {
        .baud_rate = BAUD, .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE, .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE, .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM, BUF_SIZE*2, BUF_SIZE, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_NUM, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(UART_NUM, TX_PIN, RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    gpio_set_pull_mode(RX_PIN, GPIO_PULLUP_ONLY);
    // 强制确认方向（防御 uart_set_pin 未生效）
    gpio_set_direction(TX_PIN, GPIO_MODE_OUTPUT);
    gpio_set_direction(RX_PIN, GPIO_MODE_INPUT);
    gpio_dump_io_configuration(stdout, (1ULL << TX_PIN) | (1ULL << RX_PIN));
    xTaskCreate(rx_task, "uart_rx", 4096, NULL, 5, NULL);
    ESP_LOGI(TAG_UART, "UART init OK TX=GPIO%d RX=GPIO%d", TX_PIN, RX_PIN);
    return ESP_OK;
}

void app_uart_cmd_send_alert(const char *type)
{
    return;
    if (!type) return;
    char buf[64];
    int len = snprintf(buf, sizeof(buf), "ALERT:%s\n", type);
    int sent = uart_write_bytes(UART_NUM, (const uint8_t*)buf, len);
    ESP_LOGI(TAG_UART, "TX: %.*s(sent=%d/%d)", len-1, buf, sent, len);
}
