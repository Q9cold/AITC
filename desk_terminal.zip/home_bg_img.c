/**
 * @file home_bg_img.c
 * @brief 首页背景图描述符
 *
 * 像素数据由 home_bg_img.S 通过 .incbin 嵌入，编译毫秒级。
 * 尺寸: 800×400 RGB565 = 640,000 字节
 */
#include "home_bg_img.h"

/* 由 home_bg_img.S 定义 */
extern const uint8_t home_bg_img_map[];

const lv_img_dsc_t home_bg_img = {
    .header.cf          = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved    = 0,
    .header.w           = 800,
    .header.h           = 400,
    .data_size          = 800 * 400 * 2,   /* 640,000 */
    .data               = home_bg_img_map,
};
