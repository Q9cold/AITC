#pragma once
#include "lvgl.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
// 旧版：坐姿距离告警（全屏覆盖层）
lv_obj_t *ui_warning_create(void);
void ui_warning_show(float distance_cm);
void ui_warning_hide(void);
bool ui_warning_is_shown(void);
// 新版：视距/坐姿弹窗告警（可 X 关闭）
void ui_warning_show_eye(void);
void ui_warning_show_posture(void);
#ifdef __cplusplus
}
#endif
