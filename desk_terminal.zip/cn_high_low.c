#include "cn_high_low.h"
extern const uint8_t cn_high_low_map[];
const lv_img_dsc_t cn_high_low_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 76,
    .header.h = 20,
    .data_size = 3040,
    .data = cn_high_low_map,
};
