#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t cn_pear_map[];
extern const lv_img_dsc_t cn_pear_dsc;
#ifdef __cplusplus
}
#endif
