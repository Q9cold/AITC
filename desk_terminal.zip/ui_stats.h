/**
 * @file ui_stats.h
 * @brief 统计页面 — 今日告警次数、监控时长
 */

#pragma once

#include "lvgl.h"
#include "data_model.h"

#ifdef __cplusplus
extern "C" {
#endif

lv_obj_t *ui_stats_create(lv_obj_t *parent);
void ui_stats_update(const posture_stats_t *stats);

#ifdef __cplusplus
}
#endif
