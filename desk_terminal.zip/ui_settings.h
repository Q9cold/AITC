/**
 * @file ui_settings.h
 * @brief 设置页面 — 安全距离滑块、报警开关、关于信息
 */

#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

lv_obj_t *ui_settings_create(lv_obj_t *parent);

void ui_settings_update_from_remote(float safe_distance, bool alert_enabled);

/** 查询告警开关状态，false=关闭不告警 */
bool ui_settings_alert_enabled(void);

#ifdef __cplusplus
}
#endif
