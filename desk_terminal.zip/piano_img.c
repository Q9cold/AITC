/**
 * @file piano_img.c
 * @brief 钢琴图片描述符, 250×200 RGB565, 100,000 bytes
 */
#include "piano_img.h"

extern const uint8_t piano_img_map[];

const lv_img_dsc_t piano_img_dsc = {
    .header.cf          = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved    = 0,
    .header.w           = 250,
    .header.h           = 200,
    .data_size          = 250 * 200 * 2,
    .data               = piano_img_map,
};
