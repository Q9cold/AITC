#include "wd_pear_jpg.h"
extern const uint8_t wd_pear_jpg_map[];
const lv_img_dsc_t wd_pear_jpg_dsc = {
    .header.cf = LV_IMG_CF_RAW,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 200,
    .header.h = 180,
    .data_size = 15682,
    .data = wd_pear_jpg_map,
};
