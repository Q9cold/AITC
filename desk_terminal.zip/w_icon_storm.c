#include "w_icon_storm.h"
extern const uint8_t w_icon_storm_map[];
const lv_img_dsc_t w_icon_storm_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 50,
    .header.h = 50,
    .data_size = 5000,
    .data = w_icon_storm_map,
};
