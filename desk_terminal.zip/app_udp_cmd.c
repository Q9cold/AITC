/**
 * @file app_udp_cmd.c
 * @brief UDP 双向通信 — 终端 ↔ hello_esp
 *        收: CMD:xxx (语音命令)  发: ALERT:xxx (告警/音乐)
 */
#include "app_udp_cmd.h"
#include "data_model.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <stdio.h>

static const char *TAG = "udp";
#define MY_PORT   8888
#define PEER_PORT 8887
#define PEER_IP   "10.45.232.74"

static int s_rx_sock = -1;
static int s_tx_sock = -1;

static void parse_cmd(const char *line, int len)
{
    if (len < 5 || strncmp(line, "CMD:", 4)) return;
    const char *text = line + 4;
    int tl = len - 4;
    while (tl > 0 && (text[tl-1]=='\n'||text[tl-1]=='\r')) tl--;
    if (tl <= 0 || tl > 127) return;
    voice_cmd_t cmd = {0};
    memcpy(cmd.text, text, tl);
    xQueueSend(xQueueVoiceCmd, &cmd, 0);
    ESP_LOGI(TAG, "RX: \"%.*s\"", tl, text);
}

static void rx_task(void *arg)
{
    s_rx_sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in addr = { .sin_family = AF_INET, .sin_port = htons(MY_PORT), .sin_addr.s_addr = htonl(INADDR_ANY) };
    bind(s_rx_sock, (struct sockaddr *)&addr, sizeof(addr));
    int flags = fcntl(s_rx_sock, F_GETFL, 0);
    fcntl(s_rx_sock, F_SETFL, flags | O_NONBLOCK);

    s_tx_sock = socket(AF_INET, SOCK_DGRAM, 0);
    ESP_LOGI(TAG, "ready rx:%d tx→%s:%d", MY_PORT, PEER_IP, PEER_PORT);

    char buf[256], line[256]; int li = 0;
    while (1) {
        int n = recvfrom(s_rx_sock, buf, sizeof(buf)-1, 0, NULL, NULL);
        if (n > 0) {
            buf[n] = 0;
            for (int i = 0; i < n; i++) {
                char c = buf[i];
                if (c == '\n')      { line[li]=0; parse_cmd(line, li); li=0; }
                else if (c != '\r' && li < 254) line[li++] = c;
            }
        } else {
            vTaskDelay(pdMS_TO_TICKS(200));
        }
    }
}

esp_err_t app_udp_cmd_init(void)
{
    xTaskCreate(rx_task, "udp_rx", 4096, NULL, 5, NULL);
    return ESP_OK;
}

void app_udp_cmd_send_alert(const char *type)
{
    if (!type || s_tx_sock < 0) return;
    char buf[64];
    int len = snprintf(buf, sizeof(buf), "ALERT:%s\n", type);
    struct sockaddr_in peer = { .sin_family = AF_INET, .sin_port = htons(PEER_PORT) };
    inet_aton(PEER_IP, &peer.sin_addr);
    int sent = sendto(s_tx_sock, buf, len, 0,
                      (struct sockaddr *)&peer, sizeof(peer));
    if (sent < 0) ESP_LOGW(TAG, "sendto fail: %d", sent);
}
