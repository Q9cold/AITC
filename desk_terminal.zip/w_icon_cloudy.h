#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t w_icon_cloudy_map[];
extern const lv_img_dsc_t w_icon_cloudy_dsc;
#ifdef __cplusplus
}
#endif
