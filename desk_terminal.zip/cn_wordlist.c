#include "cn_wordlist.h"
extern const uint8_t cn_wordlist_map[];
const lv_img_dsc_t cn_wordlist_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 70,
    .header.h = 26,
    .data_size = 3640,
    .data = cn_wordlist_map,
};
