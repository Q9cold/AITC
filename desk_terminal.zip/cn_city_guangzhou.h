#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t cn_city_guangzhou_map[];
extern const lv_img_dsc_t cn_city_guangzhou_dsc;
#ifdef __cplusplus
}
#endif
