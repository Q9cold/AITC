/**
 * @file ui_stats.c
 * @brief 统计页面实现
 */

#include "ui_stats.h"
#include "ui_common.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdio.h>

static lv_obj_t *s_alert_count_label = NULL;
static lv_obj_t *s_monitor_time_label = NULL;
static uint32_t s_boot_ticks = 0;  // 开机时记录

lv_obj_t *ui_stats_create(lv_obj_t *parent)
{
    lv_obj_t *page = lv_obj_create(parent);
    lv_obj_set_size(page, LV_HOR_RES, LV_VER_RES - 80);
    lv_obj_set_style_bg_color(page, UI_COLOR_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(page, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(page, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_pad_all(page, 20, LV_PART_MAIN);

    // 标题
    lv_obj_t *title = ui_common_create_title(page, "Today's Stats");
    lv_obj_align(title, LV_ALIGN_TOP_LEFT, 0, 10);

    // 告警次数卡片
    lv_obj_t *card1 = ui_common_create_card(page, 350, 140);
    lv_obj_align(card1, LV_ALIGN_TOP_LEFT, 0, 60);

    lv_obj_t *icon1 = lv_label_create(card1);
    lv_label_set_text(icon1, LV_SYMBOL_BELL);
    lv_obj_set_style_text_font(icon1, &lv_font_montserrat_30, 0);
    lv_obj_align(icon1, LV_ALIGN_TOP_LEFT, 0, 10);

    lv_obj_t *label1 = lv_label_create(card1);
    lv_label_set_text(label1, "Today's Alerts");
    lv_obj_set_style_text_color(label1, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(label1, &lv_font_montserrat_16, 0);
    lv_obj_align(label1, LV_ALIGN_TOP_LEFT, 40, 12);

    s_alert_count_label = lv_label_create(card1);
    lv_label_set_text(s_alert_count_label, "0");
    lv_obj_set_style_text_color(s_alert_count_label, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(s_alert_count_label, &lv_font_montserrat_48, 0);
    lv_obj_align(s_alert_count_label, LV_ALIGN_CENTER, 0, 10);

    // 监控时长卡片
    lv_obj_t *card2 = ui_common_create_card(page, 350, 140);
    lv_obj_align(card2, LV_ALIGN_TOP_RIGHT, 0, 60);

    lv_obj_t *icon2 = lv_label_create(card2);
    lv_label_set_text(icon2, LV_SYMBOL_CHARGE);
    lv_obj_set_style_text_font(icon2, &lv_font_montserrat_30, 0);
    lv_obj_align(icon2, LV_ALIGN_TOP_LEFT, 0, 10);

    lv_obj_t *label2 = lv_label_create(card2);
    lv_label_set_text(label2, "Monitoring Time");
    lv_obj_set_style_text_color(label2, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(label2, &lv_font_montserrat_16, 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 40, 12);

    s_monitor_time_label = lv_label_create(card2);
    lv_label_set_text(s_monitor_time_label, "00:00:00");
    lv_obj_set_style_text_color(s_monitor_time_label, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(s_monitor_time_label, &lv_font_montserrat_48, 0);
    lv_obj_align(s_monitor_time_label, LV_ALIGN_CENTER, 0, 10);

    s_boot_ticks = xTaskGetTickCount();  // 记录开机时刻
    return page;
}

void ui_stats_update(const posture_stats_t *stats)
{
    // 更新告警次数（仅当有新数据时）
    if (stats && s_alert_count_label) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%lu", (unsigned long)stats->today_alert_count);
        lv_label_set_text(s_alert_count_label, buf);
        lv_color_t color = stats->today_alert_count > 0
                           ? UI_COLOR_ALERT_RED : UI_COLOR_SAFE_GREEN;
        lv_obj_set_style_text_color(s_alert_count_label, color, 0);
    }

    // 监控时长 — 无条件刷新（开机计时）
    if (s_monitor_time_label) {
        uint32_t sec = (xTaskGetTickCount() - s_boot_ticks) / configTICK_RATE_HZ;
        uint32_t h = sec / 3600;
        uint32_t m = (sec % 3600) / 60;
        uint32_t s = sec % 60;
        char buf[16];
        snprintf(buf, sizeof(buf), "%02lu:%02lu:%02lu",
                 (unsigned long)h, (unsigned long)m, (unsigned long)s);
        lv_label_set_text(s_monitor_time_label, buf);
    }
}
