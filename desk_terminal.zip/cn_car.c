#include "cn_car.h"
extern const uint8_t cn_car_map[];
const lv_img_dsc_t cn_car_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 44,
    .header.h = 24,
    .data_size = 2112,
    .data = cn_car_map,
};
