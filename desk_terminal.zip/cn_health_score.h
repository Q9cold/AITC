#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const lv_img_dsc_t cn_health_score_dsc;
#ifdef __cplusplus
}
#endif
