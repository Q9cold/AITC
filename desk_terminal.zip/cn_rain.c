#include "cn_rain.h"
extern const uint8_t cn_rain_map[];
const lv_img_dsc_t cn_rain_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 26,
    .header.h = 23,
    .data_size = 1196,
    .data = cn_rain_map,
};
