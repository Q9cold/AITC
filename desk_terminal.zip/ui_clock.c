/**
 * @file ui_clock.c
 * @brief 时钟页面实现
 */

#include "ui_clock.h"
#include "ui_common.h"
#include "app_wifi_time.h"
#include "data_model.h"
#include <stdio.h>

static lv_obj_t *s_time_label = NULL;
static lv_obj_t *s_date_label = NULL;
static lv_obj_t *s_ble_status_label = NULL;

lv_obj_t *ui_clock_create(void)
{
    lv_obj_t *page = lv_obj_create(NULL);
    lv_obj_set_size(page, LV_HOR_RES, LV_VER_RES - 80);
    lv_obj_set_style_bg_color(page, UI_COLOR_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(page, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(page, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_pad_all(page, 0, LV_PART_MAIN);

    // 时间显示（HH:MM:SS）
    s_time_label = lv_label_create(page);
    lv_label_set_text(s_time_label, "00:00:00");
    lv_obj_set_style_text_color(s_time_label, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(s_time_label, &lv_font_montserrat_48, 0);
    lv_obj_align(s_time_label, LV_ALIGN_CENTER, 0, -30);

    // 日期显示
    s_date_label = lv_label_create(page);
    lv_label_set_text(s_date_label, "----/--/-- ---");
    lv_obj_set_style_text_color(s_date_label, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(s_date_label, &lv_font_montserrat_20, 0);
    lv_obj_align(s_date_label, LV_ALIGN_CENTER, 0, 30);

    // BLE 连接状态
    s_ble_status_label = lv_label_create(page);
    lv_label_set_text(s_ble_status_label, "Searching...");
    lv_obj_set_style_text_color(s_ble_status_label, UI_COLOR_CONNECTING, 0);
    lv_obj_set_style_text_font(s_ble_status_label, &lv_font_montserrat_16, 0);
    lv_obj_align(s_ble_status_label, LV_ALIGN_CENTER, 0, 70);

    // 初始更新一次
    ui_clock_update();

    return page;
}

void ui_clock_update(void)
{
    if (!s_time_label || !s_date_label) return;

    char buf[64];

    // 更新时间
    app_get_time_str(buf, sizeof(buf), "%H:%M:%S");
    lv_label_set_text(s_time_label, buf);

    // 更新日期（中文星期格式）
    struct tm tm = app_get_local_time();
    const char *weekdays[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    snprintf(buf, sizeof(buf), "%04d/%02d/%02d %s",
             tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             weekdays[tm.tm_wday]);
    lv_label_set_text(s_date_label, buf);
}

void ui_clock_set_ble_status(bool connected)
{
    if (!s_ble_status_label) return;

    if (connected) {
        lv_label_set_text(s_ble_status_label, "PostureCam Connected");
        lv_obj_set_style_text_color(s_ble_status_label, UI_COLOR_CONNECTED, 0);
    } else {
        lv_label_set_text(s_ble_status_label, "Searching...");
        lv_obj_set_style_text_color(s_ble_status_label, UI_COLOR_CONNECTING, 0);
    }
}
