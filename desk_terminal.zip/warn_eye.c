#include "warn_eye.h"
extern const uint8_t warn_eye_map[];
const lv_img_dsc_t warn_eye_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 300,
    .header.h = 250,
    .data_size = 150000,
    .data = warn_eye_map,
};
