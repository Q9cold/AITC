#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t cn_dragonfruit_map[];
extern const lv_img_dsc_t cn_dragonfruit_dsc;
#ifdef __cplusplus
}
#endif
