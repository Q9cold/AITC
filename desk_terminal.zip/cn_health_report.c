#include "cn_health_report.h"
extern const uint8_t cn_health_report_map[];
const lv_img_dsc_t cn_health_report_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 92,
    .header.h = 26,
    .data_size = 4784,
    .data = cn_health_report_map,
};
