/**
 * @file piano_img.h
 * @brief 钢琴图片 — extern 声明, 250×200 RGB565
 */
#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t piano_img_map[];
extern const lv_img_dsc_t piano_img_dsc;
#ifdef __cplusplus
}
#endif
