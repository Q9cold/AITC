#include "cn_city_hangzhou.h"
extern const uint8_t cn_city_hangzhou_map[];
const lv_img_dsc_t cn_city_hangzhou_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 36,
    .header.h = 20,
    .data_size = 1440,
    .data = cn_city_hangzhou_map,
};
