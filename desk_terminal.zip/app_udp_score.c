/**
 * @file app_udp_score.c
 * @brief UDP 接收 PressPosture 坐姿评分数据（替代 BLE NOTIFY）
 *
 * 协议：原始 struct 字节流，按长度区分类型
 *   36 字节 → posture_scores_t（9 个 float）
 *   ≤4 字节  → press_alert_t（bool is_bad）
 */
#include "app_udp_score.h"
#include "data_model.h"
#include "esp_log.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "udp_score";
#define SCORE_PORT  8889
#define RX_BUF_SIZE 128

void app_udp_score_send_alert(const char *type);

static void rx_task(void *arg)
{
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) { ESP_LOGE(TAG, "socket fail"); vTaskDelete(NULL); return; }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port   = htons(SCORE_PORT),
        .sin_addr.s_addr = htonl(INADDR_ANY),
    };
    bind(sock, (struct sockaddr *)&addr, sizeof(addr));

    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    ESP_LOGI(TAG, "Listening UDP:%d for PressPosture scores", SCORE_PORT);

    uint8_t buf[RX_BUF_SIZE];
    while (1) {
        int n = recvfrom(sock, buf, sizeof(buf), 0, NULL, NULL);
        if (n <= 0) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }

        if (n == sizeof(posture_scores_t)) {
            posture_scores_t scores;
            memcpy(&scores, buf, sizeof(scores));
            g_last_scores = scores;
            xQueueSend(xQueuePostureScores, &scores, 0);
            static int scnt = 0;
            if (++scnt % 20 == 0)
                ESP_LOGI(TAG, "RX scores x%d h=%.0f fwd=%.0f",
                         scnt, (double)scores.health_score,
                         (double)scores.forward_lean);
        } else if (n >= (int)sizeof(press_alert_t) && n <= 4) {
            press_alert_t a;
            memcpy(&a, buf, sizeof(a));
            g_last_press_alert = a;
            xQueueSend(xQueuePressAlert, &a, 0);
            static bool last = false;
            if (a.is_bad != last) {
                last = a.is_bad;
                ESP_LOGI(TAG, "RX press: %s", a.is_bad ? "BAD" : "OK");
            }
        } else {
            ESP_LOGW(TAG, "RX %d bytes (unexpected)", n);
        }
    }
}

esp_err_t app_udp_score_init(void)
{
    xTaskCreate(rx_task, "udp_score", 4096, NULL, 5, NULL);
    return ESP_OK;
}
