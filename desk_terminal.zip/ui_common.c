/**
 * @file ui_common.c
 * @brief 公共 UI 实现
 */

#include "ui_common.h"
#include "app_wifi_time.h"
#include "esp_wifi.h"
#include "esp_log.h"
#include "cn_desktop.h"
#include "esp_heap_caps.h"
#include <string.h>

static const char *TAG_WIFI = "wifi_icon";

// ============================================================
// iOS/Android 风格 WiFi 图标 — canvas 手绘
//
// 几何关系（关键）：
//   ● 圆点与三条弧线 共用同一个圆心 (CX, CY)
//   ● 圆心位于图标底部，弧线自然向上扩散
//   ● 弧线从 225° 到 315°（即竖直向上 ±45°）
//   ● 三条弧线半径等差递增，视觉均匀
// ============================================================
#define WIFI_ICON_W  32   // 图标宽（容纳最外层弧线）
#define WIFI_ICON_H  22   // 图标高
#define WIFI_CX      16   // 圆心 X（水平居中）
#define WIFI_CY      19   // 圆心 Y（靠近底部，弧线向上展开）
#define WIFI_DOT_R    2   // 圆点半径
#define WIFI_ARC_W    3   // 弧线宽度

static lv_obj_t  *s_wifi_canvas = NULL;
static lv_color_t s_wifi_buf[WIFI_ICON_W * WIFI_ICON_H];
static int        s_last_wifi_level = -1;
static lv_obj_t  *s_rssi_label = NULL;       // RSSI 数值标签

// 直接在 canvas 缓冲区上画一个实心圆（圆心 (cx,cy)，半径 r）
static void canvas_fill_circle(lv_color_t *buf, int w, int h,
                               int cx, int cy, int r, lv_color_t c)
{
    for (int dy = -r; dy <= r; dy++) {
        for (int dx = -r; dx <= r; dx++) {
            if (dx * dx + dy * dy <= r * r) {
                int px = cx + dx, py = cy + dy;
                if (px >= 0 && px < w && py >= 0 && py < h) {
                    buf[py * w + px] = c;
                }
            }
        }
    }
}

// ============================================================
// 内部辅助：RSSI 读取与等级转换
// ============================================================
static int wifi_get_rssi(void)
{
    wifi_ap_record_t ap_info;
    if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
        return ap_info.rssi;
    }
    return -128;  // 无效值
}

static int wifi_rssi_to_level(int rssi)
{
    if (rssi >= -55) return 3;   // 强
    if (rssi >= -70) return 2;   // 中
    if (rssi >= -85) return 1;   // 弱
    return 0;                      // 无信号
}

// ============================================================
// 全局样式引用
// ============================================================
void ui_common_init(void)
{
    // 初始化默认主题（深色系）
    lv_theme_t *theme = lv_theme_default_init(NULL,
                         lv_palette_main(LV_PALETTE_BLUE),
                         lv_palette_main(LV_PALETTE_RED),
                         true, LV_FONT_DEFAULT);
    if (theme) {
        lv_disp_set_theme(NULL, theme);
    }

    // 设置屏幕背景
    lv_obj_set_style_bg_color(lv_scr_act(), UI_COLOR_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(lv_scr_act(), LV_OPA_COVER, LV_PART_MAIN);
}

lv_obj_t *ui_common_create_status_bar(lv_obj_t *parent)
{
    // 枪铁色渐变底色 + 顶部金属高光线
    lv_color_t metal_dark  = lv_color_hex(0x1C1C1E);
    lv_color_t metal_edge  = lv_color_hex(0x3A3A40);

    lv_obj_t *bar = lv_obj_create(parent);
    lv_obj_set_size(bar, LV_HOR_RES, 30);
    lv_obj_set_style_bg_color(bar, metal_dark, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(bar, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(bar, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(bar, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(bar, 0, LV_PART_MAIN);
    lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);

    // 顶部金属高光线（1px）
    lv_obj_t *edge_top = lv_obj_create(bar);
    lv_obj_set_size(edge_top, LV_HOR_RES, 1);
    lv_obj_set_style_bg_color(edge_top, metal_edge, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(edge_top, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(edge_top, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(edge_top, 0, LV_PART_MAIN);
    lv_obj_align(edge_top, LV_ALIGN_TOP_MID, 0, 0);

    // 底部金属暗线（1px）
    lv_obj_t *edge_bot = lv_obj_create(bar);
    lv_obj_set_size(edge_bot, LV_HOR_RES, 1);
    lv_obj_set_style_bg_color(edge_bot, lv_color_hex(0x0E0E10), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(edge_bot, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(edge_bot, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(edge_bot, 0, LV_PART_MAIN);
    lv_obj_align(edge_bot, LV_ALIGN_BOTTOM_MID, 0, 0);

    // ── 装饰铆钉（4 个，四角）──
    lv_color_t rivet_c = lv_color_hex(0x555560);
    for (int r = 0; r < 4; r++) {
        lv_obj_t *rivet = lv_obj_create(bar);
        lv_obj_set_size(rivet, 4, 4);
        lv_obj_set_style_radius(rivet, LV_RADIUS_CIRCLE, LV_PART_MAIN);
        lv_obj_set_style_bg_color(rivet, rivet_c, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(rivet, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_border_width(rivet, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(rivet, 0, LV_PART_MAIN);
        lv_coord_t rx = (r % 2 == 0) ? 3 : LV_HOR_RES - 7;
        lv_coord_t ry = (r < 2) ? 3 : 23;
        lv_obj_set_pos(rivet, rx, ry);
    }

    // BLE 指示灯 — 带金属外框
    lv_obj_t *ble_ring = lv_obj_create(bar);
    lv_obj_set_size(ble_ring, 14, 14);
    lv_obj_align(ble_ring, LV_ALIGN_LEFT_MID, 8, 0);
    lv_obj_set_style_radius(ble_ring, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_bg_color(ble_ring, metal_edge, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(ble_ring, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(ble_ring, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(ble_ring, 0, LV_PART_MAIN);

    lv_obj_t *ble_led = lv_led_create(ble_ring);
    lv_obj_set_size(ble_led, 8, 8);
    lv_obj_center(ble_led);
    lv_led_set_color(ble_led, UI_COLOR_CONNECTED);
    lv_led_off(ble_led);

    // 中文标题
    {
        int cw = cn_desktop_dsc.header.w;
        int ch = cn_desktop_dsc.header.h;
        lv_color_t *cbuf = heap_caps_malloc(cw * ch * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);
        if (cbuf) {
            memcpy(cbuf, cn_desktop_map, cw * ch * 2);
            lv_obj_t *cn_title = lv_canvas_create(bar);
            lv_canvas_set_buffer(cn_title, cbuf, cw, ch, LV_IMG_CF_TRUE_COLOR);
            lv_obj_set_size(cn_title, cw, ch);
            lv_obj_align(cn_title, LV_ALIGN_LEFT_MID, 28, 0);
            lv_obj_set_style_pad_all(cn_title, 0, LV_PART_MAIN);
            lv_obj_set_style_border_width(cn_title, 0, LV_PART_MAIN);
            lv_obj_set_style_bg_opa(cn_title, LV_OPA_TRANSP, LV_PART_MAIN);
        }
    }

    // RSSI + WiFi 模块面板
    s_rssi_label = lv_label_create(bar);
    lv_label_set_text(s_rssi_label, "");
    lv_obj_set_style_text_color(s_rssi_label, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(s_rssi_label, &lv_font_montserrat_12, 0);
    lv_obj_align(s_rssi_label, LV_ALIGN_RIGHT_MID, -(WIFI_ICON_W + 14), 0);

    lv_obj_t *wifi_box = lv_obj_create(bar);
    lv_obj_set_size(wifi_box, WIFI_ICON_W, WIFI_ICON_H);
    lv_obj_set_style_bg_opa(wifi_box, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(wifi_box, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(wifi_box, 0, LV_PART_MAIN);
    lv_obj_align(wifi_box, LV_ALIGN_RIGHT_MID, -8, 0);

    s_wifi_canvas = lv_canvas_create(wifi_box);
    lv_canvas_set_buffer(s_wifi_canvas, s_wifi_buf, WIFI_ICON_W, WIFI_ICON_H, LV_IMG_CF_TRUE_COLOR);
    lv_obj_set_size(s_wifi_canvas, WIFI_ICON_W, WIFI_ICON_H);
    lv_obj_align(s_wifi_canvas, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_pad_all(s_wifi_canvas, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_wifi_canvas, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_wifi_canvas, LV_OPA_TRANSP, LV_PART_MAIN);

    return bar;
}

void ui_common_update_ble_icon(lv_obj_t *status_bar, bool connected)
{
    // 遍历子对象找到 ble_ring（里面有 lv_led）
    for (int c = 0; c < lv_obj_get_child_cnt(status_bar); c++) {
        lv_obj_t *ring = lv_obj_get_child(status_bar, c);
        if (ring && lv_obj_get_child_cnt(ring) > 0) {
            lv_obj_t *led = lv_obj_get_child(ring, 0);
            if (led && lv_obj_check_type(led, &lv_led_class)) {
                if (connected) {
                    lv_led_on(led);
                    lv_led_set_color(led, UI_COLOR_CONNECTED);
                } else {
                    lv_led_off(led);
                    lv_led_set_color(led, UI_COLOR_DISCONNECTED);
                }
                return;
            }
        }
    }
}

lv_obj_t *ui_common_create_card(lv_obj_t *parent, int w, int h)
{
    lv_obj_t *card = lv_obj_create(parent);
    lv_obj_set_size(card, w, h);
    lv_obj_set_style_bg_color(card, UI_COLOR_CARD_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 12, LV_PART_MAIN);
    lv_obj_set_style_pad_all(card, 15, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);
    return card;
}

lv_obj_t *ui_common_create_title(lv_obj_t *parent, const char *text)
{
    lv_obj_t *title = lv_label_create(parent);
    lv_label_set_text(title, text);
    lv_obj_set_style_text_color(title, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_24, 0);
    return title;
}

// ============================================================
// WiFi 信号图标更新
// ============================================================
void ui_common_update_wifi_icon(lv_obj_t *status_bar)
{
    (void)status_bar;

    if (!s_wifi_canvas) return;

    int rssi = wifi_get_rssi();
    int level = wifi_rssi_to_level(rssi);

    if (level == s_last_wifi_level) return;
    s_last_wifi_level = level;

    ESP_LOGD(TAG_WIFI, "RSSI=%d -> level=%d", rssi, level);

    // 更新 RSSI 数值标签
    if (s_rssi_label) {
        char rssi_buf[8];
        snprintf(rssi_buf, sizeof(rssi_buf), "%ddBm", rssi);
        lv_label_set_text(s_rssi_label, rssi_buf);
    }

    if (level < 0) level = 0;
    if (level > 3) level = 3;

    // ---- 1. 填充状态栏底色 ----
    lv_canvas_fill_bg(s_wifi_canvas, UI_COLOR_ACCENT, LV_OPA_COVER);

    // ---- 2. 信号颜色 ----
    lv_color_t active, grey = lv_color_make(0x66, 0x66, 0x66);
    switch (level) {
        case 3: active = lv_color_make(0x00, 0xE6, 0x76); break; // 强·绿
        case 2: active = lv_color_make(0xFF, 0xD7, 0x40); break; // 中·黄
        case 1: active = lv_color_make(0xFF, 0x17, 0x44); break; // 弱·红
        default: active = grey; break;                              // 无·灰
    }

    // ---- 3. 三条同心弧线（共用圆心 WIFI_CX,WIFI_CY，半径 5/9/13）----
    // 角度 225°→315°：从左上跨越正上方到右上（竖直向上 ±45°）
    // 10 倍放大：2250 → 3150
    static const int arc_radii[] = {5, 9, 13};

    lv_draw_arc_dsc_t dsc;
    lv_draw_arc_dsc_init(&dsc);
    dsc.width   = WIFI_ARC_W;
    dsc.rounded = 1;

    for (int i = 0; i < 3; i++) {
        bool on = (i < level);                     // level=3→全亮, 2→2条, 1→1条, 0→全灰
        dsc.color = on ? active : grey;
        lv_canvas_draw_arc(s_wifi_canvas, WIFI_CX, WIFI_CY,
                           arc_radii[i], 2250, 3150, &dsc);
    }

    // ---- 4. 圆点（与弧线共圆心）----
    lv_color_t dot_color = (level > 0) ? active : grey;
    canvas_fill_circle(s_wifi_buf, WIFI_ICON_W, WIFI_ICON_H,
                       WIFI_CX, WIFI_CY, WIFI_DOT_R, dot_color);

    // ---- 5. 刷新 ----
    lv_obj_invalidate(s_wifi_canvas);
}
