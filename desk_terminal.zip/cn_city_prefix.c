#include "cn_city_prefix.h"
extern const uint8_t cn_city_prefix_map[];
const lv_img_dsc_t cn_city_prefix_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 52,
    .header.h = 20,
    .data_size = 2080,
    .data = cn_city_prefix_map,
};
