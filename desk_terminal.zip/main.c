/*
 * SPDX-FileCopyrightText: 2023-2024 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

/**
 * @file main.c
 * @brief 坐姿监测控制终端 — 入口文件
 *
 * 初始化顺序：
 * 1. NVS Flash（WiFi/BLE 参数存储）
 * 2. WiFi STA + SNTP 时间同步
 * 3. 显示面板（LCD + Touch + LVGL）
 * 4. 数据模型（FreeRTOS 队列 x5）
 * 5. BLE Central Client（双连接：PostureCam + PressureMat）
 * 6. UART 命令接收（从 hello_esp 接收语音识别命令）
 * 7. UI 管理器（LVGL 屏幕 + 数据轮询）
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "waveshare_rgb_lcd_port.h"
#include "lvgl_port.h"
#include "data_model.h"
#include "app_wifi_time.h"
#include "app_ble_client.h"
#include "app_uart_cmd.h"
#include "app_i2c_cmd.h"
#include "app_udp_cmd.h"
#include "app_udp_score.h"
#include "app_weather.h"
#include "ui_manager.h"

static const char *TAG = "app_main";

void app_main(void)
{
    // esp_log_level_set("*", ESP_LOG_NONE);   // 临时开启，验证后改回

    // 1. NVS Flash 初始化（WiFi/BLE/设置都需要）
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }

    // 2. WiFi + NTP 时间同步（非阻塞：失败不影响系统运行）
    app_wifi_time_init();

    // 3. 显示面板初始化（LCD + Touch + LVGL）
    ESP_LOGI(TAG, "Initializing display...");
    waveshare_esp32_s3_rgb_lcd_init();
    ESP_LOGI(TAG, "Display initialized");

    // 4. 数据模型初始化（队列）
    data_model_init();

    // 5. BLE Central Client（扫描并连接 PostureCam + PressureMat）
    app_ble_client_init();

    // 6. I2C 命令通信（从 hello_esp I2C 从机接收语音识别命令）
    app_i2c_cmd_init();

    // 6b. UART 命令通信（AUX 辅助通道）
    app_uart_cmd_init();

    // 6c. UDP 命令通信（WiFi 通道 → hello_esp）
    app_udp_cmd_init();

    // 6d. UDP 坐姿评分接收（WiFi 通道 ← PressPosture）
    app_udp_score_init();

    // 6e. 天气获取
    app_weather_init();

    // 7. UI 管理器（LVGL 屏幕 + 数据轮询）
    //    LVGL 锁内创建 UI
    // -1 = 无限等待，确保 LVGL 任务已启动并释放互斥锁
    if (lvgl_port_lock(-1)) {
        ui_manager_init();
        lvgl_port_unlock();
    }

    ESP_LOGI(TAG, "Posture Terminal started successfully");
}
