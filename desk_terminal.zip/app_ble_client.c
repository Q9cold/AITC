/**
 * @file app_ble_client.c
 * @brief BLE Central — 扫描连接 PressPosture，接收 9 维坐姿评分
 */
#include "app_ble_client.h"
#include "data_model.h"
#include "esp_log.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "host/ble_hs_adv.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "ble_client";

#define DEV_NAME              "PressPosture"
#define BLE_CHR_UUID_SCORES   0x4F21

static uint16_t  s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
static uint16_t  s_chr_handle  = 0;
static bool      s_connected   = false;
static bool      s_notify_ok   = false;
static bool      s_scanning    = false;

static const ble_uuid16_t g_chr_uuid = BLE_UUID16_INIT(BLE_CHR_UUID_SCORES);

extern void ble_store_config_init(void);

static void start_scan(void);
static int  gap_event_cb(struct ble_gap_event *e, void *arg);

// ============================================================
// 订阅 Notify（写 CCCD）
// ============================================================
static void enable_notify(void)
{
    ESP_LOGI(TAG, "Enable notify...");
    uint8_t v[2] = {0x01, 0x00};
    int rc = ble_gattc_write_flat(s_conn_handle, s_chr_handle + 1,
                                  v, 2, NULL, NULL);
    if (rc == 0) {
        s_notify_ok = true;
        ESP_LOGI(TAG, "Notify enabled.");
    } else {
        ESP_LOGW(TAG, "CCCD write err: %d", rc);
    }
}

// ============================================================
// 特征发现回调
// ============================================================
static int chr_disc_cb(uint16_t h, const struct ble_gatt_error *err,
                        const struct ble_gatt_chr *chr, void *arg)
{
    if (err->status == BLE_HS_EDONE) {
        if (s_chr_handle == 0) {
            ESP_LOGW(TAG, "Score char (0x4F21) not found");
        } else {
            enable_notify();
        }
        return 0;
    }
    if (err->status)  { ESP_LOGE(TAG, "Chr disc err: %d", err->status); return 0; }
    if (!chr) return 0;

    // 打印每个发现的特征
    ESP_LOGI(TAG, "  [%d] UUID=0x%04X prop=0x%02X val_h=%d",
             h, (unsigned)chr->uuid.u16.value,
             (unsigned)chr->properties, chr->val_handle);

    if (ble_uuid_cmp(&chr->uuid.u, &g_chr_uuid.u) == 0) {
        s_chr_handle = chr->val_handle;
        ESP_LOGI(TAG, "MATCH score characteristic handle=%d", s_chr_handle);
    }
    return 0;
}

// ============================================================
// GAP 事件回调
// ============================================================
static int gap_event_cb(struct ble_gap_event *e, void *arg)
{
    switch (e->type) {

    case BLE_GAP_EVENT_CONNECT:
        if (e->connect.status == 0) {
            s_conn_handle = e->connect.conn_handle;
            s_connected = true;
            data_model_set_ble_status(BLE_STATUS_CONNECTED);
            ble_gap_disc_cancel(); s_scanning = false;
            ESP_LOGI(TAG, "Connected to PressPosture");
            ble_gattc_disc_all_chrs(s_conn_handle, 1, 0xFFFF,
                                    chr_disc_cb, NULL);
        } else {
            ESP_LOGW(TAG, "Connect fail: %d", e->connect.status);
            start_scan();
        }
        break;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "Disconnected (%d)", e->disconnect.reason);
        s_connected  = false;
        s_notify_ok  = false;
        s_chr_handle = 0;
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        data_model_set_ble_status(BLE_STATUS_DISCONNECTED);
        vTaskDelay(pdMS_TO_TICKS(2000));
        start_scan();
        break;

    case BLE_GAP_EVENT_DISC:
        if (e->disc.event_type != BLE_HCI_ADV_RPT_EVTYPE_ADV_IND &&
            e->disc.event_type != BLE_HCI_ADV_RPT_EVTYPE_DIR_IND) break;
        {
            struct ble_hs_adv_fields f;
            char name[32] = {0};
            int rc = ble_hs_adv_parse_fields(&f, e->disc.data,
                                             e->disc.length_data);
            if (rc == 0 && f.name && f.name_len > 0) {
                int nl = f.name_len < 31 ? f.name_len : 31;
                memcpy(name, f.name, nl); name[nl] = 0;
            }
            if (!name[0]) break;
            if (strcmp(name, DEV_NAME)) break;
            if (s_connected) break;

            // 仅连接 10:b4:1d:ca:86:fe
            static const uint8_t target[6] =
                {0xfe,0x86,0xca,0x1d,0xb4,0x10};
            if (memcmp(e->disc.addr.val, target, 6)) break;

            ESP_LOGI(TAG, "Connecting to PressPosture...");
            ble_gap_disc_cancel(); s_scanning = false;
            uint8_t oat; ble_hs_id_infer_auto(0, &oat);
            ble_gap_connect(oat, &e->disc.addr, 30000, NULL,
                            gap_event_cb, NULL);
        }
        break;

    case BLE_GAP_EVENT_NOTIFY_RX:
        if (e->notify_rx.attr_handle == s_chr_handle) {
            struct os_mbuf *om = e->notify_rx.om;
            uint16_t len = OS_MBUF_PKTLEN(om);

            if (len == sizeof(posture_scores_t)) {
                os_mbuf_copydata(om, 0, sizeof(posture_scores_t),
                                 &g_last_scores);
                xQueueSend(xQueuePostureScores, &g_last_scores, 0);
                // 每秒最多打一条
                static int score_cnt = 0;
                if (++score_cnt % 20 == 0)
                    ESP_LOGI(TAG, "RX scores (%d pkts)", score_cnt);
            } else if (len >= sizeof(press_alert_t)) {
                press_alert_t a;
                os_mbuf_copydata(om, 0, sizeof(a), &a);
                g_last_press_alert = a;
                xQueueSend(xQueuePressAlert, &a, 0);
                // 压力告警仅状态变化时打印
                static bool last_press = false;
                if (a.is_bad != last_press) {
                    last_press = a.is_bad;
                    ESP_LOGI(TAG, "Press: %s", a.is_bad ? "BAD" : "OK");
                }
            }
        }
        break;

    case BLE_GAP_EVENT_SUBSCRIBE:
        ESP_LOGI(TAG, "Subscribe: h=%d notify=%d",
                 e->subscribe.attr_handle,
                 e->subscribe.cur_notify);
        break;
    }
    return 0;
}

// ============================================================
// NimBLE 栈回调
// ============================================================
static void on_sync(void)
{
    ble_hs_util_ensure_addr(0);
    start_scan();
}
static void on_reset(int r) { ESP_LOGE(TAG, "Reset: %d", r); }
static void host_task(void *a) { nimble_port_run(); }

static void start_scan(void)
{
    if (s_scanning || s_connected) return;
    uint8_t oat; ble_hs_id_infer_auto(0, &oat);
    struct ble_gap_disc_params p = {0};
    p.filter_duplicates = 1; p.passive = 0;
    int rc = ble_gap_disc(oat, BLE_HS_FOREVER, &p, gap_event_cb, NULL);
    if (rc == 0) {
        s_scanning = true;
        data_model_set_ble_status(BLE_STATUS_CONNECTING);
        ESP_LOGI(TAG, "Scanning for PressPosture...");
    } else {
        ESP_LOGE(TAG, "Scan err: %d", rc);
    }
}

// ============================================================
// 公开 API
// ============================================================
void app_ble_client_init(void)
{
    nimble_port_init();
    ble_hs_cfg.reset_cb = on_reset;
    ble_hs_cfg.sync_cb  = on_sync;
    ble_store_config_init();
    nimble_port_freertos_init(host_task);

    // 自广播 "PostureTerminal"
    struct ble_hs_adv_fields adv = {0};
    adv.name = (uint8_t *)"PostureTerminal";
    adv.name_len = 15; adv.name_is_complete = 1;
    ble_gap_adv_set_fields(&adv);
    struct ble_gap_adv_params ap = {0};
    ap.conn_mode = BLE_GAP_CONN_MODE_UND;
    ap.disc_mode = BLE_GAP_DISC_MODE_GEN;
    ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC, NULL, BLE_HS_FOREVER,
                      &ap, NULL, NULL);

    ESP_LOGI(TAG, "BLE Central ready");
}

bool app_ble_client_is_connected(void) { return s_connected; }
