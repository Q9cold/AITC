#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t wd_apple_map[];
extern const lv_img_dsc_t wd_apple_dsc;
#ifdef __cplusplus
}
#endif
