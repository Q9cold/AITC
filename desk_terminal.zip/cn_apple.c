#include "cn_apple.h"
extern const uint8_t cn_apple_map[];
const lv_img_dsc_t cn_apple_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 44,
    .header.h = 23,
    .data_size = 2024,
    .data = cn_apple_map,
};
