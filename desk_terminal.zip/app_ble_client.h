/**
 * @file app_ble_client.h
 * @brief BLE Central Client — 扫描并连接 PressPosture
 */
#pragma once
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
void app_ble_client_init(void);
bool app_ble_client_is_connected(void);
#ifdef __cplusplus
}
#endif
