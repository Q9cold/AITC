#include "wd_dragonfruit_jpg.h"
extern const uint8_t wd_dragonfruit_jpg_map[];
const lv_img_dsc_t wd_dragonfruit_jpg_dsc = {
    .header.cf = LV_IMG_CF_RAW,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 200,
    .header.h = 180,
    .data_size = 15313,
    .data = wd_dragonfruit_jpg_map,
};
