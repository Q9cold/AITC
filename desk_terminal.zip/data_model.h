/**
 * @file data_model.h
 * @brief 中央数据模型 — BLE 与 UI 之间的数据总线
 *
 * 使用 FreeRTOS 队列解耦 BLE Client 任务和 LVGL UI 任务。
 * BLE 收到通知后写入队列，UI 通过 lv_timer 读取队列更新画面。
 */

#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// 数据类型
// ============================================================

typedef struct {
    float    distance_cm;
    bool     is_safe;
    bool     is_alerting;
    bool     alert_enabled;
    float    safe_distance_cm;
    uint32_t sequence_number;
} posture_data_t;

typedef struct {
    uint32_t today_alert_count;
    uint32_t monitoring_time_seconds;
} posture_stats_t;

typedef struct {
    float safe_distance_cm;
    bool  alert_enabled;
} config_write_t;

// BLE 连接状态
typedef enum {
    BLE_STATUS_DISCONNECTED = 0,
    BLE_STATUS_CONNECTING,
    BLE_STATUS_CONNECTED,
} ble_conn_status_t;

// 语音命令（hello_esp UART → UI）
typedef struct {
    char text[128];  // 中文命令文本，如 "打开灯光"
} voice_cmd_t;

// 压力报警状态（press BLE → UI）
typedef struct {
    bool is_bad;     // true=坐姿不正, false=正常
} press_alert_t;

// 9 维坐姿评分（PressPosture BLE → UI）
typedef struct {
    float forward_lean;
    float backward_lean;
    float lateral_lean;
    float head_twist;
    float pressure_balance;
    float pressure_center;
    float pressure_uniform;
    float posture_stability;
    float health_score;
} posture_scores_t;

// ============================================================
// 全局队列（由 data_model_init 创建）
// ============================================================
extern QueueHandle_t xQueuePostureData;   // posture_data_t,  BLE → UI
extern QueueHandle_t xQueuePostureStats;  // posture_stats_t, BLE → UI
extern QueueHandle_t xQueueConfigWrite;   // config_write_t,  UI  → BLE
extern QueueHandle_t xQueueVoiceCmd;      // voice_cmd_t,     UART → UI
extern QueueHandle_t xQueuePressAlert;    // press_alert_t,   BLE → UI
extern QueueHandle_t xQueuePostureScores; // posture_scores_t,BLE → UI

// ============================================================
// 全局状态（缓存的最近一次数据）
// ============================================================
extern posture_data_t  g_last_posture;
extern posture_stats_t g_last_stats;
extern ble_conn_status_t g_ble_status;
extern press_alert_t  g_last_press_alert;
extern posture_scores_t g_last_scores;

// ============================================================
// API
// ============================================================

/**
 * @brief 初始化数据模型（创建 FreeRTOS 队列）
 */
void data_model_init(void);

/**
 * @brief 获取缓存的坐姿数据
 */
const posture_data_t *data_model_get_posture(void);

/**
 * @brief 获取缓存的统计数据
 */
const posture_stats_t *data_model_get_stats(void);

/**
 * @brief 更新 BLE 连接状态
 */
void data_model_set_ble_status(ble_conn_status_t status);

/**
 * @brief 获取 BLE 连接状态
 */
ble_conn_status_t data_model_get_ble_status(void);

/**
 * @brief 将配置写入队列（UI 触发，BLE 任务处理）
 */
bool data_model_queue_config(const config_write_t *cfg);

#ifdef __cplusplus
}
#endif
