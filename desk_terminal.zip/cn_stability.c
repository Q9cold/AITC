#include "cn_stability.h"
extern const uint8_t cn_stability_map[];
const lv_img_dsc_t cn_stability_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 94,
    .header.h = 21,
    .data_size = 3948,
    .data = cn_stability_map,
};
