#include "cn_dragonfruit.h"
extern const uint8_t cn_dragonfruit_map[];
const lv_img_dsc_t cn_dragonfruit_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 58,
    .header.h = 21,
    .data_size = 2436,
    .data = cn_dragonfruit_map,
};
