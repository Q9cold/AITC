/**
 * @file app_i2c_cmd.h
 * @brief I2C 主站通信 — 与 hello_esp 通过 I2C 双向通信
 *
 * 终端 (I2C Master) ↔ hello_esp (I2C Slave, 地址 0x2A)
 *
 * 读操作：获取语音命令 [len:1B][text:len_bytes]
 * 写操作：发送告警 [alert:1B] (0=无, 1=摄像头坐姿, 2=压力坐垫)
 */

#pragma once
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 I2C 命令通信
 *
 * 创建轮询任务，定期从 hello_esp 读取语音命令，
 * 推送到 xQueueVoiceCmd 队列。
 */
esp_err_t app_i2c_cmd_init(void);

/**
 * @brief 发送告警到 hello_esp
 * @param alert  0=无告警, 1=摄像头坐姿告警, 2=压力坐垫告警
 */
void app_i2c_cmd_send_alert(uint8_t alert);

#ifdef __cplusplus
}
#endif
