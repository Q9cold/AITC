/**
 * @file ui_home.c
 * @brief 首页实现 — 儿童友好桌面
 *
 * 布局：
 *   ┌──────────────────────────────┐
 *   │   (儿童卡通背景图 800×400)    │
 *   │   ┌──────────────────────┐   │
 *   │   │     14:32:15         │   │  半透明时钟卡片
 *   │   │  2026/06/30 Mon      │   │
 *   │   └──────────────────────┘   │
 *   │   [♫ Play] [▶ Anim] [🔔 Alerts] │  三个功能按钮
 *   │      PostureCam Connected    │  BLE 状态
 *   └──────────────────────────────┘
 */

#include "ui_home.h"
#include "ui_common.h"
#include "app_udp_cmd.h"
#include "app_weather.h"
#include "home_bg_img.h"
#include "piano_jpg.h"
#include "app_wifi_time.h"
#include "data_model.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "cn_apple.h"
#include "cn_banana.h"
#include "cn_pear.h"
#include "cn_dragonfruit.h"
#include "cn_car.h"
#include "cn_dragon.h"
#include "wd_apple_jpg.h"
#include "wd_banana_jpg.h"
#include "wd_pear_jpg.h"
#include "wd_dragonfruit_jpg.h"
#include "wd_car_jpg.h"
#include "wd_dragon_jpg.h"
#include "note_q.h"
#include "note_e.h"
#include "note_be.h"
#include "cn_health_report.h"
#include "cn_forward.h"
#include "cn_backward.h"
#include "cn_lateral.h"
#include "cn_head_twist.h"
#include "cn_press_bal.h"
#include "cn_press_ctr.h"
#include "cn_press_unif.h"
#include "cn_stability.h"
#include "cn_health_score.h"
#include "cn_eye_warn.h"
#include "cn_posture_warn.h"
#include "warn_eye.h"
#include "warn_posture.h"
#include "cn_sunny.h"
#include "cn_cloudy.h"
#include "cn_fog.h"
#include "cn_rain.h"
#include "cn_snow.h"
#include "cn_storm.h"
#include "cn_feels_like.h"
#include "cn_humidity.h"
#include "cn_wind.h"
#include "cn_high_low.h"
#include "cn_precip.h"
#include "cn_city_prefix.h"
#include "cn_city_beijing.h"
#include "cn_city_shanghai.h"
#include "cn_city_zhengzhou.h"
#include "cn_city_guangzhou.h"
#include "cn_city_shenzhen.h"
#include "cn_city_hangzhou.h"
#include "cn_city_chengdu.h"
#include "cn_city_wuhan.h"
#include "cn_city_nanjing.h"
#include "cn_city_xian.h"
#include "w_icon_sunny.h"
#include "w_icon_cloudy.h"
#include "w_icon_rain.h"
#include "w_icon_storm.h"
#include <stdio.h>
#include <string.h>

static const char *TAG = "ui_home";

// ============================================================
// 首页专用色彩（儿童友好亮色调）
// ============================================================
#define HOME_COLOR_SKY_BLUE     lv_color_hex(0x4FC3F7)   // 音乐按钮
#define HOME_COLOR_MINT_GREEN   lv_color_hex(0x81C784)   // 动画按钮
#define HOME_COLOR_WARM_CORAL   lv_color_hex(0xFF8A65)   // 告警按钮
#define HOME_COLOR_GOLDEN       lv_color_hex(0xFFD54F)   // BLE 搜索中
#define HOME_COLOR_BG_FALLBACK  lv_color_hex(0xFF1493)   // 亮粉色诊断，确认页面渲染

// ============================================================
// 静态控件引用
// ============================================================
static lv_obj_t *s_time_label = NULL;
static lv_obj_t *s_date_label = NULL;
static lv_obj_t *s_ble_label = NULL;
static lv_obj_t *s_posture_circle = NULL;
static lv_obj_t *s_weather_card = NULL;
static lv_obj_t *s_weather_temp = NULL;
static lv_obj_t *s_weather_desc = NULL;
static lv_obj_t *s_weather_humi = NULL;
static lv_obj_t *s_weather_icon = NULL;         // 天气图标
static lv_obj_t *s_weather_overlay = NULL;       // 天气详情弹窗

// ============================================================
// 音乐播放器弹窗
// ============================================================
static lv_obj_t *s_music_overlay = NULL;

static void music_close_cb(lv_event_t *e)
{
    if (s_music_overlay) {
        lv_obj_add_flag(s_music_overlay, LV_OBJ_FLAG_HIDDEN);
    }
}

static void music_popup_create(void)
{
    // 全屏半透明遮罩
    s_music_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_music_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_music_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_music_overlay, LV_OPA_50, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_music_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_music_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_music_overlay, music_close_cb, LV_EVENT_CLICKED, NULL);

    // 居中卡片 540×330（约 2/3 屏幕）
    lv_obj_t *card = lv_obj_create(s_music_overlay);
    lv_obj_set_size(card, 540, 330);
    lv_obj_align(card, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(card, UI_COLOR_CARD_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 20, LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 2, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, UI_COLOR_ACCENT, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_pad_all(card, 15, LV_PART_MAIN);

    // ── 五线谱音符装饰（预渲染图片）──
    static const lv_img_dsc_t *note_imgs[] = {
        &note_q_dsc, &note_e_dsc, &note_be_dsc,
        &note_q_dsc, &note_e_dsc, &note_be_dsc,
    };
    static int note_px[] = {20, 110, 210, 310, 400, 480};
    for (int ni = 0; ni < 6; ni++) {
        // 上边
        lv_obj_t *n1 = lv_img_create(card);
        lv_img_set_src(n1, note_imgs[ni]);
        lv_obj_set_pos(n1, note_px[ni], 0);
        lv_obj_set_style_img_opa(n1, LV_OPA_50, 0);
        // 下边（镜像用同一个）
        lv_obj_t *n2 = lv_img_create(card);
        lv_img_set_src(n2, note_imgs[ni]);
        lv_obj_set_pos(n2, note_px[ni], 302);
        lv_obj_set_style_img_opa(n2, LV_OPA_50, 0);
    }

    // ---- 关闭按钮（右上角 X）----
    lv_obj_t *close_btn = lv_btn_create(card);
    lv_obj_set_size(close_btn, 32, 32);
    lv_obj_align(close_btn, LV_ALIGN_TOP_RIGHT, -5, 5);
    lv_obj_set_style_bg_color(close_btn, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(close_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *close_x = lv_label_create(close_btn);
    lv_label_set_text(close_x, LV_SYMBOL_CLOSE);
    lv_obj_set_style_text_color(close_x, lv_color_white(), 0);
    lv_obj_center(close_x);
    lv_obj_add_event_cb(close_btn, music_close_cb, LV_EVENT_CLICKED, NULL);

    // ---- 标题 ----
    lv_obj_t *title = lv_label_create(card);
    lv_label_set_text(title, "Music Player");
    lv_obj_set_style_text_color(title, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_24, 0);
    lv_obj_align(title, LV_ALIGN_TOP_LEFT, 0, 10);

    // ---- 左侧：钢琴图 (SJPG) ----
    lv_obj_t *pimg = lv_img_create(card);
    lv_img_set_src(pimg, &piano_jpg_dsc);
    lv_obj_align(pimg, LV_ALIGN_LEFT_MID, 10, 20);

    // ---- 右侧：歌曲信息面板 ----
    lv_obj_t *info = lv_obj_create(card);
    lv_obj_set_size(info, 240, 270);
    lv_obj_align(info, LV_ALIGN_RIGHT_MID, -10, 20);
    lv_obj_set_style_bg_opa(info, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(info, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(info, 10, LV_PART_MAIN);
    lv_obj_clear_flag(info, LV_OBJ_FLAG_SCROLLABLE);

    // 歌曲名称 - 大号
    lv_obj_t *song = lv_label_create(info);
    lv_label_set_text(song, "Summer");
    lv_obj_set_style_text_color(song, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(song, &lv_font_montserrat_30, 0);
    lv_obj_align(song, LV_ALIGN_TOP_LEFT, 0, 10);

    // 艺术家
    lv_obj_t *artist = lv_label_create(info);
    lv_label_set_text(artist, "Joe Hisaishi");
    lv_obj_set_style_text_color(artist, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(artist, &lv_font_montserrat_20, 0);
    lv_obj_align(artist, LV_ALIGN_TOP_LEFT, 0, 55);

    // 专辑
    lv_obj_t *album = lv_label_create(info);
    lv_label_set_text(album, "Album: Kikujiro OST");
    lv_obj_set_style_text_color(album, UI_COLOR_SAFE_GREEN, 0);
    lv_obj_set_style_text_font(album, &lv_font_montserrat_16, 0);
    lv_obj_align(album, LV_ALIGN_TOP_LEFT, 0, 95);

    // 年份 & 风格
    lv_obj_t *year = lv_label_create(info);
    lv_label_set_text(year, "Year: 1999\nStyle: Piano / New Age");
    lv_obj_set_style_text_color(year, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(year, &lv_font_montserrat_14, 0);
    lv_obj_align(year, LV_ALIGN_TOP_LEFT, 0, 130);

    // 描述
    lv_obj_t *desc = lv_label_create(info);
    lv_label_set_text(desc,
        "\"Summer\" is one of the most\n"
        "beloved piano pieces from\n"
        "the movie Kikujiro (1999).\n"
        "Its light, breezy melody\n"
        "evokes the joy of childhood\n"
        "summer days.");
    lv_obj_set_style_text_color(desc, lv_color_hex(0xBBBBBB), 0);
    lv_obj_set_style_text_font(desc, &lv_font_montserrat_12, 0);
    lv_obj_align(desc, LV_ALIGN_TOP_LEFT, 0, 175);

    ESP_LOGI(TAG, "Music popup created");
}

// ============================================================
// 按钮回调
// ============================================================
static void btn_music_cb(lv_event_t *e)
{
    ESP_LOGI(TAG, "Play Music pressed");
    // 通过 UDP 发送音乐命令到 hello_esp
    app_udp_cmd_send_alert("music");
    if (!s_music_overlay) {
        music_popup_create();
    }
    if (s_music_overlay) {
        lv_obj_clear_flag(s_music_overlay, LV_OBJ_FLAG_HIDDEN);
    }
}

// ============================================================
// 单词表翻页弹窗
// ============================================================
static lv_obj_t *s_word_overlay = NULL;
static int s_word_page = 0;
static void word_popup_show(void);  // 前置声明

typedef struct {
    const char        *en;
    const char        *pos;
    const char        *audio;
    const lv_img_dsc_t *img;
    const lv_img_dsc_t *cn;
} word_t;

static const word_t s_words[] = {
    {"Apple",  "n. noun", "apple",    &wd_apple_jpg_dsc,        &cn_apple_dsc},
    {"Banana", "n. noun", "banana",   &wd_banana_jpg_dsc,       &cn_banana_dsc},
    {"Pear",   "n. noun", "pear",     &wd_pear_jpg_dsc,         &cn_pear_dsc},
    {"Dragon\nFruit","n. noun","dragonfruit", &wd_dragonfruit_jpg_dsc,&cn_dragonfruit_dsc},
    {"Car",    "n. noun", "car",      &wd_car_jpg_dsc,          &cn_car_dsc},
    {"Dragon", "n. noun", "dragon",   &wd_dragon_jpg_dsc,       &cn_dragon_dsc},
};
#define WORD_COUNT (sizeof(s_words) / sizeof(s_words[0]))

static void word_close_cb(lv_event_t *e)
{
    if (s_word_overlay) lv_obj_add_flag(s_word_overlay, LV_OBJ_FLAG_HIDDEN);
}

// 延迟翻页（避免在按钮回调中删除自身所在的控件树）
static void word_flip_timer_cb(lv_timer_t *timer)
{
    int dir = (int)(intptr_t)timer->user_data;
    s_word_page += dir;
    if (s_word_page < 0) s_word_page = WORD_COUNT - 1;
    if (s_word_page >= (int)WORD_COUNT) s_word_page = 0;
    word_popup_show();
}

// 喇叭按钮 — 通过 UDP 让语音模块播放对应单词音频
static void word_speaker_cb(lv_event_t *e)
{
    const char *word = (const char *)lv_event_get_user_data(e);
    ESP_LOGI(TAG, "Speaker: %s", word);
    // 发送 UDP 命令播放单词音频: CMD:word_apple → rsp_apple.wav
    char cmd[48];
    snprintf(cmd, sizeof(cmd), "word_%s", word);
    app_udp_cmd_send_alert(cmd);  // 复用 ALERT 通道, hello_esp 端映射到 WAV
}

static void word_page_flip(lv_event_t *e)
{
    int dir = (int)(intptr_t)lv_event_get_user_data(e);
    lv_timer_t *t = lv_timer_create(word_flip_timer_cb, 50, (void *)(intptr_t)dir);
    lv_timer_set_repeat_count(t, 1);
}

static void word_popup_show(void)
{
    if (s_word_overlay) {
        lv_obj_del(s_word_overlay);
        s_word_overlay = NULL;
    }

    const word_t *w = &s_words[s_word_page];

    // 遮罩
    s_word_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_word_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_word_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_word_overlay, LV_OPA_50, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_word_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_word_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_word_overlay, word_close_cb, LV_EVENT_CLICKED, NULL);

    // ── 书本 580×360 ──
    lv_color_t cover_c = lv_color_hex(0x4A2F1A);
    lv_color_t page_c  = lv_color_hex(0xFDF8F0);
    lv_color_t shadow_c = lv_color_hex(0xC8C0B0);
    lv_obj_t *book = lv_obj_create(s_word_overlay);
    lv_obj_set_size(book, 580, 360);
    lv_obj_align(book, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(book, cover_c, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(book, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(book, 14, LV_PART_MAIN);
    lv_obj_set_style_border_width(book, 3, LV_PART_MAIN);
    lv_obj_set_style_border_color(book, lv_color_hex(0x5A3D28), LV_PART_MAIN);
    lv_obj_set_style_pad_all(book, 10, LV_PART_MAIN);
    lv_obj_clear_flag(book, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_shadow_width(book, 24, LV_PART_MAIN);
    lv_obj_set_style_shadow_color(book, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_shadow_opa(book, LV_OPA_70, LV_PART_MAIN);

    // ── 书签带（顶部红色标签）──
    lv_obj_t *ribbon = lv_obj_create(book);
    lv_obj_set_size(ribbon, 30, 20);
    lv_obj_set_style_bg_color(ribbon, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(ribbon, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(ribbon, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(ribbon, 0, LV_PART_MAIN);
    lv_obj_align(ribbon, LV_ALIGN_TOP_MID, 0, -12);

    // ── 左页 260×320 ──
    lv_obj_t *left_page = lv_obj_create(book);
    lv_obj_set_size(left_page, 260, 320);
    lv_obj_align(left_page, LV_ALIGN_LEFT_MID, 8, 0);
    lv_obj_set_style_bg_color(left_page, page_c, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(left_page, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(left_page, 3, LV_PART_MAIN);
    lv_obj_set_style_border_width(left_page, 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(left_page, lv_color_hex(0xD8D0C4), LV_PART_MAIN);
    lv_obj_set_style_pad_all(left_page, 12, LV_PART_MAIN);
    lv_obj_clear_flag(left_page, LV_OBJ_FLAG_SCROLLABLE);
    // 页内侧阴影（书脊方向）
    lv_obj_t *l_shadow = lv_obj_create(left_page);
    lv_obj_set_size(l_shadow, 6, 296);
    lv_obj_align(l_shadow, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_set_style_bg_color(l_shadow, shadow_c, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(l_shadow, LV_OPA_30, LV_PART_MAIN);
    lv_obj_set_style_border_width(l_shadow, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(l_shadow, 0, LV_PART_MAIN);

    // ── 书脊 ──
    lv_obj_t *spine = lv_obj_create(book);
    lv_obj_set_size(spine, 6, 304);
    lv_obj_align(spine, LV_ALIGN_CENTER, 0, -4);
    lv_obj_set_style_bg_color(spine, lv_color_hex(0x2A1808), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(spine, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(spine, 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(spine, lv_color_hex(0x1A0C00), LV_PART_MAIN);
    lv_obj_set_style_radius(spine, 2, LV_PART_MAIN);

    // ── 右页 260×320 ──
    lv_obj_t *right_page = lv_obj_create(book);
    lv_obj_set_size(right_page, 260, 320);
    lv_obj_align(right_page, LV_ALIGN_RIGHT_MID, -8, 0);
    lv_obj_set_style_bg_color(right_page, page_c, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(right_page, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(right_page, 3, LV_PART_MAIN);
    lv_obj_set_style_border_width(right_page, 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(right_page, lv_color_hex(0xD8D0C4), LV_PART_MAIN);
    lv_obj_set_style_pad_all(right_page, 12, LV_PART_MAIN);
    lv_obj_clear_flag(right_page, LV_OBJ_FLAG_SCROLLABLE);
    // 页内侧阴影
    lv_obj_t *r_shadow = lv_obj_create(right_page);
    lv_obj_set_size(r_shadow, 6, 296);
    lv_obj_align(r_shadow, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_style_bg_color(r_shadow, shadow_c, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(r_shadow, LV_OPA_30, LV_PART_MAIN);
    lv_obj_set_style_border_width(r_shadow, 0, LV_PART_MAIN);
    lv_obj_set_style_radius(r_shadow, 0, LV_PART_MAIN);

    // 关闭按钮 X（封面右上角）
    lv_obj_t *close_btn = lv_btn_create(book);
    lv_obj_set_size(close_btn, 28, 28);
    lv_obj_align(close_btn, LV_ALIGN_TOP_RIGHT, -4, 4);
    lv_obj_set_style_bg_color(close_btn, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(close_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *cx = lv_label_create(close_btn);
    lv_label_set_text(cx, LV_SYMBOL_CLOSE);
    lv_obj_set_style_text_color(cx, lv_color_white(), 0);
    lv_obj_center(cx);
    lv_obj_add_event_cb(close_btn, word_close_cb, LV_EVENT_CLICKED, NULL);

    // 标题（左页顶部）
    lv_obj_t *title = lv_label_create(left_page);
    lv_label_set_text(title, "Word List");
    lv_obj_set_style_text_color(title, lv_color_hex(0x333333), 0);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_20, 0);
    lv_obj_align(title, LV_ALIGN_TOP_LEFT, 0, 0);

    // 左右页码（1-2, 3-4, 5-6, ...）
    char pbuf[8];
    snprintf(pbuf, sizeof(pbuf), "%hhu", (unsigned char)(s_word_page * 2 + 1));
    lv_obj_t *lpn = lv_label_create(left_page);
    lv_label_set_text(lpn, pbuf);
    lv_obj_set_style_text_color(lpn, lv_color_hex(0x999999), 0);
    lv_obj_set_style_text_font(lpn, &lv_font_montserrat_12, 0);
    lv_obj_align(lpn, LV_ALIGN_BOTTOM_RIGHT, 0, 0);

    snprintf(pbuf, sizeof(pbuf), "%hhu", (unsigned char)(s_word_page * 2 + 2));
    lv_obj_t *rpn = lv_label_create(right_page);
    lv_label_set_text(rpn, pbuf);
    lv_obj_set_style_text_color(rpn, lv_color_hex(0x999999), 0);
    lv_obj_set_style_text_font(rpn, &lv_font_montserrat_12, 0);
    lv_obj_align(rpn, LV_ALIGN_BOTTOM_LEFT, 0, 0);

    // ---- 左页内容：英文单词 + 词性 + 喇叭 ----
    lv_obj_t *en_label = lv_label_create(left_page);
    lv_label_set_text(en_label, w->en);
    lv_obj_set_style_text_color(en_label, lv_color_hex(0x222222), 0);
    lv_obj_set_style_text_font(en_label, &lv_font_montserrat_30, 0);
    lv_obj_align(en_label, LV_ALIGN_LEFT_MID, 0, -30);

    lv_obj_t *pos_label = lv_label_create(left_page);
    lv_label_set_text(pos_label, w->pos);
    lv_obj_set_style_text_color(pos_label, UI_COLOR_SAFE_GREEN, 0);
    lv_obj_set_style_text_font(pos_label, &lv_font_montserrat_16, 0);
    lv_obj_align(pos_label, LV_ALIGN_LEFT_MID, 0, 10);

    lv_obj_t *spk_btn = lv_btn_create(left_page);
    lv_obj_set_size(spk_btn, 36, 36);
    lv_obj_align(spk_btn, LV_ALIGN_LEFT_MID, 80, 0);
    lv_obj_set_style_bg_color(spk_btn, lv_color_hex(0x8B6F47), LV_PART_MAIN);
    lv_obj_set_style_radius(spk_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *spk_icon = lv_label_create(spk_btn);
    lv_label_set_text(spk_icon, LV_SYMBOL_AUDIO);
    lv_obj_set_style_text_color(spk_icon, lv_color_white(), 0);
    lv_obj_center(spk_icon);
    lv_obj_add_event_cb(spk_btn, word_speaker_cb, LV_EVENT_CLICKED, (void *)w->audio);

    // ---- 右页内容：图片 + 中文标签 ----
    lv_obj_t *wimg = lv_img_create(right_page);
    lv_img_set_src(wimg, w->img);
    lv_obj_align(wimg, LV_ALIGN_TOP_MID, 0, 10);

    int cw2 = w->cn->header.w, ch2 = w->cn->header.h;
    lv_color_t *cbuf2 = heap_caps_malloc(cw2 * ch2 * 2, MALLOC_CAP_SPIRAM);
    if (cbuf2) {
        memcpy(cbuf2, w->cn->data, cw2 * ch2 * 2);
        lv_obj_t *cl = lv_canvas_create(right_page);
        lv_canvas_set_buffer(cl, cbuf2, cw2, ch2, LV_IMG_CF_TRUE_COLOR);
        lv_obj_set_size(cl, cw2, ch2);
        lv_obj_align(cl, LV_ALIGN_BOTTOM_MID, 0, -5);
        lv_obj_set_style_pad_all(cl, 0, LV_PART_MAIN);
        lv_obj_set_style_border_width(cl, 0, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(cl, LV_OPA_TRANSP, LV_PART_MAIN);
    }

    // ---- 翻页按钮（封面底部左右）----
    lv_obj_t *prev_btn = lv_btn_create(book);
    lv_obj_set_size(prev_btn, 36, 36);
    lv_obj_align(prev_btn, LV_ALIGN_BOTTOM_LEFT, 20, -5);
    lv_obj_set_style_bg_color(prev_btn, lv_color_hex(0x5A3D1C), LV_PART_MAIN);
    lv_obj_set_style_radius(prev_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *prev_lbl = lv_label_create(prev_btn);
    lv_label_set_text(prev_lbl, LV_SYMBOL_LEFT);
    lv_obj_center(prev_lbl);
    lv_obj_add_event_cb(prev_btn, word_page_flip, LV_EVENT_CLICKED, (void *)(intptr_t)(-1));

    // 右箭头 >
    lv_obj_t *next_btn = lv_btn_create(book);
    lv_obj_set_size(next_btn, 36, 36);
    lv_obj_align(next_btn, LV_ALIGN_BOTTOM_RIGHT, -20, -5);
    lv_obj_set_style_bg_color(next_btn, lv_color_hex(0x5A3D1C), LV_PART_MAIN);
    lv_obj_set_style_radius(next_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *next_lbl = lv_label_create(next_btn);
    lv_label_set_text(next_lbl, LV_SYMBOL_RIGHT);
    lv_obj_center(next_lbl);
    lv_obj_add_event_cb(next_btn, word_page_flip, LV_EVENT_CLICKED, (void *)(intptr_t)(+1));

    ESP_LOGI(TAG, "Word list page %d/%d: %s", s_word_page + 1, (int)WORD_COUNT, w->en);
}

static void btn_wordlist_cb(lv_event_t *e)
{
    ESP_LOGI(TAG, "Word List pressed");
    s_word_page = 0;  // 每次打开从第1页开始
    word_popup_show();
}

// ============================================================
// 告警历史弹窗
// ============================================================
static lv_obj_t *s_alert_overlay = NULL;

static void alert_close_cb(lv_event_t *e)
{
    if (s_alert_overlay) lv_obj_add_flag(s_alert_overlay, LV_OBJ_FLAG_HIDDEN);
}

static void __attribute__((unused)) alert_popup_create(void)
{
    s_alert_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_alert_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_alert_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_alert_overlay, LV_OPA_50, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_alert_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_alert_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_alert_overlay, alert_close_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *card = lv_obj_create(s_alert_overlay);
    lv_obj_set_size(card, 540, 360);
    lv_obj_align(card, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(card, UI_COLOR_CARD_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 20, LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 2, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, UI_COLOR_ACCENT, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

    // 关闭按钮
    lv_obj_t *close_btn = lv_btn_create(card);
    lv_obj_set_size(close_btn, 32, 32);
    lv_obj_align(close_btn, LV_ALIGN_TOP_RIGHT, -5, 5);
    lv_obj_set_style_bg_color(close_btn, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(close_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *cx = lv_label_create(close_btn);
    lv_label_set_text(cx, LV_SYMBOL_CLOSE);
    lv_obj_set_style_text_color(cx, lv_color_white(), 0);
    lv_obj_center(cx);
    lv_obj_add_event_cb(close_btn, alert_close_cb, LV_EVENT_CLICKED, NULL);

    // 标题
    lv_obj_t *title = lv_label_create(card);
    lv_label_set_text(title, "Posture Report");
    lv_obj_set_style_text_color(title, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_24, 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 15);

    // 报告内容
    lv_obj_t *report = lv_label_create(card);
    lv_label_set_text(report,
        "Today's Posture Summary\n\n"
        "Total Alerts:  3\n"
        "Longest Safe:  45 min");
    lv_obj_set_style_text_color(report, lv_color_hex(0xBBBBBB), 0);
    lv_obj_set_style_text_font(report, &lv_font_montserrat_16, 0);
    lv_obj_align(report, LV_ALIGN_TOP_LEFT, 30, 70);

    // 安全 / 告警比例条
    lv_obj_t *bar_label = lv_label_create(card);
    lv_label_set_text(bar_label, "Safe  92%  |  Alert  8%");
    lv_obj_set_style_text_color(bar_label, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(bar_label, &lv_font_montserrat_14, 0);
    lv_obj_align(bar_label, LV_ALIGN_TOP_LEFT, 30, 170);

    lv_obj_t *bar_bg = lv_obj_create(card);
    lv_obj_set_size(bar_bg, 480, 24);
    lv_obj_align(bar_bg, LV_ALIGN_TOP_LEFT, 30, 195);
    lv_obj_set_style_bg_color(bar_bg, lv_color_hex(0x333333), LV_PART_MAIN);
    lv_obj_set_style_radius(bar_bg, 4, LV_PART_MAIN);
    lv_obj_set_style_pad_all(bar_bg, 0, LV_PART_MAIN);
    lv_obj_clear_flag(bar_bg, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *safe_bar = lv_obj_create(bar_bg);
    lv_obj_set_size(safe_bar, 442, 24);  // 92% of 480
    lv_obj_align(safe_bar, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_style_bg_color(safe_bar, UI_COLOR_SAFE_GREEN, LV_PART_MAIN);
    lv_obj_set_style_radius(safe_bar, 4, LV_PART_MAIN);
    lv_obj_set_style_pad_all(safe_bar, 0, LV_PART_MAIN);

    lv_obj_t *alert_bar = lv_obj_create(bar_bg);
    lv_obj_set_size(alert_bar, 38, 24);  // 8% of 480
    lv_obj_align(alert_bar, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_set_style_bg_color(alert_bar, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(alert_bar, 4, LV_PART_MAIN);
    lv_obj_set_style_pad_all(alert_bar, 0, LV_PART_MAIN);

    // 建议文字
    lv_obj_t *suggest = lv_label_create(card);
    lv_label_set_text(suggest,
        "Suggestion:\n"
        "Your posture is generally\n"
        "good. Remember to take\n"
        "breaks every 30 minutes.");
    lv_obj_set_style_text_color(suggest, lv_color_hex(0x999999), 0);
    lv_obj_set_style_text_font(suggest, &lv_font_montserrat_14, 0);
    lv_obj_align(suggest, LV_ALIGN_TOP_LEFT, 30, 240);

    lv_obj_add_flag(s_alert_overlay, LV_OBJ_FLAG_HIDDEN);
    ESP_LOGI(TAG, "Alert popup created");
}

// 健康报告弹窗
static lv_obj_t *s_health_overlay = NULL;
static float s_report_scores[9] = {0};

static void health_close_cb(lv_event_t *e) {
    if (s_health_overlay) lv_obj_add_flag(s_health_overlay, LV_OBJ_FLAG_HIDDEN);
}

static void canvas_cn(lv_obj_t *parent, const lv_img_dsc_t *dsc, lv_coord_t x, lv_coord_t y) {
    int cw = dsc->header.w, ch = dsc->header.h;
    lv_color_t *cb = heap_caps_malloc(cw*ch*2, MALLOC_CAP_SPIRAM);
    if (cb) {
        memcpy(cb, dsc->data, cw*ch*2);
        lv_obj_t *cv = lv_canvas_create(parent);
        lv_canvas_set_buffer(cv, cb, cw, ch, LV_IMG_CF_TRUE_COLOR);
        lv_obj_set_size(cv, cw, ch);
        lv_obj_set_pos(cv, x, y);
        lv_obj_set_style_pad_all(cv, 0, LV_PART_MAIN);
        lv_obj_set_style_border_width(cv, 0, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(cv, LV_OPA_TRANSP, LV_PART_MAIN);
    }
}

static void health_report_show(void)
{
    if (s_health_overlay) lv_obj_del(s_health_overlay);
    s_health_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_health_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_health_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_health_overlay, LV_OPA_50, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_health_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_health_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_health_overlay, health_close_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *card = lv_obj_create(s_health_overlay);
    lv_obj_set_size(card, 540, 360);
    lv_obj_align(card, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(card, UI_COLOR_CARD_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 16, LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 2, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, UI_COLOR_ACCENT, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

    // X
    lv_obj_t *cb = lv_btn_create(card);
    lv_obj_set_size(cb, 30, 30);
    lv_obj_align(cb, LV_ALIGN_TOP_RIGHT, -5, 5);
    lv_obj_set_style_bg_color(cb, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(cb, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *cx = lv_label_create(cb);
    lv_label_set_text(cx, LV_SYMBOL_CLOSE);
    lv_obj_set_style_text_color(cx, lv_color_white(), 0);
    lv_obj_center(cx);
    lv_obj_add_event_cb(cb, health_close_cb, LV_EVENT_CLICKED, NULL);

    // 标题（中文）
    canvas_cn(card, &cn_health_report_dsc, 15, 10);

    // 9 项评分 — 中文标签 + 数值
    static const lv_img_dsc_t *cn_labels[] = {
        &cn_forward_dsc, &cn_backward_dsc, &cn_lateral_dsc,
        &cn_head_twist_dsc, &cn_press_bal_dsc, &cn_press_ctr_dsc,
        &cn_press_unif_dsc, &cn_stability_dsc, &cn_health_score_dsc,
    };
    lv_color_t c_ok = UI_COLOR_SAFE_GREEN;
    lv_color_t c_bad = UI_COLOR_ALERT_RED;

    for (int i = 0; i < 9; i++) {
        int col = i % 3, row = i / 3;
        int x = 20 + col * 175, y = 50 + row * 95;
        // 中文标签 canvas
        canvas_cn(card, cn_labels[i], x, y);
        // 数值
        char vbuf[16];
        snprintf(vbuf, sizeof(vbuf), "%.0f", (double)s_report_scores[i]);
        lv_obj_t *vl = lv_label_create(card);
        lv_label_set_text(vl, vbuf);
        lv_obj_set_style_text_color(vl, s_report_scores[i] < 40 ? c_bad : c_ok, 0);
        lv_obj_set_style_text_font(vl, &lv_font_montserrat_30, 0);
        lv_obj_set_pos(vl, x, y + 22);
    }
}

static void btn_alerts_cb(lv_event_t *e)
{
    ESP_LOGI(TAG, "Health Report pressed");
    memcpy(s_report_scores, &g_last_scores, sizeof(s_report_scores));
    health_report_show();
}

// ============================================================
// 天气弹窗 — 从卡片平滑过渡到详情
// ============================================================

// 动画执行回调：overlay 背景透明度
static void anim_overlay_opa_cb(void *obj, int32_t v) {
    lv_obj_set_style_bg_opa((lv_obj_t *)obj, (lv_opa_t)v, LV_PART_MAIN);
}
// 动画执行回调：卡片 y 偏移（向上滑入）
static void anim_card_y_cb(void *obj, int32_t v) {
    lv_obj_set_y((lv_obj_t *)obj, (lv_coord_t)v);
}

static void weather_popup_close_cb(lv_event_t *e)
{
    (void)e;
    if (s_weather_overlay) {
        lv_obj_del(s_weather_overlay);
        s_weather_overlay = NULL;
    }
}

// 中文 canvas 辅助 — 从 lv_img_dsc_t 创建 canvas，返回对象（内存由 canvas 生命周期管理）
static lv_obj_t *weather_cn_canvas(lv_obj_t *parent, const lv_img_dsc_t *dsc)
{
    int cw = dsc->header.w, ch = dsc->header.h;
    lv_color_t *cbuf = heap_caps_malloc(cw * ch * 2, MALLOC_CAP_SPIRAM);
    if (!cbuf) return NULL;
    memcpy(cbuf, dsc->data, cw * ch * 2);
    lv_obj_t *cv = lv_canvas_create(parent);
    lv_canvas_set_buffer(cv, cbuf, cw, ch, LV_IMG_CF_TRUE_COLOR);
    lv_obj_set_size(cv, cw, ch);
    lv_obj_set_style_pad_all(cv, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(cv, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(cv, LV_OPA_TRANSP, LV_PART_MAIN);
    return cv;
}

// 弹窗详情行（中文图片标签版）：[中文 canvas ............... 数值]
static void weather_popup_add_row_cn(lv_obj_t *parent,
    const lv_img_dsc_t *label_img, const char *value_text, lv_color_t val_color)
{
    lv_obj_t *row = lv_obj_create(parent);
    lv_obj_set_size(row, 400, 30);
    lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(row, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(row, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_BETWEEN,
                          LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

    weather_cn_canvas(row, label_img);

    lv_obj_t *value = lv_label_create(row);
    lv_label_set_text(value, value_text);
    lv_obj_set_style_text_color(value, val_color, 0);
    lv_obj_set_style_text_font(value, &lv_font_montserrat_16, 0);
}

// 英文城市名 → 中文 canvas 查表
typedef struct { const char *en; const lv_img_dsc_t *cn; } city_map_t;
static const city_map_t s_city_map[] = {
    {"Beijing",   &cn_city_beijing_dsc},
    {"Shanghai",  &cn_city_shanghai_dsc},
    {"Zhengzhou", &cn_city_zhengzhou_dsc},
    {"Guangzhou", &cn_city_guangzhou_dsc},
    {"Shenzhen",  &cn_city_shenzhen_dsc},
    {"Hangzhou",  &cn_city_hangzhou_dsc},
    {"Chengdu",   &cn_city_chengdu_dsc},
    {"Wuhan",     &cn_city_wuhan_dsc},
    {"Nanjing",   &cn_city_nanjing_dsc},
    {"Xi'an",     &cn_city_xian_dsc},
    {NULL, NULL},
};

static const lv_img_dsc_t *city_en_to_cn(const char *en)
{
    for (int i = 0; s_city_map[i].en; i++)
        if (strcmp(s_city_map[i].en, en) == 0) return s_city_map[i].cn;
    return NULL;
}

static void weather_card_click_cb(lv_event_t *e)
{
    (void)e;
    if (s_weather_overlay) return;  // 已打开则不重复创建

    const weather_t *w = app_weather_get();
    if (!w || !w->valid) return;

    // ---- 1. 全屏遮罩（初始透明，动画淡入）----
    s_weather_overlay = lv_obj_create(lv_layer_top());
    lv_obj_set_size(s_weather_overlay, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(s_weather_overlay, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_weather_overlay, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_weather_overlay, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_weather_overlay, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(s_weather_overlay, weather_popup_close_cb,
                        LV_EVENT_CLICKED, NULL);

    // ---- 2. 详情卡片（深色背景 + 发光边框）----
    lv_obj_t *card = lv_obj_create(s_weather_overlay);
    lv_obj_set_size(card, 500, 400);
    lv_obj_align(card, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(card, lv_color_hex(0x1E1E30), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 20, LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 2, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, lv_color_hex(0x5A5A80), LV_PART_MAIN);
    lv_obj_set_style_shadow_width(card, 48, LV_PART_MAIN);
    lv_obj_set_style_shadow_color(card, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_shadow_opa(card, LV_OPA_80, LV_PART_MAIN);
    lv_obj_set_style_pad_all(card, 24, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(card, NULL, LV_EVENT_CLICKED, NULL); // 阻止事件穿透

    // ---- 3. 标题 ----
    lv_obj_t *title = lv_label_create(card);
    lv_label_set_text(title, "Weather Detail");
    lv_obj_set_style_text_color(title, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_20, 0);
    lv_obj_align(title, LV_ALIGN_TOP_LEFT, 0, 0);

    // ---- 4. 关闭按钮 ----
    lv_obj_t *close_btn = lv_btn_create(card);
    lv_obj_set_size(close_btn, 32, 32);
    lv_obj_align(close_btn, LV_ALIGN_TOP_RIGHT, 0, 0);
    lv_obj_set_style_bg_color(close_btn, UI_COLOR_ALERT_RED, LV_PART_MAIN);
    lv_obj_set_style_radius(close_btn, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_t *cx = lv_label_create(close_btn);
    lv_label_set_text(cx, LV_SYMBOL_CLOSE);
    lv_obj_set_style_text_color(cx, lv_color_white(), 0);
    lv_obj_center(cx);
    lv_obj_add_event_cb(close_btn, weather_popup_close_cb,
                        LV_EVENT_CLICKED, NULL);

    // ---- 5. 天气状况（中文 canvas）----
    const lv_img_dsc_t *cond_img;
    int c = w->code;
    if (c == 0)      { cond_img = &cn_sunny_dsc; }
    else if (c <= 3) { cond_img = &cn_cloudy_dsc; }
    else if (c <= 48){ cond_img = &cn_fog_dsc; }
    else if (c <= 67){ cond_img = &cn_rain_dsc; }
    else if (c <= 86){ cond_img = &cn_snow_dsc; }
    else             { cond_img = &cn_storm_dsc; }

    // 状况标签（中文 canvas 居中显示）
    lv_obj_t *cond_cv = weather_cn_canvas(card, cond_img);
    if (cond_cv) lv_obj_align(cond_cv, LV_ALIGN_TOP_MID, 0, 40);

    // ---- 6. 大号温度 ----
    char tbuf[16];
    snprintf(tbuf, sizeof(tbuf), "%.1f°C", (double)w->temp);
    lv_obj_t *temp_label = lv_label_create(card);
    lv_label_set_text(temp_label, tbuf);
    lv_obj_set_style_text_color(temp_label, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(temp_label, &lv_font_montserrat_48, 0);
    lv_obj_align(temp_label, LV_ALIGN_TOP_MID, 0, 72);

    // ---- 7. 城市 + 体感温度（同行，左右分布）----
    {
        lv_obj_t *row = lv_obj_create(card);
        lv_obj_set_size(row, 460, 26);
        lv_obj_align(row, LV_ALIGN_TOP_MID, 0, 140);
        lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, LV_PART_MAIN);
        lv_obj_set_style_border_width(row, 0, LV_PART_MAIN);
        lv_obj_set_style_pad_all(row, 0, LV_PART_MAIN);
        lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
        lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_BETWEEN,
                              LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

        // 左侧：城市
        {
            lv_obj_t *city_grp = lv_obj_create(row);
            lv_obj_set_style_bg_opa(city_grp, LV_OPA_TRANSP, LV_PART_MAIN);
            lv_obj_set_style_border_width(city_grp, 0, LV_PART_MAIN);
            lv_obj_set_style_pad_all(city_grp, 0, LV_PART_MAIN);
            lv_obj_set_flex_flow(city_grp, LV_FLEX_FLOW_ROW);
            lv_obj_set_flex_align(city_grp, LV_FLEX_ALIGN_CENTER,
                                  LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

            weather_cn_canvas(city_grp, &cn_city_prefix_dsc);
            const lv_img_dsc_t *cn_city = city_en_to_cn(w->city);
            if (cn_city) {
                weather_cn_canvas(city_grp, cn_city);
            } else {
                lv_obj_t *cv = lv_label_create(city_grp);
                lv_label_set_text(cv, w->city[0] ? w->city : "---");
                lv_obj_set_style_text_color(cv, lv_color_hex(0xCCCCDD), 0);
                lv_obj_set_style_text_font(cv, &lv_font_montserrat_16, 0);
            }
        }

        // 右侧：体感温度
        {
            lv_obj_t *fl_grp = lv_obj_create(row);
            lv_obj_set_style_bg_opa(fl_grp, LV_OPA_TRANSP, LV_PART_MAIN);
            lv_obj_set_style_border_width(fl_grp, 0, LV_PART_MAIN);
            lv_obj_set_style_pad_all(fl_grp, 0, LV_PART_MAIN);
            lv_obj_set_flex_flow(fl_grp, LV_FLEX_FLOW_ROW);
            lv_obj_set_flex_align(fl_grp, LV_FLEX_ALIGN_CENTER,
                                  LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

            weather_cn_canvas(fl_grp, &cn_feels_like_dsc);

            char flbuf[16];
            snprintf(flbuf, sizeof(flbuf), " %.1f°C",
                     (double)(w->feels_like > 0 ? w->feels_like : w->temp));
            lv_obj_t *fl_val = lv_label_create(fl_grp);
            lv_label_set_text(fl_val, flbuf);
            lv_obj_set_style_text_color(fl_val, lv_color_hex(0xCCCCDD), 0);
            lv_obj_set_style_text_font(fl_val, &lv_font_montserrat_16, 0);
        }
    }

    // ---- 8. 详情行（左标签 / 右数值，Flex 行布局）----
    // 详情容器（透明面板，占卡片下半部）
    lv_obj_t *detail_panel = lv_obj_create(card);
    lv_obj_set_size(detail_panel, 440, 160);
    lv_obj_align(detail_panel, LV_ALIGN_BOTTOM_MID, 0, -8);
    lv_obj_set_style_bg_color(detail_panel, lv_color_hex(0x252535), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(detail_panel, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(detail_panel, 12, LV_PART_MAIN);
    lv_obj_set_style_border_width(detail_panel, 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(detail_panel, lv_color_hex(0x3A3A50), LV_PART_MAIN);
    lv_obj_set_style_pad_all(detail_panel, 14, LV_PART_MAIN);
    lv_obj_clear_flag(detail_panel, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(detail_panel, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(detail_panel, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START);

    // 填充详情行（中文标签）
    {
        char vbuf[32];
        snprintf(vbuf, sizeof(vbuf), "%d%%", w->humidity);
        weather_popup_add_row_cn(detail_panel, &cn_humidity_dsc, vbuf,
                                 UI_COLOR_TEXT_WHITE);

        snprintf(vbuf, sizeof(vbuf), "%.1f km/h", (double)w->wind_speed);
        weather_popup_add_row_cn(detail_panel, &cn_wind_dsc, vbuf,
                                 UI_COLOR_TEXT_WHITE);

        snprintf(vbuf, sizeof(vbuf), "%.0f° / %.0f°",
                 (double)w->daily_max, (double)w->daily_min);
        weather_popup_add_row_cn(detail_panel, &cn_high_low_dsc, vbuf,
                                 lv_color_hex(0xFF8A65));

        snprintf(vbuf, sizeof(vbuf), "%d%%", w->precip_prob);
        weather_popup_add_row_cn(detail_panel, &cn_precip_dsc, vbuf,
            (w->precip_prob > 30) ? UI_COLOR_ALERT_RED : UI_COLOR_SAFE_GREEN);
    }

    // ---- 9. 入场动画 ----
    // 卡片已由 LV_ALIGN_CENTER 定位，记录 y 后先下移 30px
    lv_coord_t final_y = lv_obj_get_y(card);
    lv_obj_set_y(card, final_y + 30);

    // overlay 背景淡入
    lv_anim_t a_overlay;
    lv_anim_init(&a_overlay);
    lv_anim_set_var(&a_overlay, s_weather_overlay);
    lv_anim_set_exec_cb(&a_overlay, anim_overlay_opa_cb);
    lv_anim_set_values(&a_overlay, 0, LV_OPA_50);
    lv_anim_set_time(&a_overlay, 250);
    lv_anim_start(&a_overlay);

    // 卡片向上滑入
    lv_anim_t a_card;
    lv_anim_init(&a_card);
    lv_anim_set_var(&a_card, card);
    lv_anim_set_exec_cb(&a_card, anim_card_y_cb);
    lv_anim_set_values(&a_card, final_y + 30, final_y);
    lv_anim_set_time(&a_card, 300);
    lv_anim_set_path_cb(&a_card, lv_anim_path_ease_out);
    lv_anim_start(&a_card);

    ESP_LOGI(TAG, "Weather popup shown");
}

// ============================================================
// ui_home_create() — 构建首页完整 widget 树
// ============================================================
lv_obj_t *ui_home_create(lv_obj_t *parent)
{
    const lv_coord_t page_w = LV_HOR_RES;         // 800
    const lv_coord_t page_h = LV_VER_RES - 80;    // 400 (减去状态栏 30 + 标签栏 50)

    // ---- 1. 页面容器 ----
    lv_obj_t *page = lv_obj_create(parent);
    lv_obj_set_size(page, page_w, page_h);
    lv_obj_set_style_bg_color(page, HOME_COLOR_BG_FALLBACK, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(page, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_pad_all(page, 0, LV_PART_MAIN);
    lv_obj_set_style_border_width(page, 0, LV_PART_MAIN);
    lv_obj_clear_flag(page, LV_OBJ_FLAG_SCROLLABLE);

    // ---- 2. 背景图（Canvas）----
    lv_color_t *cbuf = heap_caps_malloc(page_w * page_h * sizeof(lv_color_t),
                                        MALLOC_CAP_SPIRAM);
    if (cbuf) {
        memcpy(cbuf, home_bg_img_map, page_w * page_h * 2);
        lv_obj_t *canvas = lv_canvas_create(page);
        lv_canvas_set_buffer(canvas, cbuf, page_w, page_h, LV_IMG_CF_TRUE_COLOR);
        lv_obj_set_size(canvas, page_w, page_h);
        lv_obj_align(canvas, LV_ALIGN_TOP_LEFT, 0, 0);
        lv_obj_set_style_pad_all(canvas, 0, LV_PART_MAIN);
        lv_obj_set_style_border_width(canvas, 0, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(canvas, LV_OPA_TRANSP, LV_PART_MAIN);
        ESP_LOGI(TAG, "Canvas bg: %dx%d OK", page_w, page_h);
    } else {
        ESP_LOGE(TAG, "Canvas malloc failed!");
    }

    // ---- 3. 半透明时钟卡片（毛玻璃效果）----
    lv_obj_t *clock_card = lv_obj_create(page);
    lv_obj_set_size(clock_card, 560, 95);
    lv_obj_align(clock_card, LV_ALIGN_TOP_MID, 0, 15);
    lv_obj_set_style_bg_color(clock_card, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(clock_card, LV_OPA_30, LV_PART_MAIN);
    lv_obj_set_style_radius(clock_card, 16, LV_PART_MAIN);
    lv_obj_set_style_border_width(clock_card, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(clock_card, 0, LV_PART_MAIN);
    lv_obj_clear_flag(clock_card, LV_OBJ_FLAG_SCROLLABLE);

    // ---- 4. 时间标签 HH:MM:SS ----
    s_time_label = lv_label_create(clock_card);
    lv_label_set_text(s_time_label, "00:00:00");
    lv_obj_set_style_text_color(s_time_label, lv_color_white(), 0);
    lv_obj_set_style_text_font(s_time_label, &lv_font_montserrat_48, 0);
    lv_obj_align(s_time_label, LV_ALIGN_CENTER, 0, -12);

    // ---- 5. 日期标签 YYYY/MM/DD Day ----
    s_date_label = lv_label_create(clock_card);
    lv_label_set_text(s_date_label, "----/--/-- ---");
    lv_obj_set_style_text_color(s_date_label, lv_color_hex(0xDDDDDD), 0);
    lv_obj_set_style_text_font(s_date_label, &lv_font_montserrat_20, 0);
    lv_obj_align(s_date_label, LV_ALIGN_CENTER, 0, 25);

    // ── 天气卡片（毛玻璃风格，左色条 + 温度 + 天气描述）──
    // 卡片总尺寸 300×80，y=120 在时钟卡片 (15~110) 和按钮行 (243~) 之间
    s_weather_card = lv_obj_create(page);
    lv_obj_set_size(s_weather_card, 300, 80);
    lv_obj_align(s_weather_card, LV_ALIGN_TOP_MID, 0, 117);
    lv_obj_set_style_bg_color(s_weather_card, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_weather_card, LV_OPA_20, LV_PART_MAIN);
    lv_obj_set_style_radius(s_weather_card, 14, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_weather_card, 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(s_weather_card, lv_color_hex(0x4A4A60), LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_weather_card, 0, LV_PART_MAIN);
    lv_obj_clear_flag(s_weather_card, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(s_weather_card, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(s_weather_card, weather_card_click_cb,
                        LV_EVENT_CLICKED, NULL);

    // 天气图标（温度与描述文字之间，居中不遮挡）
    s_weather_icon = lv_img_create(s_weather_card);
    lv_img_set_src(s_weather_icon, &w_icon_cloudy_dsc);  // 默认多云图标
    lv_obj_align(s_weather_icon, LV_ALIGN_CENTER, 10, 0);

    // 左侧：大号温度（水平居中靠左）
    s_weather_temp = lv_label_create(s_weather_card);
    lv_label_set_text(s_weather_temp, "--.-°C");
    lv_obj_set_style_text_color(s_weather_temp, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(s_weather_temp, &lv_font_montserrat_30, 0);
    lv_obj_align(s_weather_temp, LV_ALIGN_LEFT_MID, 22, -6);

    // 右上：天气描述（如 "Cloudy"）
    s_weather_desc = lv_label_create(s_weather_card);
    lv_label_set_text(s_weather_desc, "Wait...");
    lv_obj_set_style_text_color(s_weather_desc, lv_color_hex(0xCCCCCC), 0);
    lv_obj_set_style_text_font(s_weather_desc, &lv_font_montserrat_20, 0);
    lv_obj_align(s_weather_desc, LV_ALIGN_RIGHT_MID, -18, -10);

    // 右下：湿度
    s_weather_humi = lv_label_create(s_weather_card);
    lv_label_set_text(s_weather_humi, "--%");
    lv_obj_set_style_text_color(s_weather_humi, lv_color_hex(0x9999BB), 0);
    lv_obj_set_style_text_font(s_weather_humi, &lv_font_montserrat_16, 0);
    lv_obj_align(s_weather_humi, LV_ALIGN_RIGHT_MID, -18, 12);

    // ---- 6. BLE 连接状态 ----
    // 小圆点 + BLE 状态文字（底部居中）
    // 用透明容器包住圆点和文字，整体居中
    lv_obj_t *status_row = lv_obj_create(page);
    lv_obj_set_size(status_row, 300, 22);
    lv_obj_align(status_row, LV_ALIGN_BOTTOM_MID, 0, -8);
    lv_obj_set_style_bg_opa(status_row, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(status_row, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(status_row, 0, LV_PART_MAIN);
    lv_obj_set_flex_flow(status_row, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(status_row, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

    s_posture_circle = lv_obj_create(status_row);
    lv_obj_set_size(s_posture_circle, 12, 12);
    lv_obj_set_style_radius(s_posture_circle, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_bg_color(s_posture_circle, lv_color_hex(0x666666), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_posture_circle, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(s_posture_circle, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(s_posture_circle, 0, LV_PART_MAIN);

    s_ble_label = lv_label_create(status_row);
    lv_label_set_text(s_ble_label, "Searching...");
    lv_obj_set_style_text_color(s_ble_label, HOME_COLOR_GOLDEN, 0);
    lv_obj_set_style_text_font(s_ble_label, &lv_font_montserrat_16, 0);
    lv_obj_set_style_pad_left(s_ble_label, 6, LV_PART_MAIN);

    // ---- 7. 按钮行（Flex 布局）----
    lv_obj_t *btn_row = lv_obj_create(page);
    lv_obj_set_size(btn_row, 760, 125);
    lv_obj_align(btn_row, LV_ALIGN_BOTTOM_MID, 0, -32);
    lv_obj_set_flex_flow(btn_row, LV_FLEX_FLOW_ROW);
    lv_obj_set_style_pad_column(btn_row, 30, LV_PART_MAIN);
    lv_obj_set_style_pad_all(btn_row, 0, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(btn_row, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_border_width(btn_row, 0, LV_PART_MAIN);

    // ---- 8. 创建三个功能按钮 ----
    typedef struct {
        const char   *icon;
        const char   *label;
        lv_color_t    color;
        lv_event_cb_t cb;
    } btn_def_t;

    const btn_def_t btn_defs[] = {
        { LV_SYMBOL_AUDIO,  "Play Music", HOME_COLOR_SKY_BLUE,   btn_music_cb },
        { LV_SYMBOL_LIST,   "Word List",  HOME_COLOR_MINT_GREEN,  btn_wordlist_cb },
        { LV_SYMBOL_FILE,   "Health Rpt", HOME_COLOR_WARM_CORAL,  btn_alerts_cb },
    };

    for (int i = 0; i < 3; i++) {
        lv_obj_t *btn = lv_btn_create(btn_row);
        lv_obj_set_style_bg_color(btn, btn_defs[i].color, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, LV_PART_MAIN);
        lv_obj_set_style_radius(btn, 22, LV_PART_MAIN);
        lv_obj_set_style_shadow_width(btn, 12, LV_PART_MAIN);
        lv_obj_set_style_shadow_color(btn, btn_defs[i].color, LV_PART_MAIN);
        lv_obj_set_style_shadow_opa(btn, LV_OPA_50, LV_PART_MAIN);
        lv_obj_set_style_shadow_ofs_y(btn, 4, LV_PART_MAIN);
        lv_obj_set_flex_grow(btn, 1);

        lv_obj_t *icon_lbl = lv_label_create(btn);
        lv_label_set_text(icon_lbl, btn_defs[i].icon);
        lv_obj_set_style_text_color(icon_lbl, lv_color_hex(0xDDDDDD), 0);  // 浅灰图标
        lv_obj_set_style_text_font(icon_lbl, &lv_font_montserrat_48, 0);
        lv_obj_align(icon_lbl, LV_ALIGN_TOP_MID, 0, 14);

        lv_obj_t *txt_lbl = lv_label_create(btn);
        lv_label_set_text(txt_lbl, btn_defs[i].label);
        lv_obj_set_style_text_color(txt_lbl, UI_COLOR_BG, 0);  // 深蓝文字
        lv_obj_set_style_text_font(txt_lbl, &lv_font_montserrat_16, 0);
        lv_obj_align(txt_lbl, LV_ALIGN_BOTTOM_MID, 0, -14);

        lv_obj_add_event_cb(btn, btn_defs[i].cb, LV_EVENT_CLICKED, NULL);
    }

    // ---- 9. 初始更新一次 ----
    ui_home_update();

    ESP_LOGI(TAG, "Home screen created");
    return page;
}

// ============================================================
// 时钟刷新
// ============================================================
void ui_home_update(void)
{
    if (!s_time_label || !s_date_label) return;

    char buf[64];

    // 时间 HH:MM:SS
    app_get_time_str(buf, sizeof(buf), "%H:%M:%S");
    lv_label_set_text(s_time_label, buf);

    // 日期 YYYY/MM/DD Day
    struct tm tm = app_get_local_time();
    const char *weekdays[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    snprintf(buf, sizeof(buf), "%04d/%02d/%02d %s",
             tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             weekdays[tm.tm_wday]);
    lv_label_set_text(s_date_label, buf);

    // 天气刷新
    if (s_weather_temp && s_weather_desc && s_weather_humi) {
        const weather_t *w = app_weather_get();
        if (w->valid) {
            char t[16];
            snprintf(t, sizeof(t), "%.1f°C", (double)w->temp);
            lv_label_set_text(s_weather_temp, t);

            // WMO 天气代码 → 描述文字 + 图标切换
            int c = w->code;
            const char *d;
            const lv_img_dsc_t *icon = NULL;
            if (c == 0)      { d = "Sunny";  icon = &w_icon_sunny_dsc; }
            else if (c <= 3) { d = "Cloudy"; icon = &w_icon_cloudy_dsc; }
            else if (c <= 48){ d = "Fog";    icon = NULL; }
            else if (c <= 67){ d = "Rain";   icon = &w_icon_rain_dsc; }
            else if (c <= 86){ d = "Snow";   icon = NULL; }
            else             { d = "Storm";  icon = &w_icon_storm_dsc; }
            lv_label_set_text(s_weather_desc, d);
            if (s_weather_icon && icon)
                lv_img_set_src(s_weather_icon, icon);

            char h[16];
            snprintf(h, sizeof(h), "Hum %d%%", w->humidity);
            lv_label_set_text(s_weather_humi, h);
        }
    }
}

// ============================================================
// BLE 状态更新
// ============================================================
void ui_home_set_ble_status(bool connected)
{
    if (!s_ble_label) return;

    if (connected) {
        lv_label_set_text(s_ble_label, "PostureCam Connected");
        lv_obj_set_style_text_color(s_ble_label, UI_COLOR_CONNECTED, 0);
        if (s_posture_circle)
            lv_obj_set_style_bg_color(s_posture_circle, UI_COLOR_CONNECTED, LV_PART_MAIN);
    } else {
        lv_label_set_text(s_ble_label, "Searching...");
        lv_obj_set_style_text_color(s_ble_label, HOME_COLOR_GOLDEN, 0);
        if (s_posture_circle)
            lv_obj_set_style_bg_color(s_posture_circle, lv_color_hex(0x666666), LV_PART_MAIN);
    }
}

void ui_home_set_posture_score(float score)
{
    if (!s_posture_circle) return;
    lv_color_t c;
    if (score >= 80)      c = UI_COLOR_SAFE_GREEN;     // 优秀·绿
    else if (score >= 60) c = HOME_COLOR_GOLDEN;        // 一般·黄
    else if (score > 0)   c = UI_COLOR_ALERT_RED;       // 差·红
    else                  c = lv_color_hex(0x666666);   // 无数据·灰
    lv_obj_set_style_bg_color(s_posture_circle, c, LV_PART_MAIN);
}
