#include "cn_press_unif.h"
extern const uint8_t cn_press_unif_map[];
const lv_img_dsc_t cn_press_unif_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 94,
    .header.h = 21,
    .data_size = 3948,
    .data = cn_press_unif_map,
};
