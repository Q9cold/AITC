#pragma once
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float temp;          // ℃ 当前温度
    int   humidity;      // %  相对湿度
    int   code;          // WMO weather code
    float feels_like;    // ℃ 体感温度
    float wind_speed;    // km/h 风速
    float daily_max;     // ℃ 今日最高
    float daily_min;     // ℃ 今日最低
    int   precip_prob;   // %  降水概率
    char  city[32];      // IP 定位城市名（英文，可用 LVGL 字体渲染）
    bool  valid;         // data valid
} weather_t;

void app_weather_init(void);
const weather_t *app_weather_get(void);

#ifdef __cplusplus
}
#endif
