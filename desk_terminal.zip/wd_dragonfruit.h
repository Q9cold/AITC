#pragma once
#include "lvgl.h"
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t wd_dragonfruit_map[];
extern const lv_img_dsc_t wd_dragonfruit_dsc;
#ifdef __cplusplus
}
#endif
