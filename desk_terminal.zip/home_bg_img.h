/**
 * @file home_bg_img.h
 * @brief 首页背景图 — extern 声明
 *
 * 800×400 RGB565 背景。
 * 像素数据在 home_bg_img.S（.incbin 嵌入 home_bg_img.bin）
 * 描述符在 home_bg_img.c
 */

#pragma once

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

/** 原始 RGB565 像素数据（由汇编文件定义） */
extern const uint8_t home_bg_img_map[];

/** LVGL 图像描述符 */
extern const lv_img_dsc_t home_bg_img;

#ifdef __cplusplus
}
#endif
