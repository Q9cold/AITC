#include "wd_pear.h"
extern const uint8_t wd_pear_map[];
const lv_img_dsc_t wd_pear_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 200,
    .header.h = 180,
    .data_size = 72000,
    .data = wd_pear_map,
};
