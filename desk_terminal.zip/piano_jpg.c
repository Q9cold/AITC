#include "piano_jpg.h"
extern const uint8_t piano_jpg_map[];
const lv_img_dsc_t piano_jpg_dsc = {
    .header.cf = LV_IMG_CF_RAW,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 250,
    .header.h = 200,
    .data_size = 23804,
    .data = piano_jpg_map,
};
