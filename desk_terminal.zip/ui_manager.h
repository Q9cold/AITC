/**
 * @file ui_manager.h
 * @brief UI 管理器 — 屏幕切换、数据轮询、生命周期管理
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 UI 管理器
 *
 * 创建所有屏幕（时钟/统计/设置）、警告覆盖层、状态栏、底部 Tab 栏。
 * 启动数据轮询 lv_timer。
 */
void ui_manager_init(void);

#ifdef __cplusplus
}
#endif
