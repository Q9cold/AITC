/**
 * @file app_wifi_time.h
 * @brief WiFi STA 连接 + SNTP 网络时间同步
 *
 * 连接 WiFi 获取 NTP 时间，为时钟页面提供准确的北京时间。
 * 失败时回退到编译时默认时间。
 */

#pragma once

#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 WiFi STA 并同步 NTP 时间
 *
 * 阻塞等待 WiFi 连接（最多 15 秒），然后从 NTP 服务器同步时间。
 * WiFi 连接失败不会阻塞系统，时钟将从默认值开始走。
 */
void app_wifi_time_init(void);

/**
 * @brief 获取当前时间字符串
 * @param buf  输出缓冲区
 * @param size 缓冲区大小
 * @param fmt  格式字符串（如 "%H:%M:%S" 或 "%Y-%m-%d %A"）
 */
void app_get_time_str(char *buf, size_t size, const char *fmt);

/**
 * @brief 获取当前本地时间结构
 */
struct tm app_get_local_time(void);

#ifdef __cplusplus
}
#endif
