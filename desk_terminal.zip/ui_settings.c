/**
 * @file ui_settings.c
 * @brief 设置页面 — 亮度调节、报警开关、关于信息
 */
#include "ui_settings.h"
#include "ui_common.h"
#include "data_model.h"
#include <stdio.h>

static lv_obj_t *s_switch = NULL;

static void switch_event_cb(lv_event_t *e)
{
    // 告警开关由 ui_settings_alert_enabled() 查询
}

lv_obj_t *ui_settings_create(lv_obj_t *parent)
{
    lv_obj_t *page = lv_obj_create(parent);
    lv_obj_set_size(page, LV_HOR_RES, LV_VER_RES - 80);
    lv_obj_set_style_bg_color(page, UI_COLOR_BG, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(page, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(page, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_pad_all(page, 20, LV_PART_MAIN);

    lv_obj_t *title = ui_common_create_title(page, "Settings");
    lv_obj_align(title, LV_ALIGN_TOP_LEFT, 0, 10);

    // === 连接信息 ===
    lv_obj_t *card1 = ui_common_create_card(page, 760, 100);
    lv_obj_align(card1, LV_ALIGN_TOP_LEFT, 0, 60);

    lv_obj_t *info_title = lv_label_create(card1);
    lv_label_set_text(info_title, "Connection Info");
    lv_obj_set_style_text_color(info_title, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(info_title, &lv_font_montserrat_16, 0);
    lv_obj_align(info_title, LV_ALIGN_TOP_LEFT, 0, 5);

    // 左栏
    lv_obj_t *left = lv_label_create(card1);
    lv_label_set_text(left, "WiFi: what\nIP: 10.45.232.92");
    lv_obj_set_style_text_color(left, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(left, &lv_font_montserrat_14, 0);
    lv_obj_align(left, LV_ALIGN_TOP_LEFT, 0, 28);
    // 右栏
    lv_obj_t *right = lv_label_create(card1);
    lv_label_set_text(right, "MAC: dc:b4:d9:28:0b:c2\nBLE: PostureTerminal");
    lv_obj_set_style_text_color(right, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(right, &lv_font_montserrat_14, 0);
    lv_obj_align(right, LV_ALIGN_TOP_RIGHT, 0, 28);

    // === 报警开关 ===
    lv_obj_t *card2 = ui_common_create_card(page, 760, 70);
    lv_obj_align(card2, LV_ALIGN_TOP_LEFT, 0, 200);

    lv_obj_t *switch_label = lv_label_create(card2);
    lv_label_set_text(switch_label, "Alert Switch");
    lv_obj_set_style_text_color(switch_label, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(switch_label, &lv_font_montserrat_16, 0);
    lv_obj_align(switch_label, LV_ALIGN_LEFT_MID, 0, 0);

    s_switch = lv_switch_create(card2);
    lv_obj_align(s_switch, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_add_state(s_switch, LV_STATE_CHECKED);
    lv_obj_add_event_cb(s_switch, switch_event_cb, LV_EVENT_VALUE_CHANGED, NULL);

    // === 关于 ===
    lv_obj_t *card3 = ui_common_create_card(page, 760, 90);
    lv_obj_align(card3, LV_ALIGN_TOP_LEFT, 0, 290);

    lv_obj_t *about_title = lv_label_create(card3);
    lv_label_set_text(about_title, "About");
    lv_obj_set_style_text_color(about_title, UI_COLOR_TEXT_WHITE, 0);
    lv_obj_set_style_text_font(about_title, &lv_font_montserrat_16, 0);
    lv_obj_align(about_title, LV_ALIGN_TOP_LEFT, 0, 5);

    lv_obj_t *about_text = lv_label_create(card3);
    lv_label_set_text(about_text,
        "PostureTerminal v1.0\n"
        "BLE Health Monitor");
    lv_obj_set_style_text_color(about_text, UI_COLOR_TEXT_GRAY, 0);
    lv_obj_set_style_text_font(about_text, &lv_font_montserrat_14, 0);
    lv_obj_align(about_text, LV_ALIGN_TOP_LEFT, 0, 30);

    return page;
}

bool ui_settings_alert_enabled(void)
{
    return s_switch && lv_obj_has_state(s_switch, LV_STATE_CHECKED);
}

void ui_settings_update_from_remote(float safe_distance, bool alert_enabled)
{
    (void)safe_distance;
    if (s_switch) {
        if (alert_enabled) lv_obj_add_state(s_switch, LV_STATE_CHECKED);
        else lv_obj_clear_state(s_switch, LV_STATE_CHECKED);
    }
}
