#include "cn_posture_warn.h"
extern const uint8_t cn_posture_warn_map[];
const lv_img_dsc_t cn_posture_warn_dsc = {
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .header.always_zero = 0,
    .header.reserved = 0,
    .header.w = 184,
    .header.h = 25,
    .data_size = 9200,
    .data = cn_posture_warn_map,
};
