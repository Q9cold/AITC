/**
 * @file data_model.c
 * @brief 中央数据模型实现
 */

#include "data_model.h"
#include "esp_log.h"

static const char *TAG = "data_model";

// ============================================================
// 全局队列句柄
// ============================================================
QueueHandle_t xQueuePostureData  = NULL;
QueueHandle_t xQueuePostureStats = NULL;
QueueHandle_t xQueueConfigWrite  = NULL;
QueueHandle_t xQueueVoiceCmd     = NULL;
QueueHandle_t xQueuePressAlert   = NULL;
QueueHandle_t xQueuePostureScores = NULL;

// ============================================================
// 缓存状态
// ============================================================
posture_data_t  g_last_posture = {0};
posture_stats_t g_last_stats   = {0};
ble_conn_status_t g_ble_status = BLE_STATUS_DISCONNECTED;
press_alert_t   g_last_press_alert = { .is_bad = false };
posture_scores_t g_last_scores = {0};

// ============================================================
void data_model_init(void)
{
    xQueuePostureData  = xQueueCreate(4, sizeof(posture_data_t));
    xQueuePostureStats = xQueueCreate(2, sizeof(posture_stats_t));
    xQueueConfigWrite  = xQueueCreate(2, sizeof(config_write_t));
    xQueueVoiceCmd     = xQueueCreate(4, sizeof(voice_cmd_t));
    xQueuePressAlert   = xQueueCreate(4, sizeof(press_alert_t));
    xQueuePostureScores = xQueueCreate(4, sizeof(posture_scores_t));

    if (!xQueuePostureData || !xQueuePostureStats || !xQueueConfigWrite ||
        !xQueueVoiceCmd || !xQueuePressAlert || !xQueuePostureScores) {
        ESP_LOGE(TAG, "Failed to create data queues");
    } else {
        ESP_LOGI(TAG, "Data model initialized (5 queues)");
    }
}

const posture_data_t *data_model_get_posture(void)
{
    return &g_last_posture;
}

const posture_stats_t *data_model_get_stats(void)
{
    return &g_last_stats;
}

void data_model_set_ble_status(ble_conn_status_t status)
{
    g_ble_status = status;
}

ble_conn_status_t data_model_get_ble_status(void)
{
    return g_ble_status;
}

bool data_model_queue_config(const config_write_t *cfg)
{
    if (!xQueueConfigWrite || !cfg) return false;
    return xQueueSend(xQueueConfigWrite, cfg, 0) == pdTRUE;
}
