#pragma once
#include "esp_err.h"
#ifdef __cplusplus
extern "C" {
#endif
esp_err_t app_udp_cmd_init(void);
void      app_udp_cmd_send_alert(const char *type);
#ifdef __cplusplus
}
#endif
