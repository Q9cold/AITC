/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * GPIO control module — button debounce + LED status patterns.
 */

#pragma once

#include "driver/gpio.h"
#include "esp_err.h"
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** LED pattern states */
typedef enum {
    LED_OFF = 0,
    LED_WIFI_CONNECTING,       /* slow blink ~1 Hz */
    LED_IDLE,                  /* solid on — listening for wake word */
    LED_RECORDING,             /* fast blink ~5 Hz (legacy) */
    LED_PROCESSING,            /* medium blink ~2.5 Hz (legacy) */
    LED_PLAYING,               /* double-blink pattern (legacy) */
    LED_ERROR,                 /* 3 quick blinks, pause, repeat */
    LED_WAKE_ACTIVE,           /* wake word detected — solid 200ms */
    LED_COMMAND_LISTENING,     /* MultiNet active — 1.5Hz blink */
    LED_RESPONDING,            /* playing response — gentle pulse */
    LED_CLOUD_QUERYING,        /* cloud query — double blink */
} led_state_t;

/**
 * @brief Initialize button GPIO (input with pull-up) and LED GPIO (output).
 *        Starts a FreeRTOS software timer for LED pattern generation.
 *
 * @param button_gpio  Button GPIO number
 * @param led_gpio     LED GPIO number
 */
esp_err_t gpio_control_init(gpio_num_t button_gpio, gpio_num_t led_gpio);

/**
 * @brief Set the LED state / blink pattern.
 */
void gpio_control_set_led_state(led_state_t state);

/**
 * @brief Check if button is currently pressed (debounced).
 */
bool gpio_control_is_button_pressed(void);

/**
 * @brief Block until button press detected.
 *
 * @param timeout_ms  0 = wait forever; >0 = timeout
 * @return true if press detected, false on timeout.
 */
bool gpio_control_wait_for_press(uint32_t timeout_ms);

/**
 * @brief Block until button release detected.
 *
 * @param timeout_ms  0 = wait forever; >0 = timeout
 * @return true if release detected, false on timeout.
 */
bool gpio_control_wait_for_release(uint32_t timeout_ms);

#ifdef __cplusplus
}
#endif
