/*
 * Board Audio Init — ES8311 + I2S implementation.
 *
 * Uses esp_codec_dev (managed component) for ES8311 codec control.
 * Creates a duplex I2S channel: TX for speaker, RX for microphone,
 * sharing MCLK/BCLK/WS from the same I2S port.
 */

#include "board_audio_init.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_rom_sys.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "driver/i2s_std.h"
#include "driver/i2s_tdm.h"
#include "esp_codec_dev.h"
#include "esp_codec_dev_defaults.h"
#include "es7210_adc.h"

static const char *TAG = "board_audio";

/* ─── I2C & GPIO pin definitions (xr-ai-cam board) ─── */
#define I2C_PORT          I2C_NUM_1
#define I2C_SDA_IO        1
#define I2C_SCL_IO        2

#define I2S_PORT          I2S_NUM_0
#define I2S_MCLK_IO       38
#define I2S_BCLK_IO       14
#define I2S_WS_IO         13
#define I2S_DOUT_IO       45
#define I2S_DIN_IO        12

#define ES8311_ADDR       0x30  /* ES8311_CODEC_DEFAULT_ADDR (8-bit) */
#define ES7210_ADDR       0x82  /* ES7210 ADC I2C address */

/* ─── Static handles ─── */
static i2c_master_bus_handle_t  s_i2c_bus = NULL;
static i2s_chan_handle_t        s_tx_handle = NULL;
static i2s_chan_handle_t        s_rx_handle = NULL;
static esp_codec_dev_handle_t   s_output_dev = NULL;
static esp_codec_dev_handle_t   s_input_dev = NULL;
static bool                     s_initialized = false;
static bool                     s_output_enabled = false;
static bool                     s_input_enabled = false;
static int                      s_output_volume = 70;

/* ─── I2C bus recovery: clock SCL 9 times to unstick a hung slave ─── */
static void i2c_bus_recover(void)
{
    gpio_config_t scl_cfg = {
        .pin_bit_mask = (1ULL << I2C_SCL_IO),
        .mode = GPIO_MODE_OUTPUT_OD,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
    };
    gpio_config(&scl_cfg);
    /* 9 clock pulses with SDA released — standard I2C recovery */
    for (int i = 0; i < 9; i++) {
        gpio_set_level(I2C_SCL_IO, 0);
        esp_rom_delay_us(10);
        gpio_set_level(I2C_SCL_IO, 1);
        esp_rom_delay_us(10);
    }
    ESP_LOGI(TAG, "I2C bus recovery: 9 SCL pulses done");
}

/* ─── I2C master init ─── */
static esp_err_t init_i2c(void)
{
    /* Step 1: read RAW GPIO state before ANY configuration */
    int raw_sda = gpio_get_level(I2C_SDA_IO);
    int raw_scl = gpio_get_level(I2C_SCL_IO);
    ESP_LOGI(TAG, "I2C RAW (before config): SDA(GPIO%d)=%d SCL(GPIO%d)=%d",
             I2C_SDA_IO, raw_sda, I2C_SCL_IO, raw_scl);

    /* Step 2: try bus recovery if SDA is stuck */
    if (raw_sda == 0) {
        ESP_LOGW(TAG, "SDA stuck LOW before init — attempting bus recovery...");
        i2c_bus_recover();
        raw_sda = gpio_get_level(I2C_SDA_IO);
        ESP_LOGI(TAG, "I2C after recovery: SDA=%d SCL=%d", raw_sda, gpio_get_level(I2C_SCL_IO));
    }

    i2c_master_bus_config_t i2c_cfg = {
        .i2c_port = I2C_PORT,
        .sda_io_num = I2C_SDA_IO,
        .scl_io_num = I2C_SCL_IO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags = { .enable_internal_pullup = true },
    };
    esp_err_t err = i2c_new_master_bus(&i2c_cfg, &s_i2c_bus);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "I2C master init failed: %d", err);
        return err;
    }

    /* Diagnostic: read GPIO state and probe ES8311 */
    int sda = gpio_get_level(I2C_SDA_IO);
    int scl = gpio_get_level(I2C_SCL_IO);
    ESP_LOGI(TAG, "I2C GPIO state: SDA(GPIO%d)=%d SCL(GPIO%d)=%d",
             I2C_SDA_IO, sda, I2C_SCL_IO, scl);

    ESP_LOGI(TAG, "Probing ES8311 at 0x%02X...", ES8311_ADDR);
    err = i2c_master_probe(s_i2c_bus, ES8311_ADDR, 100);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "ES8311 ACK at 0x%02X", ES8311_ADDR);
    } else if (err == ESP_ERR_TIMEOUT) {
        ESP_LOGE(TAG, "ES8311 probe TIMEOUT → bus stuck or no pull-up (SDA=%d SCL=%d)", sda, scl);
    } else {
        ESP_LOGE(TAG, "ES8311 probe NACK at 0x%02X (err=%d) → device absent / wrong addr / no reset",
                 ES8311_ADDR, err);
    }

    return ESP_OK;
}

/* ─── I2S duplex init (TX + RX, shared clock) ─── */
static esp_err_t init_i2s(uint32_t sample_rate)
{
    /* Create duplex channel (TX for speaker + RX for ES7210 mic) */
    i2s_chan_config_t chan_cfg = {
        .id = I2S_PORT,
        .role = I2S_ROLE_MASTER,
        .dma_desc_num = 6,
        .dma_frame_num = 240,
        .auto_clear_after_cb = true,
        .auto_clear_before_cb = false,
    };
    esp_err_t err = i2s_new_channel(&chan_cfg, &s_tx_handle, &s_rx_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "I2S new channel failed: %d", err);
        return err;
    }

    /* TX (speaker) — stereo 16/32 standard I2S → ES8311.
     * MUST be stereo to produce a 64-bit WS frame matching
     * the TDM RX (4ch×16bit = 64-bit). Mono would produce
     * a 32-bit WS, which breaks ES7210 TDM clocking. */
    i2s_std_config_t std_cfg = {
        .clk_cfg = {
            .sample_rate_hz = sample_rate,
            .clk_src = I2S_CLK_SRC_DEFAULT,
            .mclk_multiple = I2S_MCLK_MULTIPLE_256,
        },
        .slot_cfg = {
            .data_bit_width = I2S_DATA_BIT_WIDTH_16BIT,
            .slot_bit_width = I2S_SLOT_BIT_WIDTH_AUTO,
            .slot_mode = I2S_SLOT_MODE_STEREO,
            .slot_mask = I2S_STD_SLOT_BOTH,
            .ws_width = I2S_DATA_BIT_WIDTH_16BIT,
            .ws_pol = false,
            .bit_shift = true,
            .left_align = true,
            .big_endian = false,
            .bit_order_lsb = false,
        },
        .gpio_cfg = {
            .mclk = I2S_MCLK_IO,
            .bclk = I2S_BCLK_IO,
            .ws = I2S_WS_IO,
            .dout = I2S_DOUT_IO,
            .din = I2S_GPIO_UNUSED,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };
    err = i2s_channel_init_std_mode(s_tx_handle, &std_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "I2S TX init failed: %d", err);
        return err;
    }

    /* RX (microphone) — TDM mode for ES7210 4-channel ADC */
    i2s_tdm_config_t tdm_cfg = {
        .clk_cfg = {
            .sample_rate_hz = sample_rate,
            .clk_src = I2S_CLK_SRC_DEFAULT,
            .mclk_multiple = I2S_MCLK_MULTIPLE_256,
            .bclk_div = 8,
        },
        .slot_cfg = {
            .data_bit_width = I2S_DATA_BIT_WIDTH_16BIT,
            .slot_bit_width = I2S_SLOT_BIT_WIDTH_AUTO,
            .slot_mode = I2S_SLOT_MODE_STEREO,
            .slot_mask = (i2s_tdm_slot_mask_t)(I2S_TDM_SLOT0 | I2S_TDM_SLOT1 | I2S_TDM_SLOT2 | I2S_TDM_SLOT3),
            .ws_width = I2S_TDM_AUTO_WS_WIDTH,
            .ws_pol = false,
            .bit_shift = true,
            .left_align = false,
            .big_endian = false,
            .bit_order_lsb = false,
            .skip_mask = false,
            .total_slot = I2S_TDM_AUTO_SLOT_NUM,
        },
        .gpio_cfg = {
            .mclk = I2S_MCLK_IO,
            .bclk = I2S_BCLK_IO,
            .ws = I2S_WS_IO,
            .dout = I2S_GPIO_UNUSED,
            .din = I2S_DIN_IO,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };
    err = i2s_channel_init_tdm_mode(s_rx_handle, &tdm_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "I2S RX TDM init failed: %d", err);
        return err;
    }

    /* Enable TX+RX now: TX for MCLK (required by ES7210), RX for TDM data */
    i2s_channel_enable(s_tx_handle);
    i2s_channel_enable(s_rx_handle);

    ESP_LOGI(TAG, "I2S duplex: %dHz mclk=GPIO%d bclk=GPIO%d ws=GPIO%d dout=GPIO%d din=GPIO%d",
             (int)sample_rate, I2S_MCLK_IO, I2S_BCLK_IO,
             I2S_WS_IO, I2S_DOUT_IO, I2S_DIN_IO);
    return ESP_OK;
}

/* ─── ES8311 codec init ─── */
static esp_err_t init_es8311(void)
{
    /* Data interface (I2S) */
    audio_codec_i2s_cfg_t i2s_cfg = {
        .port = I2S_PORT,
        .rx_handle = s_rx_handle,
        .tx_handle = s_tx_handle,
    };
    const audio_codec_data_if_t *data_if = audio_codec_new_i2s_data(&i2s_cfg);
    if (data_if == NULL) {
        ESP_LOGE(TAG, "audio_codec_new_i2s_data failed");
        return ESP_FAIL;
    }

    /* I2C control interface */
    audio_codec_i2c_cfg_t i2c_cfg = {
        .port = I2C_PORT,
        .addr = ES8311_ADDR,
        .bus_handle = s_i2c_bus,
    };
    const audio_codec_ctrl_if_t *ctrl_if = audio_codec_new_i2c_ctrl(&i2c_cfg);
    if (ctrl_if == NULL) {
        ESP_LOGE(TAG, "audio_codec_new_i2c_ctrl failed");
        return ESP_FAIL;
    }

    /* GPIO interface for PA pin (none in this board — ES8311 drives speaker directly) */
    const audio_codec_gpio_if_t *gpio_if = audio_codec_new_gpio();
    if (gpio_if == NULL) {
        ESP_LOGE(TAG, "audio_codec_new_gpio failed");
        return ESP_FAIL;
    }

    /* ES8311 codec (DAC only) */
    es8311_codec_cfg_t es8311_cfg = {
        .ctrl_if = ctrl_if,
        .gpio_if = gpio_if,
        .codec_mode = ESP_CODEC_DEV_WORK_MODE_DAC,
        .pa_pin = GPIO_NUM_NC,       /* No external PA */
        .use_mclk = true,
        .hw_gain = {
            .pa_voltage = 5.0,
            .codec_dac_voltage = 3.3,
        },
    };
    const audio_codec_if_t *codec_if = es8311_codec_new(&es8311_cfg);
    if (codec_if == NULL) {
        int sda = gpio_get_level(I2C_SDA_IO);
        int scl = gpio_get_level(I2C_SCL_IO);
        ESP_LOGE(TAG, "es8311_codec_new FAILED → I2C GPIO state: SDA=%d SCL=%d", sda, scl);
        if (sda == 0 && scl == 0) {
            ESP_LOGE(TAG, "  → SDA/SCL both LOW: bus stuck, pull-up missing, or short");
        } else if (sda == 0) {
            ESP_LOGE(TAG, "  → SDA stuck LOW: device holding bus, check reset");
        } else {
            ESP_LOGE(TAG, "  → SDA/SCL HIGH but no ACK: device absent or wrong address");
        }
        return ESP_FAIL;
    }

    /* Create output device */
    esp_codec_dev_cfg_t dev_cfg = {
        .dev_type = ESP_CODEC_DEV_TYPE_OUT,
        .codec_if = codec_if,
        .data_if = data_if,
    };
    s_output_dev = esp_codec_dev_new(&dev_cfg);
    if (s_output_dev == NULL) {
        ESP_LOGE(TAG, "esp_codec_dev_new failed");
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "ES8311 codec initialized (I2C addr=0x%02x)", ES8311_ADDR);

    /* ─── ES7210 ADC init (microphone input) ─── */
    ESP_LOGI(TAG, "Starting ES7210 init...");
    {
        audio_codec_i2c_cfg_t es7210_i2c = {
            .port = I2C_PORT,
            .addr = ES7210_ADDR,
            .bus_handle = s_i2c_bus,
        };
        const audio_codec_ctrl_if_t *in_ctrl = audio_codec_new_i2c_ctrl(&es7210_i2c);
        if (in_ctrl == NULL) {
            ESP_LOGW(TAG, "ES7210 I2C ctrl failed — mic unavailable");
            return ESP_OK;  /* Speaker still works */
        }

        es7210_codec_cfg_t es7210_cfg = {
            .ctrl_if = in_ctrl,
            .mic_selected = (uint8_t)(ES7120_SEL_MIC1 | ES7120_SEL_MIC2 |
                                      ES7120_SEL_MIC3 | ES7120_SEL_MIC4),
        };
        const audio_codec_if_t *in_codec = es7210_codec_new(&es7210_cfg);
        if (in_codec == NULL) {
            ESP_LOGW(TAG, "ES7210 codec new failed — mic unavailable");
            return ESP_OK;
        }

        esp_codec_dev_cfg_t in_dev_cfg = {
            .dev_type = ESP_CODEC_DEV_TYPE_IN,
            .codec_if = in_codec,
            .data_if = data_if,
        };
        s_input_dev = esp_codec_dev_new(&in_dev_cfg);
        if (s_input_dev == NULL) {
            ESP_LOGW(TAG, "ES7210 dev new failed — mic unavailable");
            return ESP_OK;
        }

        ESP_LOGI(TAG, "ES7210 codec initialized (I2C addr=0x%02x)", ES7210_ADDR);

        /* Open input device to unmute ES7210 and start TDM output.
         * Actual data is read via raw I2S (board_audio_read is unused). */
        esp_codec_dev_sample_info_t fs = {
            .bits_per_sample = 16,
            .channel = 4,
            .channel_mask = ESP_CODEC_DEV_MAKE_CHANNEL_MASK(0),
            .sample_rate = 16000,
            .mclk_multiple = 0,
        };
        esp_err_t in_err = esp_codec_dev_open(s_input_dev, &fs);
        if (in_err == ESP_OK) {
            s_input_enabled = true;
            ESP_LOGI(TAG, "ES7210 input opened");
        } else {
            ESP_LOGW(TAG, "ES7210 open failed: %d", in_err);
        }
    }

    return ESP_OK;
}

/* ─── Public API ─── */

esp_err_t board_audio_init(uint32_t sample_rate)
{
    if (s_initialized) return ESP_OK;

    esp_err_t err = init_i2c();
    if (err != ESP_OK) return err;

    err = init_i2s(sample_rate);
    if (err != ESP_OK) return err;

    err = init_es8311();
    if (err != ESP_OK) return err;

    s_initialized = true;
    ESP_LOGI(TAG, "Board audio ready (ES8311 + I2S duplex)");
    return ESP_OK;
}

i2s_chan_handle_t board_audio_get_tx_handle(void)
{
    return s_tx_handle;
}

i2s_chan_handle_t board_audio_get_rx_handle(void)
{
    return s_rx_handle;  /* Shared TDM RX from ES7210 */
}

esp_err_t board_audio_write(const int16_t *data, size_t samples)
{
    if (!s_initialized || s_output_dev == NULL) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!s_output_enabled) {
        /* Open codec device on first write */
        esp_codec_dev_sample_info_t fs = {
            .bits_per_sample = 16,
            .channel = 1,
            .channel_mask = 0,
            .sample_rate = 16000,
            .mclk_multiple = 0,
        };
        esp_err_t err = esp_codec_dev_open(s_output_dev, &fs);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "esp_codec_dev_open failed: %d", err);
            return err;
        }
        esp_codec_dev_set_out_vol(s_output_dev, s_output_volume);
        s_output_enabled = true;
        ESP_LOGI(TAG, "Codec output enabled (vol=%d)", s_output_volume);
    }

    return esp_codec_dev_write(s_output_dev, (void *)data, samples * sizeof(int16_t));
}

int board_audio_read(int16_t *data, size_t samples, uint32_t timeout_ms)
{
    if (!s_initialized || s_input_dev == NULL) {
        return -1;
    }

    if (!s_input_enabled) {
        esp_codec_dev_sample_info_t fs = {
            .bits_per_sample = 16,
            .channel = 4,
            .channel_mask = ESP_CODEC_DEV_MAKE_CHANNEL_MASK(0),
            .sample_rate = 16000,
            .mclk_multiple = 0,
        };
        esp_err_t err = esp_codec_dev_open(s_input_dev, &fs);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "ES7210 open failed: %d", err);
            return -1;
        }
        s_input_enabled = true;
        ESP_LOGI(TAG, "Codec input enabled (ES7210)");
    }

    int ret = esp_codec_dev_read(s_input_dev, (void *)data,
                                  (int)(samples * sizeof(int16_t)));
    static int dbg = 0;
    if (++dbg <= 3) {
        ESP_LOGI(TAG, "esp_codec_dev_read returned %d", ret);
    }
    if (ret < 0) {
        return -1;
    }
    return ret / sizeof(int16_t);
}

bool board_audio_has_input(void)
{
    return s_input_dev != NULL;
}

void board_audio_enable_output(bool enable)
{
    if (s_output_dev == NULL) return;

    if (enable && !s_output_enabled) {
        esp_codec_dev_sample_info_t fs = {
            .bits_per_sample = 16,
            .channel = 1,
            .sample_rate = 16000,
            .mclk_multiple = 0,
        };
        esp_codec_dev_open(s_output_dev, &fs);
        esp_codec_dev_set_out_vol(s_output_dev, s_output_volume);
        s_output_enabled = true;
    } else if (!enable && s_output_enabled) {
        esp_codec_dev_close(s_output_dev);
        s_output_enabled = false;
    }
}

void board_audio_set_volume(int volume)
{
    if (volume < 0) volume = 0;
    if (volume > 100) volume = 100;
    s_output_volume = volume;
    if (s_output_dev != NULL && s_output_enabled) {
        esp_codec_dev_set_out_vol(s_output_dev, volume);
    }
}

void board_audio_deinit(void)
{
    if (s_output_dev != NULL) {
        esp_codec_dev_close(s_output_dev);
        esp_codec_dev_delete(s_output_dev);
        s_output_dev = NULL;
    }
    if (s_tx_handle != NULL) {
        i2s_channel_disable(s_tx_handle);
        i2s_del_channel(s_tx_handle);
        s_tx_handle = NULL;
    }
    /* RX is managed by afe_runner on a separate I2S port */
    if (s_i2c_bus != NULL) {
        i2c_del_master_bus(s_i2c_bus);
        s_i2c_bus = NULL;
    }
    s_initialized = false;
    s_output_enabled = false;
}
