/*
 * Command Definitions — pinyin command list for MultiNet
 * and corresponding intent mappings for the intent engine.
 *
 * COMMANDS FORMAT: space-separated pinyin (no tones).
 * MultiNet 6_cn recognizes pinyin, up to 200 commands.
 *
 * Add/modify commands here — this is the single source of truth.
 */

#include "command_config.h"
#include "intent_engine.h"

/* ─── Pinyin string list for MultiNet 6_cn (NULL-terminated) ─── */
const char *g_cmd_pinyin_list[] = {
    /* Greetings */
    "ni hao",                                    /*  0 */
    "ni hao xiao zhi",                           /*  1 */
    "ni jiao shen me ming zi",                   /*  2 */
    "zai jian",                                  /*  3 */

    /* Light control */
    "da kai deng guang",                         /*  4 */
    "guan bi deng guang",                        /*  5 */
    "tiao liang deng guang",                     /*  6 */
    "tiao an deng guang",                        /*  7 */
    "deng guang liang yi dian",                  /*  8 */
    "deng guang an yi dian",                     /*  9 */

    /* Fan control */
    "da kai feng shan",                          /* 10 */
    "guan bi feng shan",                         /* 11 */
    "feng shan kuai yi dian",                    /* 12 */
    "feng shan man yi dian",                     /* 13 */

    /* Temperature */
    "xian zai wen du duo shao",                  /* 14 */
    "jin tian re bu re",                         /* 15 */

    /* Humidity */
    "xian zai shi du duo shao",                  /* 16 */

    /* Time */
    "xian zai ji dian",                          /* 17 */
    "xian zai ji dian zhong",                    /* 18 */

    /* Date */
    "jin tian ji yue ji hao",                    /* 19 */
    "jin tian xing qi ji",                       /* 20 */

    /* Volume */
    "yin liang da yi dian",                      /* 21 */
    "yin liang xiao yi dian",                    /* 22 */

    /* Music */
    "bo fang yin yue",                           /* 23 */
    "ting zhi bo fang",                          /* 24 */
    "ting zhi yin yue",                          /* 25 */

    /* Door control */
    "da kai men",                                /* 26 */
    "guan bi men",                               /* 27 */

    /* Cloud queries */
    "jin tian tian qi zen me yang",              /* 28 */
    "ming tian tian qi zen me yang",             /* 29 */
    "ming tian hui xia yu ma",                   /* 30 */
    "sou suo yi xia",                            /* 31 */
    "wo xiang liao jie yi xia",                  /* 32 */

    /* Extras */
    "jiang ge xiao hua",                         /* 33 */
    "ni hui zuo shen me",                        /* 34 */
    "xie xie ni",                                /* 35 */
    "wan an",                                    /* 36 */
    "zao shang hao",                             /* 37 */
    "xia wu hao",                                /* 38 */
    "wan shang hao",                             /* 39 */

    NULL  /* terminator */
};

/* ─── Command definition table (maps pinyin → intent + param) ───
 *  Param values act as WAV file selectors:
 *    rsp_<intent>_<param>.wav  (tried first when param > 0)
 *    rsp_<intent>.wav          (fallback) */
const cmd_def_t g_cmd_defs[] = {
    /* Greetings — unique param per variant for per-command WAV responses */
    {"ni hao",                     INTENT_GREETING,        "你好",            1},
    {"ni hao xiao zhi",            INTENT_GREETING,        "你好小智",        0},
    {"ni jiao shen me ming zi",    INTENT_SELF_INTRO,      "你叫什么名字",    0},
    {"zai jian",                   INTENT_GOODBYE,         "再见",            1},

    /* Light control */
    {"da kai deng guang",          INTENT_LIGHT_ON,        "打开灯光",        0},
    {"guan bi deng guang",         INTENT_LIGHT_OFF,       "关闭灯光",        0},
    {"tiao liang deng guang",      INTENT_LIGHT_BRIGHTNESS,"调亮灯光",        0},
    {"tiao an deng guang",         INTENT_LIGHT_BRIGHTNESS,"调暗灯光",        0},
    {"deng guang liang yi dian",   INTENT_LIGHT_BRIGHTNESS,"灯光亮一点",      0},
    {"deng guang an yi dian",      INTENT_LIGHT_BRIGHTNESS,"灯光暗一点",      0},

    /* Fan control */
    {"da kai feng shan",           INTENT_FAN_ON,          "打开风扇",        0},
    {"guan bi feng shan",          INTENT_FAN_OFF,         "关闭风扇",        0},
    {"feng shan kuai yi dian",     INTENT_FAN_SPEED,       "风扇快一点",      0},
    {"feng shan man yi dian",      INTENT_FAN_SPEED,       "风扇慢一点",      0},

    /* Temperature */
    {"xian zai wen du duo shao",   INTENT_TEMPERATURE_QUERY,"现在温度多少",   0},
    {"jin tian re bu re",          INTENT_TEMPERATURE_QUERY,"今天热不热",     0},

    /* Humidity */
    {"xian zai shi du duo shao",   INTENT_HUMIDITY_QUERY,  "现在湿度多少",    0},

    /* Time */
    {"xian zai ji dian",           INTENT_TIME_QUERY,      "现在几点",        0},
    {"xian zai ji dian zhong",     INTENT_TIME_QUERY,      "现在几点钟",      0},

    /* Date */
    {"jin tian ji yue ji hao",     INTENT_DATE_QUERY,      "今天几月几号",    0},
    {"jin tian xing qi ji",        INTENT_DATE_QUERY,      "今天星期几",      0},

    /* Volume — step 5 is handled in state machine */
    {"yin liang da yi dian",       INTENT_VOLUME_UP,       "音量大一点",      5},
    {"yin liang xiao yi dian",     INTENT_VOLUME_DOWN,     "音量小一点",      5},

    /* Music */
    {"bo fang yin yue",            INTENT_MUSIC_PLAY,      "播放音乐",        0},
    {"ting zhi bo fang",           INTENT_MUSIC_STOP,      "停止播放",        0},
    {"ting zhi yin yue",           INTENT_MUSIC_STOP,      "停止音乐",        0},

    /* Door */
    {"da kai men",                 INTENT_OPEN_DOOR,       "打开门",          0},
    {"guan bi men",                INTENT_CLOSE_DOOR,      "关闭门",          0},

    /* Cloud queries — param flags: 0=normal, 1=WiFi-reconnect */
    {"jin tian tian qi zen me yang",INTENT_CLOUD_QUERY,    "今天天气怎么样",  0},
    {"ming tian tian qi zen me yang",INTENT_CLOUD_QUERY,   "明天天气怎么样",  0},
    {"ming tian hui xia yu ma",     INTENT_CLOUD_QUERY,    "明天会下雨吗",    0},
    {"sou suo yi xia",              INTENT_CLOUD_QUERY,    "搜索一下",        1},
    {"wo xiang liao jie yi xia",    INTENT_CLOUD_QUERY,    "我想了解一下",   0},

    /* Extras */
    {"jiang ge xiao hua",          INTENT_JOKE,            "讲个笑话",        0},
    {"ni hui zuo shen me",         INTENT_SELF_INTRO,      "你会做什么",      0},
    {"xie xie ni",                 INTENT_GREETING,        "谢谢你",          2},
    {"wan an",                     INTENT_GOODBYE,         "晚安",            0},
    {"zao shang hao",              INTENT_GREETING,        "早上好",          3},
    {"xia wu hao",                 INTENT_GREETING,        "下午好",          4},
    {"wan shang hao",              INTENT_GREETING,        "晚上好",          5},
};

/* Auto-computed command count */
const int g_cmd_count = sizeof(g_cmd_defs) / sizeof(g_cmd_defs[0]);
