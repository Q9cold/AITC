/*
 * MultiNet Runner — MultiNet 6_cn command recognition wrapper.
 * Activated after wake word to recognize Chinese commands offline.
 * Uses ESP-SR MultiNet 6_cn model (~4.1MB PSRAM).
 *
 * 100% LOCAL neural network inference on ESP32-S3.
 */

#include "multinet_runner.h"
#include "esp_log.h"
#include "esp_mn_iface.h"
#include "esp_mn_models.h"
#include "esp_mn_speech_commands.h"
#include "model_path.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "multinet_runner";

/* ─── Static state ─── */
static esp_mn_iface_t    *s_mn_iface = NULL;
static model_iface_data_t *s_mn_data = NULL;
static srmodel_list_t    *s_mn_models = NULL;
static bool s_initialized = false;
static uint32_t s_timeout_ms = MULTINET_TIMEOUT_DEFAULT;
static TickType_t s_cmd_start_ticks = 0;
static bool s_listening = false;
static esp_mn_state_t s_mn_state = ESP_MN_STATE_DETECTING;
static const char **s_command_pinyin_list = NULL;
static int s_command_count = 0;
static SemaphoreHandle_t s_mutex = NULL;

#define MULTINET_CONF_THRESHOLD  0.0f   /* disabled during debug */

/* ─── Feed statistics ─── */
static int mn_feed_ct = 0, mn_detect_ct = 0, mn_timeout_ct = 0;
static TickType_t mn_stats_tick = 0;

esp_err_t multinet_runner_init(const char *model_partition_label,
                               const char **command_pinyin_list,
                               int command_count,
                               uint32_t timeout_ms)
{
    if (s_initialized) {
        ESP_LOGW(TAG, "Already initialized");
        return ESP_OK;
    }

    s_timeout_ms = timeout_ms;
    s_command_pinyin_list = command_pinyin_list;
    s_command_count = command_count;

    /* Load models from partition */
    s_mn_models = esp_srmodel_init(model_partition_label);
    if (s_mn_models == NULL || s_mn_models->num == 0) {
        ESP_LOGE(TAG, "Failed to load models");
        return ESP_FAIL;
    }

    /* Filter MultiNet model */
    char *mn_name = esp_srmodel_filter(s_mn_models, ESP_MN_PREFIX, NULL);
    if (mn_name == NULL) {
        ESP_LOGE(TAG, "No MultiNet model found");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "MultiNet model: %s", mn_name);

    /* Create MultiNet handle */
    s_mn_iface = (esp_mn_iface_t *)esp_mn_handle_from_name(mn_name);
    if (s_mn_iface == NULL) {
        ESP_LOGE(TAG, "esp_mn_handle_from_name failed");
        return ESP_FAIL;
    }

    s_mn_data = s_mn_iface->create(mn_name, s_timeout_ms);
    if (s_mn_data == NULL) {
        ESP_LOGE(TAG, "MultiNet create failed");
        return ESP_FAIL;
    }

    /* Register command phrases */
    if (command_pinyin_list != NULL && command_count > 0) {
        esp_mn_commands_clear();
        for (int i = 0; i < command_count; i++) {
            if (command_pinyin_list[i] == NULL) break;
            esp_err_t err = esp_mn_commands_add(i, (char *)command_pinyin_list[i]);
            if (err != ESP_OK) {
                ESP_LOGW(TAG, "Failed to add command %d: %s", i,
                         command_pinyin_list[i]);
            }
        }
        esp_mn_commands_update();
        ESP_LOGI(TAG, "Registered %d commands", command_count);
    }

    s_mutex = xSemaphoreCreateMutex();
    s_initialized = true;
    s_listening = false;
    mn_stats_tick = xTaskGetTickCount();

    int mn_chunk = s_mn_iface->get_samp_chunksize ?
        s_mn_iface->get_samp_chunksize(s_mn_data) : 0;
    ESP_LOGI(TAG, "MultiNet runner initialized (timeout=%lu ms, chunk=%d)",
             s_timeout_ms, mn_chunk);
    return ESP_OK;
}

esp_err_t multinet_runner_feed(const int16_t *pcm_data, size_t sample_count)
{
    if (!s_initialized || s_mn_iface == NULL || s_mn_data == NULL) {
        return ESP_ERR_INVALID_STATE;
    }
    if (pcm_data == NULL || sample_count == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    xSemaphoreTake(s_mutex, portMAX_DELAY);

    if (!s_listening) {
        s_listening = true;
        s_cmd_start_ticks = xTaskGetTickCount();
        ESP_LOGI(TAG, "MultiNet listening started");
    }

    s_mn_state = s_mn_iface->detect(s_mn_data, (int16_t *)pcm_data);
    mn_feed_ct++;

    /* Per-second stats */
    TickType_t now = xTaskGetTickCount();
    if (now - mn_stats_tick >= pdMS_TO_TICKS(1000)) {
        ESP_LOGI(TAG, "MN stats: feed=%d state=%d detect=%d timeout=%d",
                 mn_feed_ct, (int)s_mn_state, mn_detect_ct, mn_timeout_ct);
        mn_feed_ct = mn_detect_ct = mn_timeout_ct = 0;
        mn_stats_tick = now;
    }

    xSemaphoreGive(s_mutex);
    return ESP_OK;
}

esp_err_t multinet_runner_get_result(multinet_result_t *result)
{
    if (!s_initialized || result == NULL) {
        return ESP_ERR_INVALID_STATE;
    }

    memset(result, 0, sizeof(*result));

    /* Check timeout first */
    if (s_listening) {
        TickType_t elapsed = xTaskGetTickCount() - s_cmd_start_ticks;
        if (pdTICKS_TO_MS(elapsed) > s_timeout_ms) {
            ESP_LOGW(TAG, "MultiNet timeout (%lu ms)", s_timeout_ms);
            s_listening = false;
            return ESP_ERR_TIMEOUT;
        }
    }

    /* Not yet started — no result */
    if (!s_listening) {
        return ESP_ERR_NOT_FOUND;
    }

    xSemaphoreTake(s_mutex, portMAX_DELAY);

    /* Try to get result from MultiNet */
    if (s_mn_state == ESP_MN_STATE_DETECTED) {
        mn_detect_ct++;
        esp_mn_results_t *mn_res = s_mn_iface->get_results(s_mn_data);
        if (mn_res != NULL && mn_res->num > 0) {
            int cmd_id = mn_res->phrase_id[0];
            result->confidence = mn_res->prob[0];

            /* Always log raw result (even below threshold) */
            ESP_LOGI(TAG, "MN result: num=%d phrase_id[0]=%d prob[0]=%.3f",
                     mn_res->num, cmd_id, result->confidence);

            if (cmd_id >= 0 &&
                cmd_id < s_command_count &&
                s_command_pinyin_list != NULL &&
                s_command_pinyin_list[cmd_id] != NULL) {

                snprintf(result->command_str, sizeof(result->command_str),
                         "%s", s_command_pinyin_list[cmd_id]);

                ESP_LOGI(TAG, "Command detected: id=%d text=\"%s\" conf=%.2f",
                         cmd_id, result->command_str, result->confidence);

                if (result->confidence < MULTINET_CONF_THRESHOLD) {
                    ESP_LOGW(TAG, "Confidence %.2f below threshold %.2f",
                             result->confidence, MULTINET_CONF_THRESHOLD);
                }
            } else {
                ESP_LOGW(TAG, "Invalid command id: %d (max %d)",
                         cmd_id, s_command_count);
                s_listening = false;
                xSemaphoreGive(s_mutex);
                return ESP_ERR_NOT_FOUND;
            }

            s_listening = false;
            xSemaphoreGive(s_mutex);
            return ESP_OK;
        }
    } else if (s_mn_state == ESP_MN_STATE_TIMEOUT) {
        mn_timeout_ct++;
        ESP_LOGW(TAG, "MultiNet internal timeout");
        s_listening = false;
        xSemaphoreGive(s_mutex);
        return ESP_ERR_TIMEOUT;
    }

    xSemaphoreGive(s_mutex);
    return ESP_ERR_NOT_FOUND;
}

esp_err_t multinet_runner_reset(void)
{
    if (!s_initialized) return ESP_ERR_INVALID_STATE;

    xSemaphoreTake(s_mutex, portMAX_DELAY);
    s_listening = false;
    s_cmd_start_ticks = 0;

    if (s_mn_iface && s_mn_data) {
        s_mn_iface->clean(s_mn_data);
    }

    ESP_LOGI(TAG, "MultiNet reset");
    xSemaphoreGive(s_mutex);
    return ESP_OK;
}
