/*
 * Local Response — pre-recorded WAV playback from SPIFFS.
 * Plays audio responses based on matched intent.
 * Files are stored as /spiffs/rsp_<intent_id>.wav
 */

#pragma once
#include "esp_err.h"
#include "intent_engine.h"

#ifdef __cplusplus
extern "C" {
#endif

/** Initialize SPIFFS and local response subsystem */
esp_err_t local_response_init(void);

/** Play WAV response for a given intent. Blocks until done. */
esp_err_t local_response_play(intent_id_t intent, int32_t param);

/** Play generic "I don't understand" fallback */
esp_err_t local_response_play_unknown(void);

/** Play a greeting/chime on startup */
esp_err_t local_response_play_startup(void);

/** Play a random joke (rsp_joke_0~2.wav) */
esp_err_t local_response_play_joke(void);

/** Play a named WAV file from SPIFFS (e.g. "rsp_no_wifi.wav") */
esp_err_t local_response_play_named(const char *name);

/** Abort ongoing WAV playback (called from BLE callback context).
 *  Safe to call from any task. Sets a volatile flag checked between
 *  PCM chunks by play_wav_file(). */
void local_response_abort_playback(void);

/** Clear the abort flag (call after wake/alert is handled) */
void local_response_clear_abort(void);

/** Play an IoT alert WAV from /spiffs/rsp_alert_<type>.wav.
 *  Blocks until done (or aborted by a higher-priority alert).
 *  @param alert_type  Alert identifier (maps to filename) */
esp_err_t local_response_play_alert(int alert_type);

#ifdef __cplusplus
}
#endif
