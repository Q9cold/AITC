/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * GPIO control — button debounce + LED pattern state machine.
 */

#include "gpio_control.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include "esp_log.h"
#include "driver/gpio.h"

static const char *TAG = "gpio_control";

static gpio_num_t s_button_gpio;
static gpio_num_t s_led_gpio;
static led_state_t s_led_state = LED_OFF;
static TimerHandle_t s_led_timer;

/* LED pattern timer callback — 50ms period */
static void led_timer_cb(TimerHandle_t timer)
{
    static uint8_t tick = 0;
    tick++;

    int level = 0;

    switch (s_led_state) {
    case LED_OFF:
        level = 0;
        break;
    case LED_IDLE:
        level = 1;
        break;
    case LED_WIFI_CONNECTING:    /* 1 Hz: 500ms on, 500ms off */
        level = ((tick % 20) < 10) ? 1 : 0;
        break;
    case LED_RECORDING:          /* 5 Hz: 100ms on, 100ms off */
        level = ((tick % 4) < 2) ? 1 : 0;
        break;
    case LED_PROCESSING:         /* 2.5 Hz: 200ms on, 200ms off */
        level = ((tick % 8) < 4) ? 1 : 0;
        break;
    case LED_PLAYING:            /* double-blink: 50ms on, 50ms off, 50ms on, 350ms off */
        {
            int phase = tick % 10;
            level = (phase == 0 || phase == 2) ? 1 : 0;
        }
        break;
    case LED_ERROR:              /* 3 quick blinks (50ms), then 500ms pause */
        {
            int phase = tick % 16;
            level = (phase == 0 || phase == 2 || phase == 4) ? 1 : 0;
        }
        break;
    case LED_WAKE_ACTIVE:        /* solid on for wake acknowledgement */
        level = 1;
        break;
    case LED_COMMAND_LISTENING:  /* 1.5 Hz: 333ms on, 333ms off */
        level = ((tick % 14) < 7) ? 1 : 0;
        break;
    case LED_RESPONDING:         /* gentle pulse: 100ms on, 100ms off at ~5Hz */
        level = ((tick % 4) < 2) ? 1 : 0;
        break;
    case LED_CLOUD_QUERYING:     /* double-blink: 50ms on, 50ms off, 50ms on, 850ms off */
        {
            int phase = tick % 20;
            level = (phase == 0 || phase == 2) ? 1 : 0;
        }
        break;
    default:
        level = 0;
        break;
    }

    gpio_set_level(s_led_gpio, level);
}

esp_err_t gpio_control_init(gpio_num_t button_gpio, gpio_num_t led_gpio)
{
    s_button_gpio = button_gpio;
    s_led_gpio = led_gpio;

    /* Configure button: input with internal pull-up */
    gpio_config_t btn_cfg = {
        .pin_bit_mask = (1ULL << button_gpio),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&btn_cfg));

    /* Configure LED: output, initially low */
    gpio_config_t led_cfg = {
        .pin_bit_mask = (1ULL << led_gpio),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&led_cfg));
    gpio_set_level(led_gpio, 0);

    /* Create LED pattern timer at 50ms (20 Hz) */
    s_led_timer = xTimerCreate("led_timer", pdMS_TO_TICKS(50), pdTRUE, NULL, led_timer_cb);
    if (s_led_timer == NULL) {
        ESP_LOGE(TAG, "Failed to create LED timer");
        return ESP_ERR_NO_MEM;
    }
    xTimerStart(s_led_timer, 0);

    ESP_LOGI(TAG, "GPIO control initialized: btn=GPIO%d, led=GPIO%d", button_gpio, led_gpio);
    return ESP_OK;
}

void gpio_control_set_led_state(led_state_t state)
{
    s_led_state = state;
}

bool gpio_control_is_button_pressed(void)
{
    /* Software debounce: 3 consecutive reads must agree */
    int high_count = 0;
    for (int i = 0; i < 3; i++) {
        if (gpio_get_level(s_button_gpio) == 1) {
            high_count++;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    /* Button pressed = low (pull-up → ground when pressed) */
    return (high_count < 2);
}

bool gpio_control_wait_for_press(uint32_t timeout_ms)
{
    TickType_t start = xTaskGetTickCount();
    TickType_t timeout_ticks = (timeout_ms == 0) ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);

    while (1) {
        if (gpio_control_is_button_pressed()) {
            return true;
        }
        if (timeout_ms > 0) {
            TickType_t elapsed = xTaskGetTickCount() - start;
            if (elapsed >= timeout_ticks) {
                return false;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

bool gpio_control_wait_for_release(uint32_t timeout_ms)
{
    TickType_t start = xTaskGetTickCount();
    TickType_t timeout_ticks = (timeout_ms == 0) ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);

    while (1) {
        if (!gpio_control_is_button_pressed()) {
            return true;
        }
        if (timeout_ms > 0) {
            TickType_t elapsed = xTaskGetTickCount() - start;
            if (elapsed >= timeout_ticks) {
                return false;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
