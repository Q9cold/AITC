/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Audio Input — I2S PDM RX microphone (e.g., INMP441).
 * Records 16-bit mono PCM at configurable sample rate.
 */

#pragma once

#include "driver/i2s_common.h"
#include "hal/gpio_types.h"
#include "esp_err.h"
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Initialize I2S PDM RX channel for microphone recording.
 *
 * @param sample_rate_hz  Typically 16000 for Baidu ASR
 * @param clk_gpio        PDM clock GPIO
 * @param din_gpio        PDM data input GPIO
 * @return ESP_OK on success.
 */
esp_err_t audio_input_init(uint32_t sample_rate_hz,
                           gpio_num_t clk_gpio,
                           gpio_num_t din_gpio);

/**
 * @brief Record PCM audio into a caller-supplied buffer (blocking).
 *
 * @param buffer      Pre-allocated int16_t buffer
 * @param buf_size    Buffer size in bytes
 * @param timeout_ms  Maximum recording duration in ms
 * @return ESP_OK on success.
 */
esp_err_t audio_input_record(int16_t *buffer, size_t buf_size, uint32_t timeout_ms);

/**
 * @brief De-initialize and free the I2S PDM RX channel.
 */
esp_err_t audio_input_deinit(void);

#ifdef __cplusplus
}
#endif
