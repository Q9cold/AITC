/**
 * @file uart_cmd_tx.c
 * @brief UART bidirectional — GPIO19(TX)/GPIO20(RX), UART_NUM_1
 *        与终端分时复用 USB 引脚。
 */
#include "uart_cmd_tx.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "soc/usb_serial_jtag_reg.h"
#include "soc/usb_serial_jtag_struct.h"
#include <string.h>
#include <stdio.h>

static const char *TAG = "uart_cmd";
#define UART_PORT   UART_NUM_1
#define TX_PIN      17   // 普通 GPIO，不跟 USB D+/D- 冲突
#define RX_PIN      18
#define BAUD        115200
#define BUF_SIZE    512

static volatile bool              s_alert_pending;
static volatile uart_alert_type_t s_alert_type;

esp_err_t uart_cmd_tx_init(void)
{
    // 1. 断开 USB Serial/JTAG PHY 与 GPIO19/20 的物理连接
    USB_SERIAL_JTAG.conf0.usb_pad_enable = 0;

    // 2. 复位 IO MUX，将 GPIO19/20 从 USB 功能切为普通 GPIO
    gpio_reset_pin(TX_PIN);
    gpio_reset_pin(RX_PIN);

    // 3. 配置 UART1
    uart_config_t cfg = {
        .baud_rate = BAUD, .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE, .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE, .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_driver_install(UART_PORT, BUF_SIZE*2, BUF_SIZE, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_PORT, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(UART_PORT, TX_PIN, RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    gpio_set_direction(TX_PIN, GPIO_MODE_OUTPUT);
    gpio_set_direction(RX_PIN, GPIO_MODE_INPUT);
    gpio_set_pull_mode(RX_PIN, GPIO_PULLUP_ONLY);
    printf("[UART] init OK TX=GPIO%d RX=GPIO%d\n", TX_PIN, RX_PIN);
    gpio_dump_io_configuration(stdout, (1ULL << TX_PIN) | (1ULL << RX_PIN));
    return ESP_OK;
}

void uart_cmd_send(const char *text)
{
    if (!text) return;
    char buf[256];
    int len = snprintf(buf, sizeof(buf), "CMD:%s\n", text);
    uart_write_bytes(UART_PORT, (const uint8_t*)buf, len);
}

void uart_cmd_send_intent(int id)
{
    static const char *t[] = {
        [0]="未知命令",[1]="打开灯光",[2]="关闭灯光",[3]="调亮度",
        [4]="打开风扇",[5]="关闭风扇",[6]="调风速",[7]="查询温度",
        [8]="查询湿度",[9]="查询时间",[10]="查询日期",[11]="音量加大",
        [12]="音量减小",[13]="播放音乐",[14]="停止播放",[15]="打开门",
        [16]="关闭门",[17]="你好",[18]="再见",[19]="自我介绍",[20]="云端查询",
    };
    int n = sizeof(t)/sizeof(t[0]);
    if (id >= 0 && id < n && t[id]) uart_cmd_send(t[id]);
}

// ============================================================
// RX — 接收终端告警
// ============================================================
static void parse_alert(const char *line, int len)
{
    if (len < 6 || strncmp(line, "ALERT:", 6)) return;
    const char *type = line + 6;
    int tl = len - 6;
    while (tl > 0 && (type[tl-1]=='\n'||type[tl-1]=='\r')) tl--;
    if (!strncmp(type, "posture", tl))      { s_alert_type = UART_ALERT_POSTURE; s_alert_pending = true; }
    else if (!strncmp(type, "press", tl))   { s_alert_type = UART_ALERT_PRESS;   s_alert_pending = true; }
    else if (!strncmp(type, "test", tl))    { printf("[UART] RX: ALERT:test from terminal\n"); }
}

static void rx_task(void *arg)
{
    uint8_t *buf = malloc(BUF_SIZE);
    if (!buf) { vTaskDelete(NULL); return; }
    static char lb[128]; static int li = 0;
    while (1) {
        int n = uart_read_bytes(UART_PORT, buf, BUF_SIZE-1, pdMS_TO_TICKS(200));
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                char c = buf[i];
                if (c == '\n')      { lb[li]=0; parse_alert(lb, li); li=0; }
                else if (c != '\r' && li < 127) lb[li++] = c;
                else if (li >= 127) li = 0;
            }
        }
    }
}

void uart_cmd_start_alert_rx(void)
{
    xTaskCreate(rx_task, "uart_rx", 3072, NULL, 5, NULL);
}
uart_alert_type_t uart_cmd_poll_alert(void)  { return s_alert_pending ? (uart_alert_type_t)s_alert_type : UART_ALERT_NONE; }
uart_alert_type_t uart_cmd_consume_alert(void){ uart_alert_type_t a = s_alert_type; s_alert_type = UART_ALERT_NONE; s_alert_pending = false; return a; }
