/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Cloud ASR — Baidu Short Speech Recognition.
 * Sends raw PCM audio via HTTPS and returns recognized Chinese text.
 */

#pragma once

#include "esp_err.h"
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Send PCM audio to Baidu ASR and get recognized text.
 *
 * @param pcm_data     16-bit mono PCM at 16000 Hz
 * @param data_size    Size in bytes
 * @param api_key      Baidu API Key
 * @param secret_key   Baidu Secret Key
 * @param result_text  Output: malloc'd recognized text. Caller must free().
 * @return ESP_OK on success. *result_text may be NULL if no speech detected.
 */
esp_err_t cloud_asr_recognize(const int16_t *pcm_data, size_t data_size,
                              const char *api_key, const char *secret_key,
                              char **result_text);

#ifdef __cplusplus
}
#endif
