/*
 * ESP-NOW IoT Alert — connectionless peer-to-peer safety alerts.
 *
 * Listens for ESP-NOW packets from another ESP32-S3 (e.g., an
 * eye-distance camera). When "eye_warning" is received, signals
 * the state machine to play the protective voice alert.
 *
 * ESP-NOW is connectionless, <5ms latency, no router needed.
 * Uses only the WiFi radio (STA mode, no AP connection).
 *
 * AUXILIARY feature: gated behind CONFIG_VA_ENABLE_ESPNOW_ALERT.
 */

#pragma once
#include "esp_err.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** IoT alert types — extensible */
typedef enum {
    IOT_ALERT_NONE        = 0,
    IOT_ALERT_EYE_WARNING = 1,
    IOT_ALERT_MAX
} iot_alert_type_t;

/**
 * Initialize ESP-NOW receiver (STA mode, no AP connection).
 * Non-blocking; ESP-NOW runs on WiFi task.
 */
esp_err_t espnow_alert_init(void);

/**
 * Check whether an IoT alert was received (non-blocking).
 * Returns alert type, or IOT_ALERT_NONE if none pending.
 */
iot_alert_type_t espnow_alert_poll(void);

/**
 * Consume the pending alert and clear the flag.
 */
iot_alert_type_t espnow_alert_consume(void);

#ifdef __cplusplus
}
#endif
