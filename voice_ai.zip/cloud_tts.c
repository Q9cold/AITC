/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Cloud TTS — Baidu Text-to-Speech API.
 * Requests raw PCM output (aue=4, no codec needed).
 * Streams response directly to audio_output for playback.
 */

#include "cloud_tts.h"
#include "baidu_auth.h"
#include "audio_output.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_mac.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

static const char *TAG = "cloud_tts";

#define TTS_URL "https://tsn.baidu.com/text2audio"
#define TTS_CHUNK_SIZE 2048

/* Get device MAC as cuid string */
static void get_cuid(char *cuid, size_t size)
{
    uint8_t mac[6];
    esp_err_t err = esp_efuse_mac_get_default(mac);
    if (err != ESP_OK) {
        esp_read_mac(mac, ESP_MAC_WIFI_STA);
    }
    snprintf(cuid, size, "%02x%02x%02x%02x%02x%02x",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

/* Simple URL encoding for text parameter */
static int url_encode(const char *src, char *dst, size_t dst_size)
{
    static const char *hex = "0123456789ABCDEF";
    size_t out = 0;
    for (const char *p = src; *p && out < dst_size - 4; p++) {
        unsigned char c = (unsigned char)*p;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' ||
            c == '.' || c == '~') {
            dst[out++] = c;
        } else {
            if (out + 3 >= dst_size) break;
            dst[out++] = '%';
            dst[out++] = hex[c >> 4];
            dst[out++] = hex[c & 0x0F];
        }
    }
    dst[out] = '\0';
    return out;
}

esp_err_t cloud_tts_synthesize_and_play(const char *text,
                                        const char *api_key,
                                        const char *secret_key)
{
    if (text == NULL || strlen(text) == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Get access token */
    const char *token = NULL;
    esp_err_t err = baidu_auth_get_token(api_key, secret_key, &token);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get access token");
        return err;
    }

    /* Get device ID */
    char cuid[32];
    get_cuid(cuid, sizeof(cuid));

    /* URL-encode the text */
    size_t text_len = strlen(text);
    size_t enc_size = text_len * 3 + 16; /* worst case: each char → %XX */
    char *enc_text = malloc(enc_size);
    if (enc_text == NULL) {
        return ESP_ERR_NO_MEM;
    }
    url_encode(text, enc_text, enc_size);

    /* Build POST body: form-urlencoded */
    /* aue=4 → 16K 16-bit mono PCM, raw little-endian */
    char *body = malloc(enc_size + 1024);
    if (body == NULL) {
        free(enc_text);
        return ESP_ERR_NO_MEM;
    }

    int body_len = snprintf(body, enc_size + 1024,
                            "tex=%s&tok=%s&cuid=%s&ctp=1&lan=zh&aue=4"
                            "&spd=5&pit=5&vol=5&per=0",
                            enc_text, token, cuid);
    free(enc_text);

    if (body_len < 0) {
        free(body);
        return ESP_ERR_NO_MEM;
    }

    ESP_LOGI(TAG, "Sending TTS request, text_len=%d, body_len=%d",
             strlen(text), body_len);

    /* HTTP POST — use open/fetch/read for streaming control */
    esp_http_client_config_t http_cfg = {
        .url = TTS_URL,
        .method = HTTP_METHOD_POST,
        .timeout_ms = 30000,
    };
    esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
    if (client == NULL) {
        ESP_LOGE(TAG, "Failed to init HTTP client");
        free(body);
        return ESP_FAIL;
    }

    esp_http_client_set_header(client, "Content-Type",
                               "application/x-www-form-urlencoded");
    esp_http_client_set_post_field(client, body, body_len);
    free(body);

    /* Open connection and send headers + body */
    err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP open failed: %d", err);
        esp_http_client_cleanup(client);
        return err;
    }

    int content_len = esp_http_client_fetch_headers(client);
    if (content_len < 0) {
        ESP_LOGE(TAG, "Failed to fetch headers");
        esp_http_client_cleanup(client);
        return ESP_FAIL;
    }

    int status = esp_http_client_get_status_code(client);
    ESP_LOGI(TAG, "TTS HTTP status: %d, content_len: %d", status, content_len);

    /* Check content type to detect error */
    char *content_type = NULL;
    esp_http_client_get_header(client, "Content-Type", &content_type);

    if (content_type == NULL || strstr(content_type, "audio") == NULL) {
        /* Not audio — likely a JSON error */
        char err_buf[512];
        int err_len = esp_http_client_read_response(client, err_buf, sizeof(err_buf) - 1);
        if (err_len > 0) {
            err_buf[err_len] = '\0';
            ESP_LOGE(TAG, "TTS error response: %s", err_buf);
        } else {
            ESP_LOGE(TAG, "TTS returned non-audio content-type: %s", content_type);
        }
        esp_http_client_cleanup(client);
        return ESP_FAIL;
    }

    /* Read and play PCM audio in chunks */
    ESP_LOGI(TAG, "Playing TTS audio...");
    uint8_t *chunk = malloc(TTS_CHUNK_SIZE);
    if (chunk == NULL) {
        esp_http_client_cleanup(client);
        return ESP_ERR_NO_MEM;
    }

    int total_read = 0;
    int read_len;
    do {
        read_len = esp_http_client_read(client, (char *)chunk, TTS_CHUNK_SIZE);
        if (read_len > 0) {
            total_read += read_len;
            /* Play chunk through I2S speaker */
            err = audio_output_play((const int16_t *)chunk, read_len);
            if (err != ESP_OK) {
                ESP_LOGE(TAG, "audio_output_play failed: %d", err);
                break;
            }
        }
    } while (read_len > 0);

    free(chunk);
    esp_http_client_close(client);
    esp_http_client_cleanup(client);

    ESP_LOGI(TAG, "TTS playback complete: %d bytes played", total_read);
    return ESP_OK;
}
