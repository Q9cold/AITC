/*
 * Local Response — pre-recorded WAV playback from SPIFFS.
 * Plays 16kHz 16-bit mono PCM WAV files for each intent.
 * Falls back to LED pattern if no audio file is available.
 */

#include "local_response.h"
#include "audio_output.h"
#include "gpio_control.h"
#include "esp_log.h"
#include "esp_random.h"
#include "esp_spiffs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
#include "tts_bridge.h"
#endif

static const char *TAG = "local_response";

/* ─── Playback abort (volatile — set by BLE callback, read by PCM loop) ─── */
static volatile bool s_playback_abort = false;

#define ESP_ERR_PLAYBACK_ABORT  0x701  /* Custom error code */

/* Audio output GPIOs — from Kconfig or defaults */
#ifndef CONFIG_VA_I2S_SPK_BCLK_GPIO
#define CONFIG_VA_I2S_SPK_BCLK_GPIO  7
#endif
#ifndef CONFIG_VA_I2S_SPK_WS_GPIO
#define CONFIG_VA_I2S_SPK_WS_GPIO    15
#endif
#ifndef CONFIG_VA_I2S_SPK_DOUT_GPIO
#define CONFIG_VA_I2S_SPK_DOUT_GPIO  16
#endif

#define SAMPLE_RATE  16000
#define WAV_BUF_SIZE 2048

/* Simple WAV header parser */
typedef struct __attribute__((packed)) {
    char     riff[4];        /* "RIFF" */
    uint32_t file_size;
    char     wave[4];        /* "WAVE" */
    char     fmt[4];         /* "fmt " */
    uint32_t fmt_size;
    uint16_t audio_format;   /* 1 = PCM */
    uint16_t num_channels;   /* 1 = mono */
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample;/* 16 */
    char     data[4];        /* "data" */
    uint32_t data_size;
} wav_header_t;

esp_err_t local_response_init(void)
{
    srand((unsigned int)esp_random());
    ESP_LOGI(TAG, "Local response system ready");
    return ESP_OK;
}

static esp_err_t play_wav_file(const char *filepath)
{
    /* Open WAV file from SPIFFS */
    FILE *fp = fopen(filepath, "rb");
    if (fp == NULL) {
        ESP_LOGW(TAG, "WAV file not found: %s", filepath);
        return ESP_ERR_NOT_FOUND;
    }

    /* Read WAV header */
    wav_header_t header;
    if (fread(&header, sizeof(header), 1, fp) != 1) {
        ESP_LOGE(TAG, "Failed to read WAV header");
        fclose(fp);
        return ESP_FAIL;
    }

    /* Validate header */
    if (memcmp(header.riff, "RIFF", 4) != 0 ||
        memcmp(header.wave, "WAVE", 4) != 0 ||
        header.audio_format != 1 ||
        header.num_channels != 1 ||
        header.bits_per_sample != 16) {
        ESP_LOGE(TAG, "Invalid WAV format: ch=%d bits=%d fmt=%d",
                 header.num_channels, header.bits_per_sample, header.audio_format);
        fclose(fp);
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "Playing: %s (%lu samples, %lu Hz)",
             filepath, header.data_size / 2, header.sample_rate);

    /* Init speaker */
    esp_err_t err = audio_output_init(header.sample_rate,
                                       CONFIG_VA_I2S_SPK_BCLK_GPIO,
                                       CONFIG_VA_I2S_SPK_WS_GPIO,
                                       CONFIG_VA_I2S_SPK_DOUT_GPIO);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Speaker init failed");
        fclose(fp);
        return err;
    }

    /* Stream PCM data to speaker in chunks */
    int16_t buffer[WAV_BUF_SIZE / 2];
    uint32_t total_played = 0;

    while (total_played < header.data_size) {
        /* ── Check for IoT alert abort (eye safety priority) ── */
        if (s_playback_abort) {
            ESP_LOGI(TAG, "Playback aborted for IoT alert");
            /* Send 64 samples of silence to avoid speaker pop */
            static const int16_t silence[64] = {0};
            audio_output_play(silence, sizeof(silence));
            s_playback_abort = false;
            fclose(fp);
            audio_output_deinit();
            return ESP_ERR_PLAYBACK_ABORT;
        }

        size_t to_read = sizeof(buffer);
        if (total_played + to_read > header.data_size) {
            to_read = header.data_size - total_played;
        }
        size_t samples_read = fread(buffer, 1, to_read, fp);
        if (samples_read == 0) break;

        audio_output_play(buffer, samples_read);
        total_played += samples_read;
    }

    fclose(fp);
    audio_output_deinit();

    ESP_LOGI(TAG, "Playback complete: %lu bytes", total_played);
    return ESP_OK;
}

esp_err_t local_response_play(intent_id_t intent, int32_t param)
{
    char filepath[64];

    /* Try parameterized response first, then generic */
    if (param > 0) {
        snprintf(filepath, sizeof(filepath), "/spiffs/rsp_%d_%ld.wav", intent, param);
        if (play_wav_file(filepath) == ESP_OK) return ESP_OK;
    }

    /* Fall back to generic intent response */
    snprintf(filepath, sizeof(filepath), "/spiffs/rsp_%d.wav", intent);
    esp_err_t err = play_wav_file(filepath);
    if (err == ESP_ERR_NOT_FOUND) {
        /* No WAV file — use LED as minimal feedback */
        ESP_LOGW(TAG, "No WAV for intent %d, using LED feedback", intent);
        gpio_control_set_led_state(LED_WAKE_ACTIVE);
        vTaskDelay(pdMS_TO_TICKS(300));
        gpio_control_set_led_state(LED_IDLE);
        return ESP_OK; /* Not a hard error */
    }
    return err;
}

esp_err_t local_response_play_unknown(void)
{
    /* Randomly pick from rsp_unknown_[0-4].wav */
    int idx = rand() % 5;
    char filepath[32];
    if (idx == 0) {
        snprintf(filepath, sizeof(filepath), "/spiffs/rsp_unknown.wav");
    } else {
        snprintf(filepath, sizeof(filepath), "/spiffs/rsp_unknown_%d.wav", idx);
    }
    ESP_LOGI(TAG, "Unknown response: %s", filepath);

    esp_err_t err = play_wav_file(filepath);
    if (err == ESP_ERR_NOT_FOUND) {
        /* Try default */
        if (idx != 0) {
            err = play_wav_file("/spiffs/rsp_unknown.wav");
        }
        if (err == ESP_ERR_NOT_FOUND) {
            gpio_control_set_led_state(LED_ERROR);
            vTaskDelay(pdMS_TO_TICKS(1000));
            gpio_control_set_led_state(LED_IDLE);
            return ESP_OK;
        }
    }
    return err;
}

esp_err_t local_response_play_startup(void)
{
    esp_err_t err = play_wav_file("/spiffs/rsp_startup.wav");
    if (err == ESP_ERR_NOT_FOUND) {
        /* LED fallback: slow blink */
        gpio_control_set_led_state(LED_WIFI_CONNECTING);
        vTaskDelay(pdMS_TO_TICKS(1000));
        gpio_control_set_led_state(LED_IDLE);
        return ESP_OK;
    }
    return err;
}

esp_err_t local_response_play_joke(void)
{
    /* Randomly pick from rsp_joke_0.wav, rsp_joke_1.wav, rsp_joke_2.wav */
    int idx = rand() % 3;
    char filepath[32];
    snprintf(filepath, sizeof(filepath), "/spiffs/rsp_joke_%d.wav", idx);
    ESP_LOGI(TAG, "Joke response: %s", filepath);

    esp_err_t err = play_wav_file(filepath);
    if (err == ESP_ERR_NOT_FOUND) {
        /* Try rsp_joke_0 as fallback */
        err = play_wav_file("/spiffs/rsp_joke_0.wav");
    }
    if (err == ESP_ERR_NOT_FOUND) {
        gpio_control_set_led_state(LED_WAKE_ACTIVE);
        vTaskDelay(pdMS_TO_TICKS(300));
        gpio_control_set_led_state(LED_IDLE);
        return ESP_OK;
    }
    return err;
}

esp_err_t local_response_play_named(const char *name)
{
    char filepath[64];
    snprintf(filepath, sizeof(filepath), "/spiffs/%s", name);
    return play_wav_file(filepath);
}

/* ─── IoT Alert API ─── */

void local_response_abort_playback(void)
{
    s_playback_abort = true;
}

void local_response_clear_abort(void)
{
    s_playback_abort = false;
}

esp_err_t local_response_play_alert(int alert_type)
{
#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
    /* 优先使用 AI TTS 语音合成（小乐声音） */
    if (tts_bridge_is_ready()) {
        const char *tts_text = NULL;
        switch (alert_type) {
        case 1: /* I2C_ALERT_POSTURE — 坐姿告警 */
            tts_text = "请注意坐姿";
            break;
        case 2: /* I2C_ALERT_PRESS — 压力坐垫告警 */
            tts_text = "请调整坐垫";
            break;
        case 3: /* I2C_ALERT_MUSIC — 直接播 WAV，不用 TTS */
            break;  // tts_text 保持 NULL，跳过 TTS
        default:
            ESP_LOGW(TAG, "Unknown alert type: %d", alert_type);
            return ESP_ERR_INVALID_ARG;
        }
        if (tts_text) {
            ESP_LOGI(TAG, "TTS alert: \"%s\"", tts_text);
            return tts_bridge_speak(tts_text);
        }
        /* tts_text == NULL → 回退到 WAV 播放 */
    }
#endif

    /* TTS 不可用时回退到预录 WAV */
    char filepath[64];
    switch (alert_type) {
    case 1: /* 坐姿告警 */
        snprintf(filepath, sizeof(filepath), "/spiffs/rsp_alert_posture.wav");
        break;
    case 2: /* 压力坐垫告警 */
        snprintf(filepath, sizeof(filepath), "/spiffs/rsp_alert_press.wav");
        break;
    case 3: /* 音乐播放 */
        snprintf(filepath, sizeof(filepath), "/spiffs/rsp_music.wav");
        break;
    default:
        ESP_LOGW(TAG, "Unknown alert type: %d", alert_type);
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t err = play_wav_file(filepath);
    if (err == ESP_ERR_NOT_FOUND) {
        ESP_LOGW(TAG, "Alert WAV not found: %s — LED fallback", filepath);
        /* LED fallback: 5 rapid blinks */
        for (int i = 0; i < 5; i++) {
            gpio_control_set_led_state(LED_WAKE_ACTIVE);
            vTaskDelay(pdMS_TO_TICKS(150));
            gpio_control_set_led_state(LED_IDLE);
            vTaskDelay(pdMS_TO_TICKS(150));
        }
        return ESP_OK;
    }
    /* If aborted by higher-priority alert, that's OK */
    if (err == ESP_ERR_PLAYBACK_ABORT) {
        ESP_LOGI(TAG, "Alert playback preempted");
        return ESP_OK;
    }
    return err;
}
