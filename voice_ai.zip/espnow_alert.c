/*
 * ESP-NOW IoT Alert — receiver implementation.
 *
 * Architecture:
 *   WiFi task → ESP-NOW recv callback
 *     → sets s_alert_type + s_alert_pending (volatile, <1ms)
 *   State machine loop (Core 0) → polls espnow_alert_poll()
 *     → if alert → VA_SM_IOT_ALERT → plays voice warning
 */

#include "espnow_alert.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_now.h"
#include "esp_mac.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "espnow_alert";

/* ─── Shared state (volatile — ESP-NOW callback ↔ state machine loop) ─── */
static volatile bool              s_alert_pending = false;
static volatile iot_alert_type_t  s_alert_type    = IOT_ALERT_NONE;

/* ─── ESP-NOW receive callback ─── */
static void on_recv(const esp_now_recv_info_t *recv_info,
                    const uint8_t *data, int len)
{
    if (data == NULL || len <= 0) return;

    /* Copy to null-terminated buffer (max 32 bytes) */
    char buf[33] = {0};
    int copy_len = (len < 32) ? len : 32;
    memcpy(buf, data, copy_len);

    ESP_LOGI(TAG, "ESP-NOW recv: \"%s\" (%d bytes) from "
             MACSTR, buf, len, MAC2STR(recv_info->src_addr));

    /* Map string to alert type */
    if (strcmp(buf, "eye_warning") == 0) {
        s_alert_type = IOT_ALERT_EYE_WARNING;
        s_alert_pending = true;
        ESP_LOGI(TAG, "IoT alert triggered: EYE_WARNING");
    } else {
        ESP_LOGW(TAG, "Unknown alert: \"%s\" — ignored", buf);
    }
}

/* ─── WiFi init (STA mode, no AP connection) ─── */
static esp_err_t init_wifi_sta(void)
{
    /* If WiFi is already started by another module (cloud/OTA/etc),
     * reuse it. ESP-NOW only needs the WiFi radio to be running. */
    wifi_mode_t mode;
    if (esp_wifi_get_mode(&mode) == ESP_OK &&
        (mode == WIFI_MODE_STA || mode == WIFI_MODE_APSTA)) {
        ESP_LOGI(TAG, "WiFi already running — reusing for ESP-NOW");
        esp_wifi_set_channel(1, WIFI_SECOND_CHAN_NONE);
        return ESP_OK;
    }

    /* Fresh WiFi init for standalone ESP-NOW (no cloud module) */
    esp_netif_init();

    esp_err_t err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "event loop create failed: %d", err);
        return err;
    }

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_ERROR_CHECK(esp_wifi_set_channel(1, WIFI_SECOND_CHAN_NONE));

    ESP_LOGI(TAG, "WiFi STA started");
    return ESP_OK;
}

/* ─── Public API ─── */

esp_err_t espnow_alert_init(void)
{
    ESP_LOGI(TAG, "Initializing ESP-NOW alert receiver...");

    /* Init WiFi in STA mode (no connection needed) */
    esp_err_t err = init_wifi_sta();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "WiFi init failed: %d", err);
        return err;
    }

    /* Init ESP-NOW */
    err = esp_now_init();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "ESP-NOW init failed: %d", err);
        return err;
    }

    /* Register receive callback */
    err = esp_now_register_recv_cb(on_recv);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "ESP-NOW recv cb register failed: %d", err);
        return err;
    }

    /* If a specific peer MAC is configured, add it (optional) */
#ifdef CONFIG_VA_ESPNOW_PEER_MAC
    if (strlen(CONFIG_VA_ESPNOW_PEER_MAC) > 0) {
        esp_now_peer_info_t peer = {0};
        sscanf(CONFIG_VA_ESPNOW_PEER_MAC,
               "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
               &peer.peer_addr[0], &peer.peer_addr[1], &peer.peer_addr[2],
               &peer.peer_addr[3], &peer.peer_addr[4], &peer.peer_addr[5]);
        peer.channel = 1;
        peer.encrypt = false;
        esp_err_t peer_err = esp_now_add_peer(&peer);
        if (peer_err != ESP_OK) {
            ESP_LOGW(TAG, "Failed to add peer " CONFIG_VA_ESPNOW_PEER_MAC
                     " (err=%d) — will accept broadcasts", peer_err);
        } else {
            ESP_LOGI(TAG, "Peer added: " CONFIG_VA_ESPNOW_PEER_MAC);
        }
    }
#else
    ESP_LOGI(TAG, "No peer filter — accepting all broadcasts");
#endif

    ESP_LOGI(TAG, "ESP-NOW alert receiver ready");
    return ESP_OK;
}

iot_alert_type_t espnow_alert_poll(void)
{
    if (s_alert_pending) {
        return (iot_alert_type_t)s_alert_type;
    }
    return IOT_ALERT_NONE;
}

iot_alert_type_t espnow_alert_consume(void)
{
    iot_alert_type_t alert = (iot_alert_type_t)s_alert_type;
    s_alert_type = IOT_ALERT_NONE;
    s_alert_pending = false;
    return alert;
}
