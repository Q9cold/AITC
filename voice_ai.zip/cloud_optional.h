/*
 * Cloud Optional — auxiliary HTTP query extension.
 * CLEARLY LABELED: This is an OPTIONAL, conditionally-compiled module.
 * Core voice AI (wake word, command recognition, intent, response)
 * works 100% offline. This module only activates for open-domain queries
 * like weather/news/encyclopedia, and can be disabled entirely.
 */

#pragma once
#include "esp_err.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Init cloud module (requires WiFi connected) */
esp_err_t cloud_optional_init(const char *api_key);

/** Check if cloud queries are available */
bool cloud_optional_is_available(void);

/** Send query text to cloud, get response text (malloc'd, caller frees) */
esp_err_t cloud_optional_query(const char *query_text, char **response_text);

#ifdef __cplusplus
}
#endif
