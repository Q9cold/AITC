/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * WiFi Station module — refactored from my_project.c
 * Provides blocking WiFi connect with event group signaling.
 */

#pragma once

#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Event group bits */
#define WIFI_CONNECTED_BIT  BIT0
#define WIFI_FAIL_BIT       BIT1
#define WIFI_GOT_IP_BIT     BIT2

/**
 * @brief Initialize NVS, netif, event loop, and WiFi station.
 *        Blocks until IP obtained or connection fails.
 *
 * @param ssid      WiFi SSID (UTF-8)
 * @param password  WiFi password
 * @param max_retry Maximum reconnection attempts
 * @return ESP_OK if connected, ESP_FAIL otherwise.
 */
esp_err_t wifi_station_connect(const char *ssid, const char *password, int max_retry);

/**
 * @brief Get the event group handle for external waiters.
 */
EventGroupHandle_t wifi_station_get_event_group(void);

#ifdef __cplusplus
}
#endif
