/*
 * WiFi SNTP — NTP time sync implementation.
 * Uses lwIP SNTP (already configured in sdkconfig).
 * Sets timezone to UTC+8 (Beijing/China Standard Time).
 */

#include "wifi_sntp.h"
#include "esp_log.h"
#include "esp_sntp.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <time.h>
#include <string.h>

static const char *TAG = "wifi_sntp";
static bool s_synced = false;

/* ─── Time sync notification callback ─── */
static void on_time_sync(struct timeval *tv)
{
    s_synced = true;
    ESP_LOGI(TAG, "Time synced: %lld", (long long)tv->tv_sec);
}

esp_err_t wifi_sntp_init(void)
{
    ESP_LOGI(TAG, "Starting SNTP sync...");

    /* Set timezone to UTC+8 (China Standard Time) */
    setenv("TZ", "CST-8", 1);
    tzset();

    /* Register sync callback */
    sntp_set_time_sync_notification_cb(on_time_sync);

    /* Configure SNTP */
    esp_sntp_setoperatingmode(ESP_SNTP_OPMODE_POLL);
    esp_sntp_setservername(0, "ntp.aliyun.com");
    esp_sntp_setservername(1, "pool.ntp.org");
    esp_sntp_init();

    /* Wait up to 10 seconds for first sync */
    int retry = 0;
    while (!s_synced && retry < 100) {
        vTaskDelay(pdMS_TO_TICKS(100));
        retry++;
    }

    if (s_synced) {
        ESP_LOGI(TAG, "SNTP sync OK");
        return ESP_OK;
    } else {
        ESP_LOGW(TAG, "SNTP sync timeout — continuing without time");
        return ESP_ERR_TIMEOUT;
    }
}

bool wifi_sntp_is_synced(void)
{
    return s_synced;
}

/* ─── Helpers ─── */

static const char* s_weekday_cn[] = {"日","一","二","三","四","五","六"};
static const char* s_number_cn[] = {"零","一","二","三","四","五","六","七","八","九","十"};

static void num_to_cn(int n, char *buf) {
    if (n <= 10) {
        strcpy(buf, s_number_cn[n]);
    } else if (n < 20) {
        sprintf(buf, "十%s", s_number_cn[n % 10]);
    } else {
        sprintf(buf, "%s十%s", s_number_cn[n / 10], s_number_cn[n % 10]);
    }
}

static void year_to_cn(int y, char *buf) {
    int d4 = y / 1000, d3 = (y / 100) % 10, d2 = (y / 10) % 10, d1 = y % 10;
    sprintf(buf, "%s%s%s%s", s_number_cn[d4], s_number_cn[d3], s_number_cn[d2], s_number_cn[d1]);
}

const char* wifi_sntp_get_time_string(void)
{
    static char buf[64];
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);

    char hour_cn[8], min_cn[8];
    num_to_cn(tm.tm_hour, hour_cn);
    num_to_cn(tm.tm_min, min_cn);

    const char *period = tm.tm_hour < 12 ? "上午" : "下午";
    int h12 = tm.tm_hour % 12;
    if (h12 == 0) h12 = 12;
    char h12_cn[8];
    num_to_cn(h12, h12_cn);

    if (tm.tm_min == 0) {
        snprintf(buf, sizeof(buf), "现在是%s%s点整", period, h12_cn);
    } else if (tm.tm_min == 30) {
        snprintf(buf, sizeof(buf), "现在是%s%s点半", period, h12_cn);
    } else {
        snprintf(buf, sizeof(buf), "现在是%s%s点%s分", period, h12_cn, min_cn);
    }
    return buf;
}

const char* wifi_sntp_get_date_string(void)
{
    static char buf[64];
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);

    char year_cn[16], month_cn[8], day_cn[8];
    year_to_cn(tm.tm_year + 1900, year_cn);
    num_to_cn(tm.tm_mon + 1, month_cn);
    num_to_cn(tm.tm_mday, day_cn);

    snprintf(buf, sizeof(buf), "今天是%s年%s月%s号", year_cn, month_cn, day_cn);
    return buf;
}

const char* wifi_sntp_get_weekday_string(void)
{
    static char buf[32];
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);

    snprintf(buf, sizeof(buf), "今天是星期%s", s_weekday_cn[tm.tm_wday]);
    return buf;
}
