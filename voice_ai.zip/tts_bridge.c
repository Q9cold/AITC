/*
 * TTS Bridge — ESP-TTS (xiaole voice) implementation.
 * Voice data: /spiffs/xiaole_voice.dat (~2.9 MB), loaded to PSRAM.
 */

#include "tts_bridge.h"
#include "board_audio_init.h"
#include "esp_log.h"
#include "esp_spiffs.h"
#include "esp_heap_caps.h"
#include "esp_tts.h"
#include "esp_tts_voice.h"
#include "freertos/FreeRTOS.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

static const char *TAG = "tts_bridge";

/* External declaration from esp_tts_voice_xiaole.h in ESP-SR */
extern const esp_tts_voice_t esp_tts_voice_xiaole;

static esp_tts_handle_t s_tts = NULL;
static uint8_t *s_voice_data = NULL;
static bool s_ready = false;

esp_err_t tts_bridge_init(void)
{
    if (s_ready) return ESP_OK;

    /* Open voice data from SPIFFS */
    const char *path = "/spiffs/xiaole_voice.dat";
    FILE *fp = fopen(path, "rb");
    if (fp == NULL) {
        ESP_LOGE(TAG, "Voice data not found: %s", path);
        return ESP_ERR_NOT_FOUND;
    }

    /* Get file size */
    fseek(fp, 0, SEEK_END);
    size_t size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    ESP_LOGI(TAG, "Loading voice data: %s (%u KB)...", path, (unsigned)(size / 1024));

    /* Allocate PSRAM */
    s_voice_data = (uint8_t *)heap_caps_malloc(size + 4,
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (s_voice_data == NULL) {
        ESP_LOGE(TAG, "PSRAM alloc failed (%u bytes)", (unsigned)size);
        fclose(fp);
        return ESP_ERR_NO_MEM;
    }

    /* Read into PSRAM */
    size_t read = fread(s_voice_data, 1, size, fp);
    fclose(fp);

    if (read != size) {
        ESP_LOGE(TAG, "Read failed: %u/%u", (unsigned)read, (unsigned)size);
        free(s_voice_data);
        s_voice_data = NULL;
        return ESP_FAIL;
    }

    /* Init TTS */
    esp_tts_voice_t *voice = esp_tts_voice_set_init(&esp_tts_voice_xiaole, s_voice_data);
    if (voice == NULL) {
        ESP_LOGE(TAG, "esp_tts_voice_set_init failed");
        free(s_voice_data);
        s_voice_data = NULL;
        return ESP_FAIL;
    }

    s_tts = esp_tts_create(voice);
    if (s_tts == NULL) {
        ESP_LOGE(TAG, "esp_tts_create failed");
        free(s_voice_data);
        s_voice_data = NULL;
        return ESP_FAIL;
    }

    s_ready = true;
    ESP_LOGI(TAG, "TTS ready (xiaole voice, %u KB PSRAM)", (unsigned)(size / 1024));
    return ESP_OK;
}

esp_err_t tts_bridge_speak(const char *text)
{
    if (!s_ready || s_tts == NULL) {
        ESP_LOGW(TAG, "TTS not ready");
        return ESP_ERR_INVALID_STATE;
    }

    /* Strip punctuation that xiaole voice can't pronounce */
    char filtered[256];
    int j = 0;
    for (int i = 0; text[i] && j < (int)sizeof(filtered) - 1; i++) {
        unsigned char c = text[i];
        /* Skip full-width ？ (EF BC 9F) and ！ (EF BC 81) */
        if (c == 0xEF && (text[i+1] == (char)0xBC) &&
            (text[i+2] == (char)0x9F || text[i+2] == (char)0x81)) {
            i += 2; continue;
        }
        /* Skip ASCII ? and ! */
        if (c == '?' || c == '!') continue;
        filtered[j++] = text[i];
    }
    filtered[j] = '\0';

    ESP_LOGI(TAG, "TTS speak: \"%s\"", filtered);

    int ret = esp_tts_parse_chinese(s_tts, filtered);
    if (ret < 0) {
        ESP_LOGE(TAG, "esp_tts_parse_chinese failed: %d", ret);
        return ESP_FAIL;
    }

    /* Stream PCM — 100ms timeout gives engine time to build reasonable chunks */
    int len;
    short *pcm;
    while ((pcm = esp_tts_stream_play(s_tts, &len, pdMS_TO_TICKS(100))) != NULL && len > 0) {
        board_audio_write(pcm, len);
    }
    esp_tts_stream_reset(s_tts);
    ESP_LOGI(TAG, "TTS speak done");
    return ESP_OK;
}

bool tts_bridge_is_ready(void)
{
    return s_ready;
}
