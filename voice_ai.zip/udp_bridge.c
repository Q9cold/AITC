/**
 * @file udp_bridge.c
 * @brief UDP 双向通信 — hello_esp ↔ 终端
 *        收: ALERT:xxx (告警/音乐)  发: CMD:xxx (语音命令)
 */
#include "udp_bridge.h"
#include "local_response.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <stdio.h>

static const char *TAG = "udp";
#define MY_PORT   8887
#define PEER_PORT 8888
#define PEER_IP   "10.45.232.92"

static volatile int   s_rx_sock = -1;
static volatile int   s_tx_sock = -1;
static volatile int   s_alert_type = UDP_ALERT_NONE;
static volatile bool  s_alert_pending = false;

esp_err_t udp_bridge_init(void)
{
    s_rx_sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in rx_addr = { .sin_family = AF_INET, .sin_port = htons(MY_PORT), .sin_addr.s_addr = htonl(INADDR_ANY) };
    bind(s_rx_sock, (struct sockaddr *)&rx_addr, sizeof(rx_addr));
    int flags = fcntl(s_rx_sock, F_GETFL, 0);
    fcntl(s_rx_sock, F_SETFL, flags | O_NONBLOCK);

    s_tx_sock = socket(AF_INET, SOCK_DGRAM, 0);
    ESP_LOGI(TAG, "ready rx:%d tx→%s:%d", MY_PORT, PEER_IP, PEER_PORT);
    return ESP_OK;
}

void udp_bridge_send_cmd(const char *text)
{
    if (!text || s_tx_sock < 0) return;
    char buf[256];
    int len = snprintf(buf, sizeof(buf), "CMD:%s\n", text);
    struct sockaddr_in peer = { .sin_family = AF_INET, .sin_port = htons(PEER_PORT) };
    inet_aton(PEER_IP, &peer.sin_addr);
    sendto(s_tx_sock, buf, len, 0, (struct sockaddr *)&peer, sizeof(peer));
}

void udp_bridge_send_intent(int id)
{
    static const char *t[] = {
        [0]="未知命令",[1]="打开灯光",[2]="关闭灯光",[3]="调亮度",
        [4]="打开风扇",[5]="关闭风扇",[6]="调风速",[7]="查询温度",
        [8]="查询湿度",[9]="查询时间",[10]="查询日期",[11]="音量加大",
        [12]="音量减小",[13]="播放音乐",[14]="停止播放",[15]="打开门",
        [16]="关闭门",[17]="你好",[18]="再见",[19]="自我介绍",[20]="云端查询",
    };
    int n = sizeof(t)/sizeof(t[0]);
    if (id >= 0 && id < n && t[id]) udp_bridge_send_cmd(t[id]);
}

int udp_bridge_poll_alert(void)
{
    if (s_rx_sock < 0) return UDP_ALERT_NONE;
    char buf[256];
    struct sockaddr_in from; socklen_t flen = sizeof(from);
    int n = recvfrom(s_rx_sock, buf, sizeof(buf)-1, 0, (struct sockaddr *)&from, &flen);
    if (n <= 0) return UDP_ALERT_NONE;
    buf[n] = 0;

    if (strncmp(buf, "ALERT:", 6) == 0) {
        const char *type = buf + 6;
        if (strncmp(type, "posture", 7) == 0) {
            local_response_play_named("rsp_alert_posture.wav");
        } else if (strncmp(type, "press", 5) == 0) {
            local_response_play_named("rsp_alert_press.wav");
        } else if (strncmp(type, "music", 5) == 0) {
            local_response_play_named("rsp_alert_music.wav");
        // 单词音频: word_apple → 播放 /spiffs/rsp_apple.wav
        } else if (strncmp(type, "word_", 5) == 0) {
            char name[48];
            int wlen = (int)(strlen(type + 5));
            while (wlen > 0 && (type[5 + wlen - 1] == '\n' || type[5 + wlen - 1] == '\r')) wlen--;
            snprintf(name, sizeof(name), "rsp_%.*s.wav", wlen, type + 5);
            printf("[UDP] play word: %s\n", name);
            local_response_play_named(name);
        }
    }
    return s_alert_pending ? s_alert_type : UDP_ALERT_NONE;
}

int udp_bridge_consume_alert(void)
{
    int a = s_alert_type;
    s_alert_type = UDP_ALERT_NONE;
    s_alert_pending = false;
    return a;
}
