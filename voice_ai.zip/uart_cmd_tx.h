#pragma once
#include "esp_err.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t uart_cmd_tx_init(void);
void uart_cmd_send(const char *text);
void uart_cmd_send_intent(int id);

typedef enum { UART_ALERT_NONE=0, UART_ALERT_POSTURE=1, UART_ALERT_PRESS=2 } uart_alert_type_t;

void uart_cmd_start_alert_rx(void);
uart_alert_type_t uart_cmd_poll_alert(void);
uart_alert_type_t uart_cmd_consume_alert(void);

#ifdef __cplusplus
}
#endif
