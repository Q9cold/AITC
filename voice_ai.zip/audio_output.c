/*
 * Audio Output — thin wrapper over board_audio_init (ES8311 codec).
 * Plays 16-bit mono PCM data through the I2S codec to speaker.
 *
 * The actual I2S + ES8311 initialization is done once by
 * board_audio_init(). This module keeps the old API so
 * local_response.c doesn't need to change.
 */

#include "audio_output.h"
#include "board_audio_init.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"

static const char *TAG = "audio_output";
static bool s_initialized = false;

esp_err_t audio_output_init(uint32_t sample_rate_hz,
                            gpio_num_t bclk_gpio,
                            gpio_num_t ws_gpio,
                            gpio_num_t dout_gpio)
{
    if (s_initialized) {
        return ESP_OK;
    }

    /* GPIO params are ignored — board pins are fixed for ES8311 */
    (void)bclk_gpio; (void)ws_gpio; (void)dout_gpio;

    ESP_LOGI(TAG, "Init codec output: rate=%lu Hz (ES8311 + I2S duplex)",
             sample_rate_hz);

    esp_err_t err = board_audio_init(sample_rate_hz);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "board_audio_init failed: %d", err);
        return err;
    }

    s_initialized = true;
    ESP_LOGI(TAG, "Codec output initialized");
    return ESP_OK;
}

esp_err_t audio_output_play(const int16_t *pcm_data, size_t data_size)
{
    if (!s_initialized) {
        ESP_LOGE(TAG, "Not initialized");
        return ESP_ERR_INVALID_STATE;
    }
    if (pcm_data == NULL || data_size == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    size_t samples = data_size / sizeof(int16_t);
    return board_audio_write(pcm_data, samples);
}

esp_err_t audio_output_deinit(void)
{
    /* Keep the codec alive between plays.
     * Full deinit only on board_audio_deinit() at shutdown. */
    return ESP_OK;
}
