/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Audio Output — I2S STD TX speaker (e.g., MAX98357A).
 * Plays 16-bit mono PCM data; duplicates to stereo internally.
 */

#pragma once

#include "driver/i2s_common.h"
#include "hal/gpio_types.h"
#include "esp_err.h"
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Initialize I2S STD TX channel for speaker output.
 *
 * @param sample_rate_hz  Typically 16000 to match TTS output
 * @param bclk_gpio       Bit clock GPIO
 * @param ws_gpio         Word select / LRCLK GPIO
 * @param dout_gpio       Data output GPIO
 * @return ESP_OK on success.
 */
esp_err_t audio_output_init(uint32_t sample_rate_hz,
                            gpio_num_t bclk_gpio,
                            gpio_num_t ws_gpio,
                            gpio_num_t dout_gpio);

/**
 * @brief Play raw 16-bit mono PCM data. Blocks until done.
 *
 * @param pcm_data   int16_t mono PCM samples
 * @param data_size  Size in bytes
 * @return ESP_OK on success.
 */
esp_err_t audio_output_play(const int16_t *pcm_data, size_t data_size);

/**
 * @brief De-initialize and free the I2S STD TX channel.
 */
esp_err_t audio_output_deinit(void);

#ifdef __cplusplus
}
#endif
