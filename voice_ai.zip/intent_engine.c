/*
 * Intent Engine — local pinyin-to-intent matching.
 * Uses keyword-based lookup: for each defined command,
 * checks if the recognized pinyin contains the expected keywords.
 * Also handles numeric parameter extraction from pinyin strings.
 */

#include "intent_engine.h"
#include "command_config.h"
#include "multinet_runner.h"
#include "esp_log.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "intent_engine";

/* Intent display names — index matches intent_id_t */
static const char *s_intent_names[INTENT_COUNT] = {
    [INTENT_UNKNOWN]            = "UNKNOWN",
    [INTENT_LIGHT_ON]           = "LIGHT_ON",
    [INTENT_LIGHT_OFF]          = "LIGHT_OFF",
    [INTENT_LIGHT_BRIGHTNESS]   = "LIGHT_BRIGHTNESS",
    [INTENT_FAN_ON]             = "FAN_ON",
    [INTENT_FAN_OFF]            = "FAN_OFF",
    [INTENT_FAN_SPEED]          = "FAN_SPEED",
    [INTENT_TEMPERATURE_QUERY]  = "TEMPERATURE_QUERY",
    [INTENT_HUMIDITY_QUERY]     = "HUMIDITY_QUERY",
    [INTENT_TIME_QUERY]         = "TIME_QUERY",
    [INTENT_DATE_QUERY]         = "DATE_QUERY",
    [INTENT_VOLUME_UP]          = "VOLUME_UP",
    [INTENT_VOLUME_DOWN]        = "VOLUME_DOWN",
    [INTENT_MUSIC_PLAY]         = "MUSIC_PLAY",
    [INTENT_MUSIC_STOP]         = "MUSIC_STOP",
    [INTENT_OPEN_DOOR]          = "OPEN_DOOR",
    [INTENT_CLOSE_DOOR]         = "CLOSE_DOOR",
    [INTENT_GREETING]           = "GREETING",
    [INTENT_GOODBYE]            = "GOODBYE",
    [INTENT_SELF_INTRO]         = "SELF_INTRO",
    [INTENT_CLOUD_QUERY]        = "CLOUD_QUERY",
    [INTENT_JOKE]              = "JOKE",
};

/* Chinese number mapping for param extraction */
static const char *s_chinese_digits[] = {
    "ling", "yi", "er", "san", "si", "wu", "liu", "qi", "ba", "jiu"
};
esp_err_t intent_engine_match(const char *command_pinyin,
                               float multinet_conf,
                               intent_result_t *result)
{
    if (command_pinyin == NULL || result == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Normalize: trim and collapse whitespace */
    char normalized[MULTINET_MAX_CMD_STR_LEN];
    int j = 0;
    bool in_space = false;
    for (int i = 0; command_pinyin[i] && j < sizeof(normalized) - 1; i++) {
        if (command_pinyin[i] == ' ') {
            if (!in_space && j > 0) {
                normalized[j++] = ' ';
                in_space = true;
            }
        } else {
            normalized[j++] = command_pinyin[i];
            in_space = false;
        }
    }
    /* Remove trailing space */
    while (j > 0 && normalized[j - 1] == ' ') j--;
    normalized[j] = '\0';

    /* Default result */
    result->intent = INTENT_UNKNOWN;
    result->param_value = 0;
    result->confidence = multinet_conf;

    /* Best match tracking */
    int best_match_len = 0;
    int best_idx = -1;

    for (int i = 0; i < g_cmd_count; i++) {
        const char *pattern = g_cmd_defs[i].pinyin;
        if (pattern == NULL) continue;

        /* Exact match is best */
        if (strcmp(normalized, pattern) == 0) {
            result->intent = g_cmd_defs[i].intent_id;
            result->param_value = g_cmd_defs[i].param;
            ESP_LOGI(TAG, "Exact match: \"%s\" → %s (param=%ld)",
                     normalized, s_intent_names[result->intent], result->param_value);
            return ESP_OK;
        }

        /* Substring match: pattern contained within recognized string.
         * Require confidence ≥ 0.35 to avoid routing vague partial matches
         * (like "shen me" in "shen me shi ju hua") to the wrong offline intent.
         * Low-confidence phrases go to cloud instead. */
        if (strstr(normalized, pattern) != NULL && multinet_conf >= 0.25f) {
            int len = strlen(pattern);
            if (len > best_match_len) {
                best_match_len = len;
                best_idx = i;
            }
        }
    }

    if (best_idx >= 0) {
        result->intent = g_cmd_defs[best_idx].intent_id;
        result->param_value = g_cmd_defs[best_idx].param;
        ESP_LOGI(TAG, "Substring match: \"%s\" contains \"%s\" → %s (param=%ld)",
                 normalized, g_cmd_defs[best_idx].pinyin,
                 s_intent_names[result->intent], result->param_value);

        /* Extract numeric parameter from the pinyin string if applicable */
        if (g_cmd_defs[best_idx].intent_id == INTENT_LIGHT_BRIGHTNESS ||
            g_cmd_defs[best_idx].intent_id == INTENT_FAN_SPEED ||
            g_cmd_defs[best_idx].intent_id == INTENT_VOLUME_UP ||
            g_cmd_defs[best_idx].intent_id == INTENT_VOLUME_DOWN) {
            /* Try to find numeric keywords in the pinyin */
            for (int d = 0; d <= 9; d++) {
                if (strstr(normalized, s_chinese_digits[d]) != NULL) {
                    result->param_value = d * 10; /* Default to tens */
                    break;
                }
            }
        }

        return ESP_OK;
    }

    /* No match found */
    ESP_LOGW(TAG, "No match for: \"%s\"", normalized);
    return ESP_ERR_NOT_FOUND;
}

const char *intent_engine_get_name(intent_id_t intent)
{
    if (intent >= 0 && intent < INTENT_COUNT && s_intent_names[intent] != NULL) {
        return s_intent_names[intent];
    }
    return "UNKNOWN";
}

bool intent_engine_needs_cloud(intent_id_t intent)
{
    return (intent == INTENT_CLOUD_QUERY ||
            intent == INTENT_TEMPERATURE_QUERY ||
            intent == INTENT_HUMIDITY_QUERY);
}
