/*
 * Command Config — single source of truth for all supported commands.
 * Defines pinyin strings for MultiNet and intent mapping for intent_engine.
 */

#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Maximum number of supported command phrases */
#define CMD_MAX_COUNT  128

/** Single command entry */
typedef struct {
    const char *pinyin;       /* Space-separated pinyin, e.g. "da kai deng guang" */
    int         intent_id;    /* From intent_id_t enum in intent_engine.h */
    const char *description;  /* Human-readable Chinese description */
    int32_t     param;        /* Optional: passed through to intent_result_t */
} cmd_def_t;

/** Array of all defined commands (NULL-terminated pinyin list for MultiNet) */
extern const char *g_cmd_pinyin_list[];

/** Array of command definitions (for intent engine lookup) */
extern const cmd_def_t g_cmd_defs[];

/** Number of commands (auto-computed) */
extern const int g_cmd_count;

#ifdef __cplusplus
}
#endif
