/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Cloud ASR — Baidu Short Speech Recognition API.
 * POST raw PCM audio → get recognized Chinese text.
 */

#include "cloud_asr.h"
#include "baidu_auth.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "cJSON.h"
#include "mbedtls/base64.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

static const char *TAG = "cloud_asr";

#define ASR_URL "https://vop.baidu.com/server_api"
#define DEV_PID_MANDARIN_16K 1537

/* Get device MAC as cuid string */
static void get_cuid(char *cuid, size_t size)
{
    uint8_t mac[6];
    esp_err_t err = esp_efuse_mac_get_default(mac);
    if (err != ESP_OK) {
        esp_read_mac(mac, ESP_MAC_WIFI_STA);
    }
    snprintf(cuid, size, "%02x%02x%02x%02x%02x%02x",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

esp_err_t cloud_asr_recognize(const int16_t *pcm_data, size_t data_size,
                              const char *api_key, const char *secret_key,
                              char **result_text)
{
    if (pcm_data == NULL || data_size == 0 || result_text == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    *result_text = NULL;

    /* Get access token */
    const char *token = NULL;
    esp_err_t err = baidu_auth_get_token(api_key, secret_key, &token);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get access token");
        return err;
    }

    /* Base64-encode the PCM data */
    size_t b64_len = 0;
    mbedtls_base64_encode(NULL, 0, &b64_len, (const unsigned char *)pcm_data, data_size);

    char *b64_buf = malloc(b64_len);
    if (b64_buf == NULL) {
        ESP_LOGE(TAG, "Failed to alloc base64 buffer (%u bytes)", b64_len);
        return ESP_ERR_NO_MEM;
    }

    int b64_ret = mbedtls_base64_encode((unsigned char *)b64_buf, b64_len,
                                        &b64_len, (const unsigned char *)pcm_data, data_size);
    if (b64_ret != 0) {
        ESP_LOGE(TAG, "Base64 encode failed: %d", b64_ret);
        free(b64_buf);
        return ESP_FAIL;
    }

    /* Get device ID */
    char cuid[32];
    get_cuid(cuid, sizeof(cuid));

    /* Build JSON body */
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "format", "pcm");
    cJSON_AddNumberToObject(root, "rate", 16000);
    cJSON_AddNumberToObject(root, "channel", 1);
    cJSON_AddStringToObject(root, "cuid", cuid);
    cJSON_AddStringToObject(root, "token", token);
    cJSON_AddNumberToObject(root, "dev_pid", DEV_PID_MANDARIN_16K);
    cJSON_AddStringToObject(root, "speech", b64_buf);
    cJSON_AddNumberToObject(root, "len", (double)data_size);

    char *body = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    free(b64_buf); /* Base64 buffer no longer needed */

    if (body == NULL) {
        ESP_LOGE(TAG, "Failed to serialize JSON");
        return ESP_ERR_NO_MEM;
    }

    ESP_LOGI(TAG, "Sending ASR request: %d PCM bytes → %d base64 chars",
             data_size, b64_len);

    /* HTTP POST */
    esp_http_client_config_t http_cfg = {
        .url = ASR_URL,
        .method = HTTP_METHOD_POST,
        .timeout_ms = 15000,
    };
    esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
    if (client == NULL) {
        ESP_LOGE(TAG, "Failed to init HTTP client");
        free(body);
        return ESP_FAIL;
    }

    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_post_field(client, body, strlen(body));
    free(body);

    err = esp_http_client_perform(client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP request failed: %d (0x%x)", err, err);
        esp_http_client_cleanup(client);
        return err;
    }

    int status = esp_http_client_get_status_code(client);
    ESP_LOGI(TAG, "ASR HTTP status: %d", status);

    /* Read response */
    char *resp_buf = malloc(4096);
    if (resp_buf == NULL) {
        esp_http_client_cleanup(client);
        return ESP_ERR_NO_MEM;
    }

    int resp_len = esp_http_client_read_response(client, resp_buf, 4095);
    esp_http_client_cleanup(client);

    if (resp_len < 0) {
        ESP_LOGE(TAG, "Failed to read response");
        free(resp_buf);
        return ESP_FAIL;
    }
    resp_buf[resp_len] = '\0';

    ESP_LOGI(TAG, "ASR response: %s", resp_buf);

    /* Parse JSON */
    cJSON *json = cJSON_Parse(resp_buf);
    free(resp_buf);

    if (json == NULL) {
        ESP_LOGE(TAG, "Failed to parse response JSON");
        return ESP_FAIL;
    }

    cJSON *err_no = cJSON_GetObjectItem(json, "err_no");
    if (err_no == NULL || !cJSON_IsNumber(err_no) || err_no->valueint != 0) {
        cJSON *err_msg = cJSON_GetObjectItem(json, "err_msg");
        ESP_LOGE(TAG, "ASR error: err_no=%d, err_msg=%s",
                 err_no ? err_no->valueint : -1,
                 err_msg ? err_msg->valuestring : "unknown");
        cJSON_Delete(json);
        return ESP_FAIL;
    }

    cJSON *result = cJSON_GetObjectItem(json, "result");
    if (result != NULL && cJSON_IsArray(result) && cJSON_GetArraySize(result) > 0) {
        cJSON *first = cJSON_GetArrayItem(result, 0);
        if (first != NULL && cJSON_IsString(first)) {
            *result_text = strdup(first->valuestring);
            ESP_LOGI(TAG, "Recognized: \"%s\"", *result_text);
        }
    }

    cJSON_Delete(json);

    if (*result_text == NULL) {
        ESP_LOGW(TAG, "No speech recognized (empty result)");
    }

    return ESP_OK;
}
