/*
 * Intent Engine — local rule-based intent matching.
 * Takes pinyin string from MultiNet, matches to intent_id via keyword lookup.
 * 100% local computation, no cloud dependency.
 */

#pragma once
#include "esp_err.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** High-level intent IDs */
typedef enum {
    INTENT_UNKNOWN = 0,
    INTENT_LIGHT_ON,
    INTENT_LIGHT_OFF,
    INTENT_LIGHT_BRIGHTNESS,
    INTENT_FAN_ON,
    INTENT_FAN_OFF,
    INTENT_FAN_SPEED,
    INTENT_TEMPERATURE_QUERY,
    INTENT_HUMIDITY_QUERY,
    INTENT_TIME_QUERY,
    INTENT_DATE_QUERY,
    INTENT_VOLUME_UP,
    INTENT_VOLUME_DOWN,
    INTENT_MUSIC_PLAY,
    INTENT_MUSIC_STOP,
    INTENT_OPEN_DOOR,
    INTENT_CLOSE_DOOR,
    INTENT_GREETING,
    INTENT_GOODBYE,
    INTENT_SELF_INTRO,
    INTENT_CLOUD_QUERY,       /* Triggers optional cloud extension */
    INTENT_JOKE,              /* Tell a random joke */
    INTENT_COUNT
} intent_id_t;

/** Parsed intent result */
typedef struct {
    intent_id_t  intent;
    int32_t      param_value;  /* Optional numeric parameter */
    float        confidence;   /* Pass-through from MultiNet */
} intent_result_t;

/** Match pinyin string to intent */
esp_err_t intent_engine_match(const char *command_pinyin,
                               float multinet_conf,
                               intent_result_t *result);

/** Get display name for an intent */
const char *intent_engine_get_name(intent_id_t intent);

/** Check if this intent requires cloud fallback */
bool intent_engine_needs_cloud(intent_id_t intent);

#ifdef __cplusplus
}
#endif
