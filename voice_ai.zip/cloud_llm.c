/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Cloud LLM — Baidu Qianfan ERNIE Bot API.
 * Sends user text + system prompt, returns AI reply.
 */

#include "cloud_llm.h"
#include "baidu_auth.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "cJSON.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

static const char *TAG = "cloud_llm";

/* System prompt stored in flash to save RAM */
static const char SYSTEM_PROMPT[] =
    "你是一个友好的语音助手，请用简短的口语回答。"
    "每次回答控制在100字以内，语气自然亲切。";

esp_err_t cloud_llm_chat(const char *user_text,
                         const char *api_key, const char *secret_key,
                         char **reply_text)
{
    if (user_text == NULL || reply_text == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    *reply_text = NULL;

    /* Get access token */
    const char *token = NULL;
    esp_err_t err = baidu_auth_get_token(api_key, secret_key, &token);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get access token");
        return err;
    }

    /* Build URL with access_token */
    char url[512];
    snprintf(url, sizeof(url),
             "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions"
             "?access_token=%s", token);

    /* Build JSON body */
    cJSON *root = cJSON_CreateObject();
    cJSON *messages = cJSON_CreateArray();

    /* System message */
    cJSON *sys_msg = cJSON_CreateObject();
    cJSON_AddStringToObject(sys_msg, "role", "system");
    cJSON_AddStringToObject(sys_msg, "content", SYSTEM_PROMPT);
    cJSON_AddItemToArray(messages, sys_msg);

    /* User message */
    cJSON *usr_msg = cJSON_CreateObject();
    cJSON_AddStringToObject(usr_msg, "role", "user");
    cJSON_AddStringToObject(usr_msg, "content", user_text);
    cJSON_AddItemToArray(messages, usr_msg);

    cJSON_AddItemToObject(root, "messages", messages);

    char *body = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);

    if (body == NULL) {
        ESP_LOGE(TAG, "Failed to serialize JSON");
        return ESP_ERR_NO_MEM;
    }

    ESP_LOGI(TAG, "Sending LLM request, body_len=%d", strlen(body));

    /* HTTP POST */
    esp_http_client_config_t http_cfg = {
        .url = url,
        .method = HTTP_METHOD_POST,
        .timeout_ms = 30000,
    };
    esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
    if (client == NULL) {
        ESP_LOGE(TAG, "Failed to init HTTP client");
        free(body);
        return ESP_FAIL;
    }

    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_post_field(client, body, strlen(body));
    free(body);

    err = esp_http_client_perform(client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP request failed: %d", err);
        esp_http_client_cleanup(client);
        return err;
    }

    int status = esp_http_client_get_status_code(client);
    ESP_LOGI(TAG, "LLM HTTP status: %d", status);

    /* Read response */
    char *resp_buf = malloc(8192);
    if (resp_buf == NULL) {
        esp_http_client_cleanup(client);
        return ESP_ERR_NO_MEM;
    }

    int resp_len = esp_http_client_read_response(client, resp_buf, 8191);
    esp_http_client_cleanup(client);

    if (resp_len < 0) {
        ESP_LOGE(TAG, "Failed to read response");
        free(resp_buf);
        return ESP_FAIL;
    }
    resp_buf[resp_len] = '\0';

    ESP_LOGI(TAG, "LLM response: %s", resp_buf);

    /* Parse JSON */
    cJSON *json = cJSON_Parse(resp_buf);
    free(resp_buf);

    if (json == NULL) {
        ESP_LOGE(TAG, "Failed to parse response JSON");
        return ESP_FAIL;
    }

    /* Check for error */
    cJSON *error_code = cJSON_GetObjectItem(json, "error_code");
    if (error_code != NULL) {
        cJSON *error_msg = cJSON_GetObjectItem(json, "error_msg");
        ESP_LOGE(TAG, "LLM API error: code=%d, msg=%s",
                 error_code->valueint,
                 error_msg ? error_msg->valuestring : "unknown");
        cJSON_Delete(json);
        return ESP_FAIL;
    }

    /* Extract result field */
    cJSON *result = cJSON_GetObjectItem(json, "result");
    if (result != NULL && cJSON_IsString(result)) {
        *reply_text = strdup(result->valuestring);
        ESP_LOGI(TAG, "LLM reply: \"%s\"", *reply_text);
    } else {
        ESP_LOGE(TAG, "No 'result' field in response");
    }

    cJSON_Delete(json);

    if (*reply_text == NULL) {
        return ESP_FAIL;
    }

    return ESP_OK;
}
