/*
 * TTS Bridge — local Chinese TTS using ESP-SR's esp_tts_chinese.
 * Loads xiaole (小乐) voice data from SPIFFS into PSRAM at init.
 * Converts Chinese text to PCM and streams to speaker via board_audio.
 */

#pragma once
#include "esp_err.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Init TTS: load voice data from /spiffs/xiaole_voice.dat → PSRAM.
 *  Must be called after SPIFFS is mounted. */
esp_err_t tts_bridge_init(void);

/** Synthesize Chinese text and play through speaker.
 *  Blocks until playback completes.
 *  @param text  UTF-8 Chinese string, e.g. "现在是下午三点" */
esp_err_t tts_bridge_speak(const char *text);

/** Check if TTS is ready. */
bool tts_bridge_is_ready(void);

#ifdef __cplusplus
}
#endif
