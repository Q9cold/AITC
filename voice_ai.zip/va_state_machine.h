/*
 * VA State Machine — main orchestrator.
 * Coordinates AFE, MultiNet, Intent Engine, Local Response, and Cloud Optional.
 * Runs on Core 0 as the main application loop.
 */

#pragma once
#include "esp_err.h"
#include "intent_engine.h"

#ifdef __cplusplus
extern "C" {
#endif

/** State machine states */
typedef enum {
    VA_SM_INIT,
    VA_SM_IDLE_LISTENING,
    VA_SM_WAKE_DETECTED,
    VA_SM_COMMAND_LISTENING,
    VA_SM_COMMAND_RECOGNIZED,
    VA_SM_INTENT_PROCESSING,
    VA_SM_RESPONDING,
    VA_SM_CLOUD_QUERYING,
    VA_SM_IOT_ALERT,       /* IoT-triggered alert (BLE, preemptive) */
    VA_SM_ERROR
} va_sm_state_t;

/** Init all sub-modules and prepare state machine */
esp_err_t va_state_machine_init(void);

/** Run the state machine loop (blocking, never returns) */
void va_state_machine_run(void);

/** Get current state (for LED / debug) */
va_sm_state_t va_state_machine_get_state(void);

#ifdef __cplusplus
}
#endif
