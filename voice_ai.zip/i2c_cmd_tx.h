#pragma once
#include "esp_err.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// I2C 从设备地址（本机在 I2C 总线上的地址）
// 与 posture_terminal 约定: hello_esp 从机地址 = 0x2A
// ============================================================
#define I2C_SLAVE_ADDR  0x2A

esp_err_t i2c_cmd_tx_init(void);
void i2c_cmd_send(const char *text);
void i2c_cmd_send_intent(int id);

typedef enum {
    I2C_ALERT_NONE    = 0,
    I2C_ALERT_POSTURE = 1,
    I2C_ALERT_PRESS   = 2,
    I2C_ALERT_MUSIC   = 3,   // 屏幕 UI 音乐按键
} i2c_alert_type_t;

void i2c_cmd_start_alert_rx(void);
i2c_alert_type_t i2c_cmd_poll_alert(void);
i2c_alert_type_t i2c_cmd_consume_alert(void);

#ifdef __cplusplus
}
#endif
