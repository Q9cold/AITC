/**
 * @file i2c_cmd_tx.c
 * @brief I2C 从机双向通信 — GPIO9(SDA)/GPIO10(SCL), I2C_NUM_0
 *        ESP32-S3 作为 I2C 从设备（地址 0x2A），对接屏幕主设备。
 *        使用新版 I2C driver (driver_ng)。
 */
#include "i2c_cmd_tx.h"
#include "driver/i2c_slave.h"
#include "driver/i2c_types.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include <string.h>
#include <stdio.h>

#define I2C_PORT        I2C_NUM_0   // GPIO9/10 的 IO MUX 默认就是 I2C0
#define SDA_PIN         9
#define SCL_PIN         10
#define TX_BUF_DEPTH    512
#define RX_BUF_SIZE     8

static i2c_slave_dev_handle_t s_i2c_slave;
static SemaphoreHandle_t      s_rx_sem;
static volatile char s_cmd_buf[129];
static volatile bool s_cmd_ready;
static volatile i2c_alert_type_t s_alert_type;
static volatile bool             s_alert_pending;

static bool IRAM_ATTR on_recv_done(i2c_slave_dev_handle_t slave,
                                    const i2c_slave_rx_done_event_data_t *evt,
                                    void *arg)
{
    if (evt && evt->buffer) {
        uint8_t alert = evt->buffer[0];
        if (alert == 1)      { s_alert_type = I2C_ALERT_POSTURE; s_alert_pending = true; }
        else if (alert == 2) { s_alert_type = I2C_ALERT_PRESS;   s_alert_pending = true; }
        else if (alert == 3) { s_alert_type = I2C_ALERT_MUSIC;   s_alert_pending = true; }
    }
    BaseType_t high_wake = pdFALSE;
    xSemaphoreGiveFromISR(s_rx_sem, &high_wake);
    return high_wake == pdTRUE;
}

static void rx_task(void *arg)
{
    uint8_t buf[RX_BUF_SIZE];
    while (1) {
        memset(buf, 0, sizeof(buf));
        i2c_slave_receive(s_i2c_slave, buf, sizeof(buf));
        xSemaphoreTake(s_rx_sem, portMAX_DELAY);
    }
}

static void tx_task(void *arg)
{
    while (1) {
        uint8_t frame[130]; int total;
        if (s_cmd_ready) {
            size_t len = strlen((const char *)s_cmd_buf);
            if (len > 128) len = 128;
            frame[0] = (uint8_t)len;
            memcpy(&frame[1], (const void *)s_cmd_buf, len);
            total = (int)len + 1;
            esp_err_t err = i2c_slave_transmit(s_i2c_slave, frame, total, pdMS_TO_TICKS(1000));
            if (err == ESP_OK) { s_cmd_ready = false; printf("[I2C] cmd sent\n"); }
            vTaskDelay(pdMS_TO_TICKS(50));
        } else {
            vTaskDelay(pdMS_TO_TICKS(300));
        }
    }
}

esp_err_t i2c_cmd_tx_init(void)
{
    i2c_slave_config_t cfg = {
        .i2c_port = I2C_PORT, .sda_io_num = SDA_PIN, .scl_io_num = SCL_PIN,
        .clk_source = I2C_CLK_SRC_DEFAULT, .send_buf_depth = TX_BUF_DEPTH,
        .slave_addr = I2C_SLAVE_ADDR, .addr_bit_len = I2C_ADDR_BIT_LEN_7,
    };
    ESP_ERROR_CHECK(i2c_new_slave_device(&cfg, &s_i2c_slave));

    // I2C 从机必须手动开上拉（新驱动不自带）
    gpio_set_pull_mode(SDA_PIN, GPIO_PULLUP_ONLY);
    gpio_set_pull_mode(SCL_PIN, GPIO_PULLUP_ONLY);
    // Open-drain: level=1 释放总线, level=0 拉低。默认必须释放
    gpio_set_level(SDA_PIN, 1);
    gpio_set_level(SCL_PIN, 1);

    i2c_slave_event_callbacks_t cbs = { .on_recv_done = on_recv_done };
    ESP_ERROR_CHECK(i2c_slave_register_event_callbacks(s_i2c_slave, &cbs, NULL));

    s_rx_sem = xSemaphoreCreateBinary();
    s_cmd_ready = false;
    xTaskCreate(tx_task, "i2c_tx", 3072, NULL, 4, NULL);

    printf("[I2C] slave init OK PORT=%d SDA=GPIO%d SCL=GPIO%d addr=0x%02X\n",
           I2C_PORT, SDA_PIN, SCL_PIN, I2C_SLAVE_ADDR);
    return ESP_OK;
}

void i2c_cmd_start_alert_rx(void)
{
    xTaskCreate(rx_task, "i2c_rx", 3072, NULL, 5, NULL);
}

void i2c_cmd_send(const char *text)
{
    if (!text) return;
    size_t len = strlen(text);
    if (len > 128) len = 128;
    memcpy((void *)s_cmd_buf, text, len);
    ((char *)s_cmd_buf)[len] = '\0';
    s_cmd_ready = true;
    printf("[I2C] cmd queued: \"%s\"\n", (const char *)s_cmd_buf);
}

void i2c_cmd_send_intent(int id)
{
    static const char *t[] = {
        [0]="未知命令",[1]="打开灯光",[2]="关闭灯光",[3]="调亮度",
        [4]="打开风扇",[5]="关闭风扇",[6]="调风速",[7]="查询温度",
        [8]="查询湿度",[9]="查询时间",[10]="查询日期",[11]="音量加大",
        [12]="音量减小",[13]="播放音乐",[14]="停止播放",[15]="打开门",
        [16]="关闭门",[17]="你好",[18]="再见",[19]="自我介绍",[20]="云端查询",
    };
    int n = sizeof(t)/sizeof(t[0]);
    if (id >= 0 && id < n && t[id]) i2c_cmd_send(t[id]);
}

i2c_alert_type_t i2c_cmd_poll_alert(void)  { return s_alert_pending ? (i2c_alert_type_t)s_alert_type : I2C_ALERT_NONE; }
i2c_alert_type_t i2c_cmd_consume_alert(void){ i2c_alert_type_t a = s_alert_type; s_alert_type = I2C_ALERT_NONE; s_alert_pending = false; return a; }
