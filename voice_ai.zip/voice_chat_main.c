/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Voice Chat AI — Application entry point.
 * Initializes WiFi, GPIO, Baidu auth, and the voice assistant.
 * Main loop polls the button to trigger voice conversations.
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_event.h"
#include "nvs_flash.h"

#include "wifi_station.h"
#include "gpio_control.h"
#include "baidu_auth.h"
#include "voice_assistant.h"

static const char *TAG = "voice_chat";

/* --- Configuration (override via menuconfig / Kconfig.projbuild) --- */

#ifndef CONFIG_VA_WIFI_SSID
#define CONFIG_VA_WIFI_SSID "那维莱特的大典Pro"
#endif

#ifndef CONFIG_VA_WIFI_PASS
#define CONFIG_VA_WIFI_PASS "200506080612"
#endif

#ifndef CONFIG_VA_BAIDU_API_KEY
#define CONFIG_VA_BAIDU_API_KEY ""
#endif

#ifndef CONFIG_VA_BAIDU_SECRET_KEY
#define CONFIG_VA_BAIDU_SECRET_KEY ""
#endif

void app_main(void)
{
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "  Voice Chat AI — ESP32-S3");
    ESP_LOGI(TAG, "  Free heap: %u bytes", (unsigned int)esp_get_free_heap_size());
    ESP_LOGI(TAG, "========================================");

    /* --- Step 1: NVS init (required for WiFi) --- */
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    ESP_LOGI(TAG, "NVS initialized");

    /* --- Step 2: GPIO init (button + LED) --- */
    ret = gpio_control_init(CONFIG_VA_BUTTON_GPIO, CONFIG_VA_LED_GPIO);
    ESP_ERROR_CHECK(ret);
    gpio_control_set_led_state(LED_WIFI_CONNECTING);

    /* --- Step 3: WiFi connect --- */
    ESP_LOGI(TAG, "Connecting to WiFi SSID: %s", CONFIG_VA_WIFI_SSID);
    ret = wifi_station_connect(CONFIG_VA_WIFI_SSID, CONFIG_VA_WIFI_PASS, 5);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi connection FAILED, restarting in 5s...");
        gpio_control_set_led_state(LED_ERROR);
        vTaskDelay(pdMS_TO_TICKS(5000));
        esp_restart();
    }

    ESP_LOGI(TAG, "WiFi connected, free heap: %u", (unsigned int)esp_get_free_heap_size());

    /* --- Step 4: Pre-fetch Baidu access token --- */
    const char *api_key = CONFIG_VA_BAIDU_API_KEY;
    const char *secret_key = CONFIG_VA_BAIDU_SECRET_KEY;

    if (strlen(api_key) == 0 || strlen(secret_key) == 0) {
        ESP_LOGW(TAG, "⚠  Baidu API Key or Secret Key not configured!");
        ESP_LOGW(TAG, "   Use 'idf.py menuconfig' → Voice Chat Configuration");
        ESP_LOGW(TAG, "   to set your Baidu Cloud credentials.");
        gpio_control_set_led_state(LED_ERROR);
        vTaskDelay(pdMS_TO_TICKS(10000));
        esp_restart();
    }

    const char *token = NULL;
    ret = baidu_auth_get_token(api_key, secret_key, &token);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get Baidu access token, restarting in 5s...");
        gpio_control_set_led_state(LED_ERROR);
        vTaskDelay(pdMS_TO_TICKS(5000));
        esp_restart();
    }
    ESP_LOGI(TAG, "Baidu access token obtained");

    /* --- Step 5: Initialize voice assistant --- */
    ret = voice_assistant_init(api_key, secret_key);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to init voice assistant");
        gpio_control_set_led_state(LED_ERROR);
        vTaskDelay(pdMS_TO_TICKS(5000));
        esp_restart();
    }

    gpio_control_set_led_state(LED_IDLE);
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "  Ready! Press the button to talk.");
    ESP_LOGI(TAG, "  Free heap: %u bytes", (unsigned int)esp_get_free_heap_size());
    ESP_LOGI(TAG, "========================================");

    /* --- Step 6: Main loop — wait for button press --- */
    while (1) {
        /* Wait for button press */
        if (gpio_control_wait_for_press(portMAX_DELAY)) {
            ESP_LOGI(TAG, "Button pressed! Triggering voice assistant...");
            gpio_control_set_led_state(LED_RECORDING);

            /* Brief delay so user hears the press before speaking */
            vTaskDelay(pdMS_TO_TICKS(200));

            voice_assistant_trigger();

            /* Wait for the cycle to complete before accepting next press */
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
}
