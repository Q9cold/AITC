/*
 * AFE Runner — AFE V2 + WakeNet9 wrapper.
 * Always-on wake word detection using ESP-SR.
 * Two FreeRTOS tasks: Feed (I2S → AFE ringbuf) and Fetch (AFE → WakeNet).
 * Runs on Core 1 to keep real-time audio isolated from app logic.
 */

#pragma once
#include "esp_err.h"
#include "hal/gpio_types.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Callback when wake word is detected */
typedef void (*afe_wake_callback_t)(void *user_ctx);

typedef struct {
    uint32_t    sample_rate_hz;         /* Typically 16000 */
    gpio_num_t  mic_bclk_gpio;          /* I2S bit clock (BCLK) — INMP441 SCK */
    gpio_num_t  mic_ws_gpio;            /* I2S word select (WS) — INMP441 WS */
    gpio_num_t  mic_din_gpio;           /* I2S data input (DIN) — INMP441 SD */
    const char *model_partition_label; /* "model" */
    afe_wake_callback_t on_wake;       /* Called from fetch task on detection */
    void       *wake_user_ctx;         /* Passed to callback */
} afe_runner_config_t;

/** Initialize AFE, load WakeNet model, start feed/fetch tasks */
esp_err_t afe_runner_init(const afe_runner_config_t *config);

/** Non-blocking check: was a wake word just detected? */
bool afe_runner_is_wake_detected(void);

/** Clear the wake-detected flag after consuming */
void afe_runner_clear_wake_flag(void);

/** Get pointer to most recent audio ring buffer (deprecated — kept for compat) */
const int16_t *afe_runner_get_audio_buffer(size_t *out_sample_count);

/** Enable/disable MultiNet feeding from AFE fetch task.
 *  When enabled, fetch_task directly feeds AFE output to MultiNet.
 *  Call with false after command is recognized or timeout. */
esp_err_t afe_runner_set_multinet_enabled(bool enabled);

/** De-init AFE and free resources */
esp_err_t afe_runner_deinit(void);

#ifdef __cplusplus
}
#endif
