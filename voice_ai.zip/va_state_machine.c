/*
 * VA State Machine — main orchestrator for competition-compliant voice AI.
 *
 * Coordinates the full local pipeline:
 *   AFE (always-on) → WakeNet → MultiNet → Intent Engine → Local Response
 * With optional cloud extension for open-domain queries.
 *
 * ALL core AI (wake word, command recognition, intent matching, response)
 * runs 100% LOCALLY on ESP32-S3. Cloud is clearly separated and optional.
 */

#include "va_state_machine.h"
#include "afe_runner.h"
#include "multinet_runner.h"
#include "intent_engine.h"
#include "command_config.h"
#include "local_response.h"
#include "audio_output.h"
#include "gpio_control.h"

#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
#include "cloud_optional.h"
#include "wifi_sntp.h"
#include "tts_bridge.h"
#include "wifi_station.h"
#include "board_audio_init.h"
#endif

#include "i2c_cmd_tx.h"
#include "uart_cmd_tx.h"
#include "udp_bridge.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <stdio.h>

static const char *TAG = "va_sm";

/* ─── GPIO defaults ─── */
#ifndef CONFIG_VA_I2S_MIC_BCLK_GPIO
#define CONFIG_VA_I2S_MIC_BCLK_GPIO  4
#endif
#ifndef CONFIG_VA_I2S_MIC_WS_GPIO
#define CONFIG_VA_I2S_MIC_WS_GPIO    5
#endif
#ifndef CONFIG_VA_I2S_MIC_DIN_GPIO
#define CONFIG_VA_I2S_MIC_DIN_GPIO   6
#endif

/* ─── State machine context ─── */
static va_sm_state_t s_state = VA_SM_INIT;
static intent_result_t s_pending_intent;
static bool s_play_unknown = false;
static uint32_t s_cmd_start_ms = 0;
static char s_cloud_query_text[MULTINET_MAX_CMD_STR_LEN]; /* pinyin query for cloud fallback */
static int s_current_volume = 70;  /* 0-100, tracked across volume changes */

/* ─── AFE wake callback ─── */
static void on_wake_detected(void *ctx)
{
    /* Called from AFE fetch task on Core 1.
     * Set LED, abort any ongoing playback, and transition state. */
    gpio_control_set_led_state(LED_WAKE_ACTIVE);
    local_response_abort_playback();   /* interrupt music / WAV playback */
}

/* ─── Initialize all sub-modules ─── */
esp_err_t va_state_machine_init(void)
{
    ESP_LOGI(TAG, "=== Initializing Voice AI State Machine ===");

    /* Reset pending intent */
    memset(&s_pending_intent, 0, sizeof(s_pending_intent));
    s_play_unknown = false;

    uart_cmd_tx_init();
    uart_cmd_start_alert_rx();
    udp_bridge_init();

    /* Init local response (SPIFFS WAV playback) */
    esp_err_t err = local_response_init();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "local_response_init failed");
        return err;
    }

    /* Init MultiNet runner (command recognition) */
    err = multinet_runner_init("model",
                                g_cmd_pinyin_list, g_cmd_count,
                                MULTINET_TIMEOUT_DEFAULT);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "multinet_runner_init failed");
        return err;
    }

    /* Init AFE runner (always-on wake word detection) */
    afe_runner_config_t afe_cfg = {
        .sample_rate_hz = 16000,
        .mic_bclk_gpio = CONFIG_VA_I2S_MIC_BCLK_GPIO,
        .mic_ws_gpio   = CONFIG_VA_I2S_MIC_WS_GPIO,
        .mic_din_gpio  = CONFIG_VA_I2S_MIC_DIN_GPIO,
        .model_partition_label = "model",
        .on_wake = on_wake_detected,
        .wake_user_ctx = NULL,
    };

    err = afe_runner_init(&afe_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "afe_runner_init failed");
        return err;
    }

#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
    cloud_optional_init(CONFIG_VA_CLOUD_API_KEY);
#endif

    /* I2C 从机 — 最后初始化，不干扰音频/AI 驱动 */
    i2c_cmd_tx_init();
    i2c_cmd_start_alert_rx();

    s_state = VA_SM_IDLE_LISTENING;
    ESP_LOGI(TAG, "=== Voice AI ready! Listening for wake word... ===");
    return ESP_OK;
}

/* ─── Main state machine loop ─── */
void va_state_machine_run(void)
{
    multinet_result_t mn_result;
    esp_err_t err;

    ESP_LOGI(TAG, "State machine loop started");

    while (1) {


        /* ── Preempt for posture alerts from terminal (I2C + UART) ── */
        if (i2c_cmd_poll_alert() != I2C_ALERT_NONE ||
            uart_cmd_poll_alert() != UART_ALERT_NONE ||
            udp_bridge_poll_alert() != UDP_ALERT_NONE) {
            local_response_abort_playback();
            vTaskDelay(pdMS_TO_TICKS(60));
            s_state = VA_SM_IOT_ALERT;
            ESP_LOGI(TAG, "→ IOT_ALERT");
        }

        switch (s_state) {

        /* ── IDLE: always listening for wake word ── */
        case VA_SM_IDLE_LISTENING:
            gpio_control_set_led_state(LED_IDLE);

            if (afe_runner_is_wake_detected()) {
                afe_runner_clear_wake_flag();
                s_state = VA_SM_WAKE_DETECTED;
                ESP_LOGI(TAG, "→ WAKE_DETECTED");
            }
            vTaskDelay(pdMS_TO_TICKS(30)); /* 30ms poll cycle */
            break;

        /* ── WAKE: acknowledge, reset, enable MultiNet feed ── */
        case VA_SM_WAKE_DETECTED:
            gpio_control_set_led_state(LED_WAKE_ACTIVE);
            vTaskDelay(pdMS_TO_TICKS(20)); /* Brief LED blink */

            local_response_clear_abort();   /* clear stale flag from wake callback */
            multinet_runner_reset();
            afe_runner_set_multinet_enabled(true);  /* Start feeding AFE→MultiNet */
            s_cmd_start_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
            s_cloud_query_text[0] = '\0';  /* Clear previous cloud query */
            s_state = VA_SM_COMMAND_LISTENING;
            ESP_LOGI(TAG, "→ COMMAND_LISTENING");
            break;

        /* ── COMMAND LISTENING: MultiNet fed by AFE fetch task ── */
        case VA_SM_COMMAND_LISTENING:
            gpio_control_set_led_state(LED_COMMAND_LISTENING);

            /* MultiNet is now fed directly from AFE fetch output
             * (afe_runner fetch_task → multinet_runner_feed).
             * No more ring-buffer polling here. */

            /* Check for result */
            err = multinet_runner_get_result(&mn_result);
            if (err == ESP_OK) {
                afe_runner_set_multinet_enabled(false);
                s_state = VA_SM_COMMAND_RECOGNIZED;
                ESP_LOGI(TAG, "→ COMMAND_RECOGNIZED: %s (conf=%.2f)",
                         mn_result.command_str, mn_result.confidence);
                /* Low-confidence → treat as "I don't know this command" → cloud */
                if (mn_result.confidence < 0.10f) {
                    ESP_LOGI(TAG, "Low confidence (%.2f) — routing to cloud",
                             mn_result.confidence);
#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
                    s_pending_intent.intent = INTENT_CLOUD_QUERY;
                    s_pending_intent.param_value = 0;
                    strncpy(s_cloud_query_text, mn_result.command_str,
                            sizeof(s_cloud_query_text) - 1);
                    s_cloud_query_text[sizeof(s_cloud_query_text) - 1] = '\0';
#else
                    s_play_unknown = true;
#endif
                } else if (intent_engine_match(mn_result.command_str,
                                         mn_result.confidence,
                                         &s_pending_intent) != ESP_OK) {
#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
                    /* Offline command not matched — save pinyin for cloud fallback */
                    s_pending_intent.intent = INTENT_CLOUD_QUERY;
                    s_pending_intent.param_value = 0;
                    strncpy(s_cloud_query_text, mn_result.command_str,
                            sizeof(s_cloud_query_text) - 1);
                    s_cloud_query_text[sizeof(s_cloud_query_text) - 1] = '\0';
                    ESP_LOGI(TAG, "No offline match — will query cloud with: \"%s\"",
                             s_cloud_query_text);
#else
                    s_play_unknown = true;
#endif
                } else {
                    i2c_cmd_send_intent(s_pending_intent.intent);
                    uart_cmd_send_intent(s_pending_intent.intent);
                    udp_bridge_send_intent(s_pending_intent.intent);
                    /* Save pinyin for cloud queries (matched intents too) */
                    if (intent_engine_needs_cloud(s_pending_intent.intent)) {
                        strncpy(s_cloud_query_text, mn_result.command_str,
                                sizeof(s_cloud_query_text) - 1);
                        s_cloud_query_text[sizeof(s_cloud_query_text) - 1] = '\0';
                    }
                }
            } else if (err == ESP_ERR_TIMEOUT) {
                afe_runner_set_multinet_enabled(false);
                ESP_LOGW(TAG, "Command timeout — playing unknown");
                s_play_unknown = true;
                s_state = VA_SM_RESPONDING;
            }
            vTaskDelay(pdMS_TO_TICKS(30));
            break;

        /* ── COMMAND RECOGNIZED: route to processing ── */
        case VA_SM_COMMAND_RECOGNIZED:
            if (s_play_unknown) {
                s_state = VA_SM_RESPONDING;
            } else {
                s_state = VA_SM_INTENT_PROCESSING;
            }
            ESP_LOGI(TAG, "→ INTENT_PROCESSING");
            break;

        /* ── INTENT PROCESSING: decide local vs cloud ── */
        case VA_SM_INTENT_PROCESSING:
            gpio_control_set_led_state(LED_PROCESSING);

#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
            /* Time/Date queries: speak via TTS (xiaole voice) */
            if (s_pending_intent.intent == INTENT_TIME_QUERY ||
                s_pending_intent.intent == INTENT_DATE_QUERY) {
                const char *text = NULL;
                if (s_pending_intent.intent == INTENT_TIME_QUERY)
                    text = wifi_sntp_get_time_string();
                else if (s_pending_intent.intent == INTENT_DATE_QUERY)
                    text = wifi_sntp_get_weekday_string();
                if (text && tts_bridge_is_ready() && wifi_sntp_is_synced()) {
                    ESP_LOGI(TAG, "→ TTS speak: %s", text);
                    tts_bridge_speak(text);
                    s_state = VA_SM_IDLE_LISTENING;
                    gpio_control_set_led_state(LED_IDLE);
                } else {
                    ESP_LOGW(TAG, "TTS/time not available — using WAV fallback");
                    s_state = VA_SM_RESPONDING;
                }
                break;
            }

            /* Volume up only: adjust hardware volume + TTS announce
             * (VOLUME_DOWN falls through to RESPONDING → rsp_dragon.wav) */
            if (s_pending_intent.intent == INTENT_VOLUME_UP) {
                int step = (int)s_pending_intent.param_value;
                if (step <= 0) step = 5; /* default step */
                if (s_pending_intent.intent == INTENT_VOLUME_DOWN)
                    step = -step;
                s_current_volume += step;
                if (s_current_volume > 100) s_current_volume = 100;
                if (s_current_volume < 0)   s_current_volume = 0;
                /* Initialise codec before setting volume (idempotent) */
                audio_output_init(16000, 0, 0, 0);
                board_audio_set_volume(s_current_volume);
                ESP_LOGI(TAG, "Volume set to %d%%", s_current_volume);
                if (tts_bridge_is_ready()) {
                    char vol_msg[64];
                    snprintf(vol_msg, sizeof(vol_msg), "音量已调到百分之%d", s_current_volume);
                    tts_bridge_speak(vol_msg);
                }
                s_state = VA_SM_IDLE_LISTENING;
                gpio_control_set_led_state(LED_IDLE);
                break;
            }

            /* Joke: random local WAV (offline) */
            if (s_pending_intent.intent == INTENT_JOKE) {
                s_state = VA_SM_RESPONDING;
                break;
            }

            /* "搜索一下" (param=1): WiFi already connected → confirm and go idle */
            if (s_pending_intent.intent == INTENT_CLOUD_QUERY &&
                s_pending_intent.param_value == 1 &&
                cloud_optional_is_available()) {
                s_state = VA_SM_RESPONDING;
                s_pending_intent.param_value = 99; /* signal: play wifi-ok WAV */
                break;
            }

            /* Cloud query with WiFi-reconnect flag (param=1, e.g. "搜索一下") */
            if (s_pending_intent.intent == INTENT_CLOUD_QUERY &&
                s_pending_intent.param_value == 1 &&
                !cloud_optional_is_available()) {
                ESP_LOGI(TAG, "WiFi reconnect for cloud search...");
                err = wifi_station_connect(CONFIG_VA_WIFI_SSID,
                                            CONFIG_VA_WIFI_PASS, 5);
                if (err == ESP_OK) {
                    cloud_optional_init(CONFIG_VA_CLOUD_API_KEY);
                    wifi_sntp_init();
                    ESP_LOGI(TAG, "WiFi reconnected — cloud available");
                    s_state = VA_SM_RESPONDING;
                    s_pending_intent.intent = INTENT_CLOUD_QUERY;
                    s_pending_intent.param_value = 99; /* signal: play wifi-ok WAV then cloud */
                } else {
                    ESP_LOGE(TAG, "WiFi reconnect failed");
                    s_state = VA_SM_RESPONDING;
                    s_pending_intent.intent = INTENT_CLOUD_QUERY;
                    s_pending_intent.param_value = 98; /* signal: play no-wifi WAV */
                }
                break;
            }

            if (intent_engine_needs_cloud(s_pending_intent.intent)) {
                if (cloud_optional_is_available()) {
                    s_state = VA_SM_CLOUD_QUERYING;
                    ESP_LOGI(TAG, "→ CLOUD_QUERYING (auxiliary)");
                } else {
                    ESP_LOGW(TAG, "Cloud not available — using offline response");
                    s_play_unknown = true;
                    s_state = VA_SM_RESPONDING;
                }
            } else
#endif
            {
                s_state = VA_SM_RESPONDING;
                ESP_LOGI(TAG, "→ RESPONDING (local)");
            }
            break;

        /* ── RESPONDING: play WAV response ── */
        case VA_SM_RESPONDING:
            gpio_control_set_led_state(LED_RESPONDING);

            if (s_play_unknown) {
                local_response_play_unknown();
                s_play_unknown = false;
            } else if (s_pending_intent.intent == INTENT_LIGHT_ON) {
                local_response_play_named("rsp_apple.wav");
            } else if (s_pending_intent.intent == INTENT_LIGHT_OFF) {
                local_response_play_named("rsp_banana.wav");
            } else if (s_pending_intent.intent == INTENT_LIGHT_BRIGHTNESS) {
                local_response_play_named("rsp_pear.wav");
            } else if (s_pending_intent.intent == INTENT_VOLUME_DOWN) {
                local_response_play_named("rsp_dragon.wav");
            } else if (s_pending_intent.intent == INTENT_MUSIC_PLAY) {
                local_response_play_named("rsp_music.wav");
            } else if (s_pending_intent.intent == INTENT_MUSIC_STOP) {
                local_response_play_named("rsp_car.wav");
            } else if (s_pending_intent.intent == INTENT_JOKE) {
                local_response_play_joke();
            } else if (s_pending_intent.param_value == 98) {
                /* WiFi reconnect failed → "好像没有连接到网络哦" */
                local_response_play_named("rsp_no_wifi.wav");
            } else if (s_pending_intent.param_value == 99) {
                /* WiFi reconnected → "已经连上网络啦，快来问我吧" → back to listening */
                local_response_play_named("rsp_wifi_ok.wav");
            } else {
                local_response_play(s_pending_intent.intent,
                                    s_pending_intent.param_value);
            }

            /* Back to listening */
            s_state = VA_SM_IDLE_LISTENING;
            gpio_control_set_led_state(LED_IDLE);
            ESP_LOGI(TAG, "→ IDLE_LISTENING");
            break;

        /* ── CLOUD QUERYING: optional HTTP request ── */
        case VA_SM_CLOUD_QUERYING:
#ifdef CONFIG_VA_ENABLE_CLOUD_EXTENSION
            gpio_control_set_led_state(LED_CLOUD_QUERYING);
            {
                /* Determine query text:
                 * - Unmatched offline commands: use saved MultiNet pinyin
                 * - Temperature/Humidity: use fixed Chinese queries */
                /* Use saved pinyin as query text (set for both matched
                 * and unmatched cloud intents in COMMAND_LISTENING) */
                const char *query = s_cloud_query_text;
                if (query[0] == '\0') {
                    query = "查询";  /* fallback only if nothing was saved */
                }

                char *cloud_resp = NULL;
                err = cloud_optional_query(query, &cloud_resp);
                if (err == ESP_OK && cloud_resp != NULL) {
                    ESP_LOGI(TAG, "Cloud response: %s", cloud_resp);
                    /* Speak via local TTS (xiaole voice) */
                    if (tts_bridge_is_ready()) {
                        ESP_LOGI(TAG, "→ TTS speak cloud response");
                        gpio_control_set_led_state(LED_PLAYING);
                        tts_bridge_speak(cloud_resp);
                        s_state = VA_SM_IDLE_LISTENING;
                        gpio_control_set_led_state(LED_IDLE);
                    } else {
                        ESP_LOGW(TAG, "TTS not ready — playing unknown.wav fallback");
                        s_play_unknown = true;
                        s_state = VA_SM_RESPONDING;
                    }
                    free(cloud_resp);
                } else {
                    ESP_LOGE(TAG, "Cloud query failed");
                    s_play_unknown = true;
                    s_state = VA_SM_RESPONDING;
                }
            }
            ESP_LOGI(TAG, "→ %s",
                     s_state == VA_SM_IDLE_LISTENING ? "IDLE_LISTENING" : "RESPONDING");
            break;
#else
            s_state = VA_SM_RESPONDING;
            s_play_unknown = true;
            break;
#endif

        /* ── IOT ALERT: play posture warning (triggered by terminal via UART) ── */
        case VA_SM_IOT_ALERT:
            gpio_control_set_led_state(LED_RESPONDING);
            {
                // I2C → UART → TCP 顺序消费
                i2c_alert_type_t alert = i2c_cmd_consume_alert();
                if (alert == I2C_ALERT_NONE)
                    alert = (i2c_alert_type_t)uart_cmd_consume_alert();
                if (alert == I2C_ALERT_NONE)
                    alert = (i2c_alert_type_t)udp_bridge_consume_alert();
                ESP_LOGI(TAG, "IoT alert: type=%d", (int)alert);
                local_response_clear_abort();  // 清除进入 IOT_ALERT 时设置的 abort 标志
                local_response_play_alert((int)alert);
            }
            s_state = VA_SM_IDLE_LISTENING;
            gpio_control_set_led_state(LED_IDLE);
            ESP_LOGI(TAG, "→ IDLE_LISTENING (after IoT alert)");
            break;

        /* ── ERROR: recover and return to listening ── */
        case VA_SM_ERROR:
        default:
            gpio_control_set_led_state(LED_ERROR);
            ESP_LOGE(TAG, "Error state — recovering in 3s...");
            vTaskDelay(pdMS_TO_TICKS(3000));
            s_state = VA_SM_IDLE_LISTENING;
            gpio_control_set_led_state(LED_IDLE);
            break;
        }
    }
}

va_sm_state_t va_state_machine_get_state(void)
{
    return s_state;
}
