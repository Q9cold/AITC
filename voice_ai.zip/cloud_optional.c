/*
 * Cloud Optional — auxiliary HTTP query module.
 * AUXILIARY: Only used for open-domain queries (weather, news, encyclopedia).
 * Core voice AI works 100% offline without this module.
 * Compiled only when CONFIG_VA_ENABLE_CLOUD_EXTENSION=y.
 */

#include "cloud_optional.h"
#include "esp_http_client.h"
#include "esp_crt_bundle.h"
#include "esp_log.h"
#include "cJSON.h"
#include "wifi_station.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

static const char *TAG = "cloud_optional";

static bool s_available = false;
static const char *s_api_key = NULL;

esp_err_t cloud_optional_init(const char *api_key)
{
    if (api_key == NULL || strlen(api_key) == 0) {
        ESP_LOGW(TAG, "No API key provided — cloud queries disabled");
        s_available = false;
        return ESP_OK;
    }

    s_api_key = api_key;
    s_available = true;
    ESP_LOGI(TAG, "Cloud optional module initialized (AUXILIARY)");
    return ESP_OK;
}

bool cloud_optional_is_available(void)
{
    return s_available;
}

esp_err_t cloud_optional_query(const char *query_text, char **response_text)
{
    if (!s_available || query_text == NULL || response_text == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    *response_text = NULL;

    /* Build HTTP request for DeepSeek V4 Pro (OpenAI-compatible API).
     * Escape the query text to prevent JSON injection. */
    char body[2048];
    char escaped_query[1024];
    const char *src = query_text;
    char *dst = escaped_query;
    while (*src && (dst - escaped_query) < (int)sizeof(escaped_query) - 2) {
        if (*src == '"' || *src == '\\') {
            *dst++ = '\\';
            *dst++ = *src++;
        } else if (*src == '\n') {
            *dst++ = '\\'; *dst++ = 'n'; src++;
        } else if (*src == '\r') {
            *dst++ = '\\'; *dst++ = 'r'; src++;
        } else {
            *dst++ = *src++;
        }
    }
    *dst = '\0';

    snprintf(body, sizeof(body),
             "{\"messages\":["
             "{\"role\":\"system\",\"content\":\"你是小龙，一个为小朋友服务的语音助手。"
             "用户输入可能是拼音。请始终用中文简短口语回答，控制在50字以内。即使涉及英文也要用中文答复。\"},"
             "{\"role\":\"user\",\"content\":\"%s\"}"
             "],\"model\":\"deepseek-chat\",\"max_tokens\":150}",
             escaped_query);

    esp_http_client_config_t http_cfg = {
        .url = "https://api.deepseek.com/chat/completions",
        .method = HTTP_METHOD_POST,
        .timeout_ms = 10000,
        .crt_bundle_attach = esp_crt_bundle_attach,
    };

    esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
    if (client == NULL) {
        return ESP_FAIL;
    }

    char auth_header[128];
    snprintf(auth_header, sizeof(auth_header), "Bearer %s", s_api_key);
    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_header(client, "Authorization", auth_header);

    /* Use manual open/write/fetch/read to handle chunked responses */
    esp_err_t err = esp_http_client_open(client, strlen(body));
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP open failed: %d", err);
        esp_http_client_cleanup(client);
        return err;
    }
    int wlen = esp_http_client_write(client, body, strlen(body));
    if (wlen < 0) {
        ESP_LOGE(TAG, "HTTP write failed: %d", wlen);
        esp_http_client_cleanup(client);
        return ESP_FAIL;
    }
    int clen = esp_http_client_fetch_headers(client);
    if (clen < 0) {
        ESP_LOGE(TAG, "Fetch headers failed: %d", clen);
        esp_http_client_cleanup(client);
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "Status=%d Content-Length=%d",
             esp_http_client_get_status_code(client), clen);

    char *resp_buf = malloc(2048);
    if (resp_buf == NULL) {
        esp_http_client_cleanup(client);
        return ESP_ERR_NO_MEM;
    }

    int total = 0;
    int max_retries = 50;
    while (total < 2046 && max_retries-- > 0) {
        int n = esp_http_client_read(client, resp_buf + total, 2046 - total);
        if (n <= 0) {
            vTaskDelay(pdMS_TO_TICKS(10));  /* wait for more data */
            if (!esp_http_client_is_complete_data_received(client)) continue;
            break;
        }
        total += n;
    }
    esp_http_client_close(client);
    esp_http_client_cleanup(client);

    if (total <= 0) {
        ESP_LOGE(TAG, "Empty response");
        free(resp_buf);
        return ESP_FAIL;
    }
    resp_buf[total] = '\0';
    ESP_LOGI(TAG, "Response (%d bytes): %s", total, resp_buf);

    /* Parse response (OpenAI format) */
    cJSON *json = cJSON_Parse(resp_buf);
    free(resp_buf);

    if (json == NULL) return ESP_FAIL;

    cJSON *choices = cJSON_GetObjectItem(json, "choices");
    if (choices && cJSON_IsArray(choices)) {
        cJSON *choice = cJSON_GetArrayItem(choices, 0);
        if (choice) {
            cJSON *message = cJSON_GetObjectItem(choice, "message");
            if (message) {
                cJSON *content = cJSON_GetObjectItem(message, "content");
                if (content && cJSON_IsString(content)) {
                    *response_text = strdup(content->valuestring);
                }
            }
        }
    }

    cJSON_Delete(json);
    return (*response_text != NULL) ? ESP_OK : ESP_FAIL;
}
