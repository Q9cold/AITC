/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Baidu OAuth 2.0 — obtain and cache access_token.
 */

#include "baidu_auth.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "cJSON.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <string.h>
#include <stdio.h>

static const char *TAG = "baidu_auth";

#define TOKEN_URL "https://aip.baidubce.com/oauth/2.0/token"
#define TOKEN_BUF_SIZE 256

static char s_access_token[TOKEN_BUF_SIZE];
static int64_t s_token_expiry_us = 0;   /* esp_timer_get_time() when token expires */
static bool s_token_valid = false;
static SemaphoreHandle_t s_token_mutex = NULL;

esp_err_t baidu_auth_get_token(const char *api_key, const char *secret_key,
                               const char **access_token)
{
    if (api_key == NULL || secret_key == NULL || access_token == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    /* Create mutex on first call */
    if (s_token_mutex == NULL) {
        s_token_mutex = xSemaphoreCreateMutex();
        if (s_token_mutex == NULL) {
            return ESP_ERR_NO_MEM;
        }
    }

    xSemaphoreTake(s_token_mutex, portMAX_DELAY);

    /* Return cached token if still valid (with 1-hour margin) */
    int64_t now_us = esp_timer_get_time();
    if (s_token_valid && (now_us < s_token_expiry_us - 3600LL * 1000000LL)) {
        ESP_LOGD(TAG, "Using cached access token");
        *access_token = s_access_token;
        xSemaphoreGive(s_token_mutex);
        return ESP_OK;
    }

    /* Build request body */
    char body[512];
    int body_len = snprintf(body, sizeof(body),
                            "grant_type=client_credentials&client_id=%s&client_secret=%s",
                            api_key, secret_key);
    if (body_len < 0 || body_len >= sizeof(body)) {
        ESP_LOGE(TAG, "Body buffer overflow");
        xSemaphoreGive(s_token_mutex);
        return ESP_ERR_NO_MEM;
    }

    /* Configure HTTP client */
    esp_http_client_config_t http_cfg = {
        .url = TOKEN_URL,
        .method = HTTP_METHOD_POST,
        .timeout_ms = 15000,
    };
    esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
    if (client == NULL) {
        ESP_LOGE(TAG, "Failed to init HTTP client");
        xSemaphoreGive(s_token_mutex);
        return ESP_FAIL;
    }

    esp_http_client_set_header(client, "Content-Type", "application/x-www-form-urlencoded");
    esp_http_client_set_post_field(client, body, body_len);

    esp_err_t err = esp_http_client_perform(client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP request failed: %d", err);
        esp_http_client_cleanup(client);
        xSemaphoreGive(s_token_mutex);
        return err;
    }

    int status = esp_http_client_get_status_code(client);
    if (status != 200) {
        ESP_LOGE(TAG, "HTTP error: %d", status);
        esp_http_client_cleanup(client);
        xSemaphoreGive(s_token_mutex);
        return ESP_FAIL;
    }

    /* Read response body */
    char resp_buf[512];
    int resp_len = esp_http_client_read_response(client, resp_buf, sizeof(resp_buf) - 1);
    if (resp_len < 0) {
        ESP_LOGE(TAG, "Failed to read response");
        esp_http_client_cleanup(client);
        xSemaphoreGive(s_token_mutex);
        return ESP_FAIL;
    }
    resp_buf[resp_len] = '\0';
    esp_http_client_cleanup(client);

    /* Parse JSON */
    cJSON *json = cJSON_Parse(resp_buf);
    if (json == NULL) {
        ESP_LOGE(TAG, "Failed to parse response JSON: %s", resp_buf);
        xSemaphoreGive(s_token_mutex);
        return ESP_FAIL;
    }

    cJSON *token_item = cJSON_GetObjectItem(json, "access_token");
    cJSON *expires_item = cJSON_GetObjectItem(json, "expires_in");
    cJSON *error_item = cJSON_GetObjectItem(json, "error_description");

    if (error_item != NULL && cJSON_IsString(error_item)) {
        ESP_LOGE(TAG, "Auth error: %s", error_item->valuestring);
        cJSON_Delete(json);
        xSemaphoreGive(s_token_mutex);
        return ESP_FAIL;
    }

    if (token_item == NULL || !cJSON_IsString(token_item)) {
        ESP_LOGE(TAG, "No access_token in response: %s", resp_buf);
        cJSON_Delete(json);
        xSemaphoreGive(s_token_mutex);
        return ESP_FAIL;
    }

    strncpy(s_access_token, token_item->valuestring, TOKEN_BUF_SIZE - 1);
    s_access_token[TOKEN_BUF_SIZE - 1] = '\0';

    int expires_in = (expires_item != NULL && cJSON_IsNumber(expires_item))
                     ? expires_item->valueint : 2592000;

    s_token_expiry_us = now_us + (int64_t)expires_in * 1000000LL;
    s_token_valid = true;

    cJSON_Delete(json);

    ESP_LOGI(TAG, "Access token obtained, expires in %d seconds", expires_in);
    *access_token = s_access_token;
    xSemaphoreGive(s_token_mutex);
    return ESP_OK;
}
