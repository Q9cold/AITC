/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Voice Assistant — main orchestrator state machine.
 * Coordinates the full pipeline:
 *   Mic recording → ASR → LLM → TTS → Speaker playback
 */

#include "voice_assistant.h"
#include "audio_input.h"
#include "audio_output.h"
#include "cloud_asr.h"
#include "cloud_llm.h"
#include "cloud_tts.h"
#include "gpio_control.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "voice_assistant";

/* Audio parameters */
#define SAMPLE_RATE       16000
#define RECORD_DURATION_S 2
#define PCM_BUF_SIZE      (SAMPLE_RATE * RECORD_DURATION_S * sizeof(int16_t))  /* 64000 bytes */

/* GPIO pins — can be overridden via Kconfig */
#ifndef CONFIG_VA_BUTTON_GPIO
#define CONFIG_VA_BUTTON_GPIO 0
#endif
#ifndef CONFIG_VA_LED_GPIO
#define CONFIG_VA_LED_GPIO 8
#endif
#ifndef CONFIG_VA_I2S_PDM_CLK_GPIO
#define CONFIG_VA_I2S_PDM_CLK_GPIO 4
#endif
#ifndef CONFIG_VA_I2S_PDM_DATA_GPIO
#define CONFIG_VA_I2S_PDM_DATA_GPIO 5
#endif
#ifndef CONFIG_VA_I2S_BCLK_GPIO
#define CONFIG_VA_I2S_BCLK_GPIO 6
#endif
#ifndef CONFIG_VA_I2S_WS_GPIO
#define CONFIG_VA_I2S_WS_GPIO 7
#endif
#ifndef CONFIG_VA_I2S_DOUT_GPIO
#define CONFIG_VA_I2S_DOUT_GPIO 15
#endif

/* State machine context */
typedef struct {
    voice_assistant_state_t state;
    const char *api_key;
    const char *secret_key;
    TaskHandle_t task_handle;
} va_ctx_t;

static va_ctx_t s_va_ctx;

/* Error recovery — return to IDLE after delay */
static void va_error_recovery(void)
{
    gpio_control_set_led_state(LED_ERROR);
    ESP_LOGE(TAG, "Entering ERROR state, recovering in 3 seconds...");
    vTaskDelay(pdMS_TO_TICKS(3000));
    gpio_control_set_led_state(LED_IDLE);
    s_va_ctx.state = VA_STATE_IDLE;
}

/* Main orchestrator task */
static void va_task(void *arg)
{
    s_va_ctx.state = VA_STATE_IDLE;
    ESP_LOGI(TAG, "Voice assistant task started, waiting for trigger...");
    ESP_LOGI(TAG, "Free heap: %u bytes", (unsigned int)esp_get_free_heap_size());

    while (1) {
        /* Wait for trigger (task notification) */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        /* === STAGE 1: RECORDING === */
        s_va_ctx.state = VA_STATE_RECORDING;
        ESP_LOGI(TAG, "=== Stage: RECORDING ===");

        gpio_control_set_led_state(LED_RECORDING);

        /* Init audio input (microphone) */
        esp_err_t err = audio_input_init(SAMPLE_RATE,
                                         CONFIG_VA_I2S_PDM_CLK_GPIO,
                                         CONFIG_VA_I2S_PDM_DATA_GPIO);
        if (err != ESP_OK) {
            va_error_recovery();
            continue;
        }

        /* Allocate PCM buffer */
        int16_t *pcm_buf = malloc(PCM_BUF_SIZE);
        if (pcm_buf == NULL) {
            ESP_LOGE(TAG, "Failed to alloc PCM buffer (%d bytes), free heap: %u",
                     PCM_BUF_SIZE, (unsigned int)esp_get_free_heap_size());
            audio_input_deinit();
            va_error_recovery();
            continue;
        }

        /* Record audio */
        size_t free_before = (unsigned int)esp_get_free_heap_size();
        err = audio_input_record(pcm_buf, PCM_BUF_SIZE,
                                 RECORD_DURATION_S * 1000 + 1000);
        audio_input_deinit();

        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Recording failed");
            free(pcm_buf);
            va_error_recovery();
            continue;
        }
        ESP_LOGI(TAG, "Recorded %d bytes, free heap: %u → %u",
                 PCM_BUF_SIZE, (unsigned int)free_before, (unsigned int)esp_get_free_heap_size());

        /* === STAGE 2: ASR === */
        s_va_ctx.state = VA_STATE_UPLOADING_ASR;
        ESP_LOGI(TAG, "=== Stage: ASR ===");

        gpio_control_set_led_state(LED_PROCESSING);

        char *asr_text = NULL;
        err = cloud_asr_recognize(pcm_buf, PCM_BUF_SIZE,
                                  s_va_ctx.api_key, s_va_ctx.secret_key,
                                  &asr_text);
        free(pcm_buf); /* PCM buffer no longer needed */

        if (err != ESP_OK) {
            ESP_LOGE(TAG, "ASR failed");
            free(asr_text);
            va_error_recovery();
            continue;
        }

        if (asr_text == NULL || strlen(asr_text) == 0) {
            ESP_LOGW(TAG, "No speech detected, returning to idle");
            gpio_control_set_led_state(LED_IDLE);
            s_va_ctx.state = VA_STATE_IDLE;
            free(asr_text);
            continue;
        }

        ESP_LOGI(TAG, "ASR result: \"%s\", free heap: %u",
                 asr_text, (unsigned int)esp_get_free_heap_size());

        /* === STAGE 3: LLM === */
        s_va_ctx.state = VA_STATE_WAITING_LLM;
        ESP_LOGI(TAG, "=== Stage: LLM ===");

        char *llm_reply = NULL;
        err = cloud_llm_chat(asr_text,
                             s_va_ctx.api_key, s_va_ctx.secret_key,
                             &llm_reply);
        free(asr_text);

        if (err != ESP_OK || llm_reply == NULL) {
            ESP_LOGE(TAG, "LLM failed");
            free(llm_reply);
            va_error_recovery();
            continue;
        }

        ESP_LOGI(TAG, "LLM reply: \"%s\", free heap: %u",
                 llm_reply, (unsigned int)esp_get_free_heap_size());

        /* === STAGE 4: TTS + PLAYBACK === */
        s_va_ctx.state = VA_STATE_SYNTHESIZING_TTS;
        ESP_LOGI(TAG, "=== Stage: TTS ===");

        gpio_control_set_led_state(LED_PLAYING);

        /* Init audio output (speaker) */
        err = audio_output_init(SAMPLE_RATE,
                                CONFIG_VA_I2S_BCLK_GPIO,
                                CONFIG_VA_I2S_WS_GPIO,
                                CONFIG_VA_I2S_DOUT_GPIO);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Speaker init failed");
            free(llm_reply);
            audio_output_deinit();
            va_error_recovery();
            continue;
        }

        /* Synthesize and play (streaming) */
        err = cloud_tts_synthesize_and_play(llm_reply,
                                            s_va_ctx.api_key,
                                            s_va_ctx.secret_key);
        free(llm_reply);
        audio_output_deinit();

        if (err != ESP_OK) {
            ESP_LOGE(TAG, "TTS/playback failed");
            va_error_recovery();
            continue;
        }

        /* === DONE === */
        s_va_ctx.state = VA_STATE_IDLE;
        gpio_control_set_led_state(LED_IDLE);
        ESP_LOGI(TAG, "=== Cycle complete, free heap: %u ===",
                 (unsigned int)esp_get_free_heap_size());
    }
}

esp_err_t voice_assistant_init(const char *api_key, const char *secret_key)
{
    if (api_key == NULL || secret_key == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    s_va_ctx.api_key = api_key;
    s_va_ctx.secret_key = secret_key;
    s_va_ctx.state = VA_STATE_IDLE;

    /* Create the orchestrator task */
    BaseType_t ret = xTaskCreate(va_task,
                                  "va_task",
                                  8192,
                                  NULL,
                                  5,
                                  &s_va_ctx.task_handle);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create VA task");
        return ESP_ERR_NO_MEM;
    }

    ESP_LOGI(TAG, "Voice assistant initialized");
    return ESP_OK;
}

void voice_assistant_trigger(void)
{
    if (s_va_ctx.task_handle != NULL) {
        /* Only trigger if currently idle */
        if (s_va_ctx.state == VA_STATE_IDLE) {
            ESP_LOGI(TAG, "Triggering voice assistant...");
            xTaskNotifyGive(s_va_ctx.task_handle);
        } else {
            ESP_LOGW(TAG, "Voice assistant busy (state=%d), ignoring trigger",
                     s_va_ctx.state);
        }
    }
}

voice_assistant_state_t voice_assistant_get_state(void)
{
    return s_va_ctx.state;
}
