/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Voice Assistant — main orchestrator state machine.
 * Ties together all modules: audio_input → ASR → LLM → TTS → audio_output.
 */

#pragma once

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/** Voice assistant states */
typedef enum {
    VA_STATE_IDLE,
    VA_STATE_RECORDING,
    VA_STATE_UPLOADING_ASR,
    VA_STATE_WAITING_LLM,
    VA_STATE_SYNTHESIZING_TTS,
    VA_STATE_PLAYING,
    VA_STATE_ERROR
} voice_assistant_state_t;

/**
 * @brief Initialize voice assistant and start its FreeRTOS task.
 *
 * @param api_key      Baidu API Key
 * @param secret_key   Baidu Secret Key
 * @return ESP_OK on success.
 */
esp_err_t voice_assistant_init(const char *api_key, const char *secret_key);

/**
 * @brief Trigger a conversation cycle (called when button is pressed).
 */
void voice_assistant_trigger(void);

/**
 * @brief Get current state (for debugging).
 */
voice_assistant_state_t voice_assistant_get_state(void);

#ifdef __cplusplus
}
#endif
