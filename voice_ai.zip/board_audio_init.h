/*
 * Board Audio Init — ES8311 codec + I2S duplex for xr-ai-cam / ESP32-S3.
 *
 * GPIO map (matches xr-ai-cam board):
 *   I2C SDA  → GPIO 1    (ES8311 control)
 *   I2C SCL  → GPIO 2    (ES8311 control)
 *   I2S MCLK → GPIO 38   (shared clock)
 *   I2S BCLK → GPIO 14
 *   I2S WS   → GPIO 13
 *   I2S DOUT → GPIO 45   (to ES8311 DAC → speaker)
 *   I2S DIN  → GPIO 12   (from mic → ADC)
 *
 * Replaces the per-module I2S init previously in audio_output.c
 * and afe_runner.c. The ES8311 codec requires I2C initialization
 * before any audio can be heard — writing raw I2S data without the
 * codec being configured will produce no sound.
 */

#pragma once
#include "esp_err.h"
#include "driver/i2s_std.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Initialize the shared I2S duplex bus + ES8311 codec.
 * Must be called once, before any audio I/O.
 *
 * @param sample_rate  Audio sample rate (16000 Hz in our project)
 * @return ESP_OK on success
 */
esp_err_t board_audio_init(uint32_t sample_rate);

/**
 * Get the I2S TX handle (for speaker output).
 * Returns NULL if board_audio_init hasn't been called.
 */
i2s_chan_handle_t board_audio_get_tx_handle(void);

/**
 * Get the I2S RX handle (for microphone input).
 * Returns NULL if board_audio_init hasn't been called.
 */
i2s_chan_handle_t board_audio_get_rx_handle(void);

/**
 * Write PCM samples to the codec for playback.
 * @param data    16-bit mono PCM samples
 * @param samples Number of samples
 * @return ESP_OK or error
 */
esp_err_t board_audio_write(const int16_t *data, size_t samples);

/**
 * Read PCM samples from the microphone codec (ES7210).
 * @param data    Buffer for 16-bit mono PCM samples
 * @param samples Number of samples to read
 * @param timeout_ms Max wait time (use portMAX_DELAY for blocking)
 * @return Number of samples actually read, or -1 on error
 */
int board_audio_read(int16_t *data, size_t samples, uint32_t timeout_ms);

/**
 * Check if microphone input is available.
 */
bool board_audio_has_input(void);

/**
 * Enable or disable the codec output.
 */
void board_audio_enable_output(bool enable);

/**
 * Set output volume (0-100).
 */
void board_audio_set_volume(int volume);

/**
 * Deinitialize the codec and I2S bus.
 */
void board_audio_deinit(void);

#ifdef __cplusplus
}
#endif
