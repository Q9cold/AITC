/*
 * MultiNet Runner — MultiNet 6_cn command recognition wrapper.
 * Activated after wake word. Feeds audio chunks, returns pinyin results.
 */

#pragma once
#include "esp_err.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MULTINET_MAX_CMD_STR_LEN  64
#define MULTINET_TIMEOUT_DEFAULT  5000  /* ms */

typedef struct {
    char     command_str[MULTINET_MAX_CMD_STR_LEN]; /* e.g. "da kai deng guang" */
    float    confidence;                            /* 0.0 ~ 1.0 */
} multinet_result_t;

/** Initialize MultiNet, load model, register command pinyin list */
esp_err_t multinet_runner_init(const char *model_partition_label,
                               const char **command_pinyin_list,
                               int command_count,
                               uint32_t timeout_ms);

/** Feed a chunk of 16-bit mono 16kHz PCM to MultiNet */
esp_err_t multinet_runner_feed(const int16_t *pcm_data, size_t sample_count);

/** Non-blocking: check if a command was recognized.
 *  Returns ESP_OK and fills result on detection.
 *  Returns ESP_ERR_NOT_FOUND while still scanning.
 *  Returns ESP_ERR_TIMEOUT if timeout expired with no valid speech. */
esp_err_t multinet_runner_get_result(multinet_result_t *result);

/** Reset state for next recognition cycle (after wake). */
esp_err_t multinet_runner_reset(void);

#ifdef __cplusplus
}
#endif
