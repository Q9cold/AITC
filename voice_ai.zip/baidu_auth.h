/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Baidu OAuth 2.0 — obtain and cache access_token.
 * Token is valid for ~30 days. Cached and refreshed on expiry.
 */

#pragma once

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Obtain a Baidu API access_token.
 *        Uses cached token if still valid; otherwise requests a new one.
 *
 * @param api_key      Baidu Cloud API Key
 * @param secret_key   Baidu Cloud Secret Key
 * @param access_token Output: pointer to static token string (do NOT free).
 * @return ESP_OK on success.
 */
esp_err_t baidu_auth_get_token(const char *api_key, const char *secret_key,
                               const char **access_token);

#ifdef __cplusplus
}
#endif
