/*
 * WiFi SNTP Time Sync — NTP-based real-time clock via WiFi.
 * Requires WiFi STA to be connected before calling wifi_sntp_init().
 */

#pragma once
#include "esp_err.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Initialize SNTP and sync time (call after WiFi connected).
 *  Blocks up to 10s for first sync. Sets timezone to UTC+8 (Beijing). */
esp_err_t wifi_sntp_init(void);

/** Check if time has been synchronized. */
bool wifi_sntp_is_synced(void);

/** Get formatted time string (e.g. "现在是下午三点二十五分").
 *  Returns static buffer, caller must copy if needed. */
const char* wifi_sntp_get_time_string(void);

/** Get formatted date string (e.g. "今天是二零二六年六月二十三日"). */
const char* wifi_sntp_get_date_string(void);

/** Get formatted weekday string (e.g. "今天是星期一"). */
const char* wifi_sntp_get_weekday_string(void);

#ifdef __cplusplus
}
#endif
