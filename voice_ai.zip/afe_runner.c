/*
 * AFE Runner — AFE V2 + WakeNet9 wrapper for ESP32-S3.
 * Uses ESP-SR (espressif/esp-sr ^2.4.0) for offline wake word detection.
 *
 * Architecture: two FreeRTOS tasks on Core 1.
 *   Feed task: I2S standard RX → AFE ring buffer (real-time, 30ms chunks)
 *   Fetch task: AFE → WakeNet → sets wake flag on detection
 *
 * 100% LOCAL neural network inference on ESP32-S3.
 */

#include "afe_runner.h"
#include "multinet_runner.h"
#include "board_audio_init.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s_std.h"
#include "esp_afe_sr_iface.h"
#include "esp_afe_sr_models.h"
#include "model_path.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "afe_runner";

/* ─── Static state ─── */
static bool s_initialized = false;
static volatile bool s_wake_detected = false;

/* AFE handles */
static esp_afe_sr_iface_t  *s_afe_iface = NULL;
static esp_afe_sr_data_t   *s_afe_data = NULL;
static srmodel_list_t      *s_models = NULL;

/* I2S RX handle for microphone */
static i2s_chan_handle_t s_rx_handle = NULL;

/* Audio ring buffer for recent audio (passed to MultiNet after wake) */
#define RINGBUF_SAMPLES   (16000 * 3)  /* 3 seconds */
static int16_t *s_audio_ringbuf = NULL;
static volatile size_t s_ringbuf_write_idx = 0;
static size_t s_ringbuf_size = 0;

/* Feed/fetch parameters */
static int s_feed_chunksize = 0;
static int s_fetch_chunksize = 0;

/* MultiNet feed control */
static volatile bool s_multinet_enabled = false;

/* Wake callback */
static afe_wake_callback_t s_wake_callback = NULL;
static void *s_wake_ctx = NULL;

/* ─── I2S Microphone Init (Standard RX, shared with board_audio) ─── */
static esp_err_t init_i2s_mic(uint32_t sample_rate,
                               gpio_num_t bclk, gpio_num_t ws, gpio_num_t din)
{
    /* If board_audio has ES7210, use shared I2S RX handle for raw TDM reads */
    if (board_audio_has_input()) {
        s_rx_handle = board_audio_get_rx_handle();
        /* RX is already enabled by board_audio_init, just use it */
        ESP_LOGI(TAG, "I2S mic: raw TDM via shared RX (ES7210 on GPIO12)");
        return ESP_OK;
    }

    i2s_chan_handle_t rx = board_audio_get_rx_handle();
    if (rx != NULL) {
        s_rx_handle = rx;
        ESP_LOGI(TAG, "I2S mic: using shared RX");
        return ESP_OK;
    }

    /* Fallback: create a standalone RX channel on separate port */
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_MASTER);
    chan_cfg.auto_clear = true;

    esp_err_t err = i2s_new_channel(&chan_cfg, NULL, &s_rx_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_new_channel failed: %d", err);
        return err;
    }

    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(sample_rate),
        .slot_cfg = {
            .data_bit_width = I2S_DATA_BIT_WIDTH_32BIT,
            .slot_bit_width = I2S_SLOT_BIT_WIDTH_AUTO,
            .slot_mode = I2S_SLOT_MODE_MONO,
            .slot_mask = I2S_STD_SLOT_LEFT,
            .ws_width = I2S_DATA_BIT_WIDTH_32BIT,
            .ws_pol = false,
            .bit_shift = true,
            .left_align = false,
            .big_endian = false,
            .bit_order_lsb = false,
        },
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = bclk,
            .ws = ws,
            .dout = I2S_GPIO_UNUSED,
            .din = din,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv = false,
            },
        },
    };

    err = i2s_channel_init_std_mode(s_rx_handle, &std_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_channel_init_std_mode failed: %d", err);
        return err;
    }

    err = i2s_channel_enable(s_rx_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_channel_enable failed: %d", err);
        return err;
    }

    ESP_LOGI(TAG, "I2S mic initialized: %lu Hz, bclk=%d ws=%d din=%d",
             sample_rate, bclk, ws, din);
    return ESP_OK;
}

/* Convert 32-bit I2S samples (24-bit data) to 16-bit for ESP-SR */
static void convert_i2s_to_16bit(const int32_t *src, int16_t *dst, int count)
{
    for (int i = 0; i < count; i++) {
        /* INMP441: 24-bit data in MSB of 32-bit slot. Shift right by 8. */
        dst[i] = (int16_t)(src[i] >> 8);
    }
}

/* ─── Feed Task (Producer: I2S → AFE) ─── */
static void feed_task(void *arg)
{
    #define TDM_CH 1  /* ES7210 codec device already outputs 1ch mono */
    int32_t *raw_buf = malloc(s_feed_chunksize * sizeof(int32_t));
    int16_t *feed_buf = malloc(s_feed_chunksize * sizeof(int16_t));
    int16_t *tdm_buf = malloc(s_feed_chunksize * sizeof(int16_t));

    if (raw_buf == NULL || feed_buf == NULL || tdm_buf == NULL) {
        ESP_LOGE(TAG, "Feed task: malloc failed");
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "Feed task started: chunksize=%d samples", s_feed_chunksize);

    bool use_tdm = board_audio_has_input();
    TickType_t stats_tick = xTaskGetTickCount();
    int read_cnt = 0, zero_cnt = 0, feed_cnt = 0, mn_feed_cnt = 0;

    while (1) {
        int samples_read = 0;

        if (use_tdm) {
            /* ES7210: accumulate 16-bit mono PCM, feed AFE 512-sample chunks */
            static int16_t acc_buf[4096];  /* 8× AFE chunk */
            static size_t  acc_samples = 0;
            size_t bytes_read = 0;

            esp_err_t err = i2s_channel_read(s_rx_handle,
                                              tdm_buf,
                                              s_feed_chunksize * sizeof(int16_t),
                                              &bytes_read,
                                              pdMS_TO_TICKS(100));

            size_t smp = bytes_read / sizeof(int16_t);
            read_cnt++;

            if (smp == 0) {
                zero_cnt++;
                vTaskDelay(pdMS_TO_TICKS(10));
                goto stats_check;
            }

            static int dbg_done = 0;
            if (dbg_done < 3) {
                ESP_LOGI(TAG, "I2S first data: err=%d bytes=%d smp=%d val0=%d val1=%d",
                         (int)err, (int)bytes_read, (int)smp,
                         smp>0 ? tdm_buf[0] : -1, smp>1 ? tdm_buf[1] : -1);
                dbg_done++;
            }

            /* Accumulate partial reads */
            if (acc_samples + smp <= sizeof(acc_buf) / sizeof(int16_t)) {
                memcpy(acc_buf + acc_samples, tdm_buf, bytes_read);
                acc_samples += smp;
            } else {
                acc_samples = 0;  /* overflow reset */
            }

            /* Feed AFE once we have a full chunk */
            while (acc_samples >= s_feed_chunksize) {
                memcpy(feed_buf, acc_buf, s_feed_chunksize * sizeof(int16_t));
                s_afe_iface->feed(s_afe_data, feed_buf);
                feed_cnt++;

                /* Feed MultiNet with raw feed_buf (same data WakeNet gets) */
                if (s_multinet_enabled) {
                    multinet_runner_feed(feed_buf, s_feed_chunksize);
                    mn_feed_cnt++;
                }

                if (s_audio_ringbuf != NULL) {
                    for (int i = 0; i < s_feed_chunksize; i++) {
                        s_audio_ringbuf[s_ringbuf_write_idx] = feed_buf[i];
                        s_ringbuf_write_idx = (s_ringbuf_write_idx + 1) % s_ringbuf_size;
                    }
                }

                size_t remaining = acc_samples - s_feed_chunksize;
                if (remaining > 0)
                    memmove(acc_buf, acc_buf + s_feed_chunksize, remaining * sizeof(int16_t));
                acc_samples = remaining;
            }
            samples_read = 0;  /* feeds + ringbuf done inside while loop */

        stats_check:
            /* ── Per-second stats ── */
            if (xTaskGetTickCount() - stats_tick >= pdMS_TO_TICKS(1000)) {
                ESP_LOGI(TAG, "stats: read=%d zero=%d feed=%d mn=%d en=%d acc=%d",
                         read_cnt, zero_cnt, feed_cnt, mn_feed_cnt,
                         s_multinet_enabled ? 1 : 0, (int)acc_samples);
                read_cnt = zero_cnt = feed_cnt = mn_feed_cnt = 0;
                stats_tick = xTaskGetTickCount();
            }
        } else {
            size_t bytes_read = 0;
            esp_err_t err = i2s_channel_read(s_rx_handle,
                                              raw_buf,
                                              s_feed_chunksize * sizeof(int32_t),
                                              &bytes_read,
                                              portMAX_DELAY);
            if (err != ESP_OK) {
                ESP_LOGW(TAG, "I2S read error: %d", err);
                vTaskDelay(pdMS_TO_TICKS(10));
                continue;
            }
            samples_read = bytes_read / sizeof(int32_t);
            if (samples_read == 0) continue;
            convert_i2s_to_16bit(raw_buf, feed_buf, samples_read);
        }

        /* Feed to AFE (already done in TDM path above) */
        if (!use_tdm) {
            s_afe_iface->feed(s_afe_data, feed_buf);
        }

        /* Write to ring buffer for post-wake MultiNet */
        if (s_audio_ringbuf != NULL) {
            for (int i = 0; i < samples_read; i++) {
                s_audio_ringbuf[s_ringbuf_write_idx] = feed_buf[i];
                s_ringbuf_write_idx = (s_ringbuf_write_idx + 1) % s_ringbuf_size;
            }
        }
    }
}

/* ─── Fetch Task (Consumer: AFE → WakeNet + optional MultiNet feed) ─── */
static void fetch_task(void *arg)
{
    ESP_LOGI(TAG, "Fetch task started: chunksize=%d samples", s_fetch_chunksize);

    while (1) {
        afe_fetch_result_t *result = s_afe_iface->fetch(s_afe_data);
        if (result == NULL || result->ret_value < 0) {
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        /* MultiNet is now fed from feed_task (raw feed_buf), not fetch output. */

        /* Check for wake word */
        if (result->wakeup_state == WAKENET_DETECTED) {
            ESP_LOGI(TAG, "=== WAKE WORD DETECTED: index=%d ===", result->wake_word_index);
            s_wake_detected = true;

            /* Call user callback if registered */
            if (s_wake_callback != NULL) {
                s_wake_callback(s_wake_ctx);
            }
        }

        /* Yield to allow other tasks to run */
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

/* ─── Public API ─── */

esp_err_t afe_runner_init(const afe_runner_config_t *config)
{
    if (s_initialized) {
        ESP_LOGW(TAG, "Already initialized");
        return ESP_OK;
    }

    if (config == NULL) return ESP_ERR_INVALID_ARG;

    /* Load ESP-SR models from "model" partition */
    s_models = esp_srmodel_init(config->model_partition_label);
    if (s_models == NULL || s_models->num == 0) {
        ESP_LOGE(TAG, "Failed to load models from partition '%s'",
                 config->model_partition_label);
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "Loaded %d models from partition '%s'",
             s_models->num, config->model_partition_label);

    /* Get WakeNet model name */
    char *wn_name = esp_srmodel_filter(s_models, ESP_WN_PREFIX, NULL);
    if (wn_name == NULL) {
        ESP_LOGE(TAG, "No WakeNet model found");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "WakeNet model: %s", wn_name);

    /* Configure AFE */
    afe_config_t *afe_cfg = afe_config_init("M", s_models,
                                             AFE_TYPE_SR, AFE_MODE_HIGH_PERF);
    if (afe_cfg == NULL) {
        ESP_LOGE(TAG, "afe_config_init failed");
        return ESP_FAIL;
    }

    afe_cfg->aec_init = false;
    afe_cfg->vad_init = true;
    afe_cfg->wakenet_init = true;
    afe_cfg->wakenet_model_name = wn_name;
    afe_cfg->wakenet_mode = DET_MODE_2CH_95;
    afe_cfg->afe_linear_gain = 4.0f;
    afe_cfg->memory_alloc_mode = AFE_MEMORY_ALLOC_MORE_PSRAM;

    /* Create AFE instance */
    s_afe_iface = (esp_afe_sr_iface_t *)esp_afe_handle_from_config(afe_cfg);
    if (s_afe_iface == NULL) {
        ESP_LOGE(TAG, "esp_afe_handle_from_config failed");
        return ESP_FAIL;
    }

    s_afe_data = s_afe_iface->create_from_config(afe_cfg);
    if (s_afe_data == NULL) {
        ESP_LOGE(TAG, "create_from_config failed");
        return ESP_FAIL;
    }

    /* Get chunk sizes */
    s_feed_chunksize = s_afe_iface->get_feed_chunksize(s_afe_data);
    s_fetch_chunksize = s_afe_iface->get_fetch_chunksize(s_afe_data);
    ESP_LOGI(TAG, "AFE: feed_chunksize=%d, fetch_chunksize=%d",
             s_feed_chunksize, s_fetch_chunksize);

    /* Allocate audio ring buffer */
    s_ringbuf_size = RINGBUF_SAMPLES;
    s_audio_ringbuf = (int16_t *)heap_caps_malloc(
        s_ringbuf_size * sizeof(int16_t),
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (s_audio_ringbuf == NULL) {
        ESP_LOGE(TAG, "Ring buffer malloc failed");
        return ESP_ERR_NO_MEM;
    }
    memset(s_audio_ringbuf, 0, s_ringbuf_size * sizeof(int16_t));
    s_ringbuf_write_idx = 0;

    /* Save callback */
    s_wake_callback = config->on_wake;
    s_wake_ctx = config->wake_user_ctx;

    /* Init I2S microphone */
    esp_err_t err = init_i2s_mic(config->sample_rate_hz,
                                  config->mic_bclk_gpio,
                                  config->mic_ws_gpio,
                                  config->mic_din_gpio);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Mic init failed");
        return err;
    }

    /* Create feed task on Core 1 */
    BaseType_t ret = xTaskCreatePinnedToCore(feed_task, "afe_feed",
                                              4096, NULL, 5, NULL, 1);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create feed task");
        return ESP_ERR_NO_MEM;
    }

    /* Create fetch task on Core 1 */
    ret = xTaskCreatePinnedToCore(fetch_task, "afe_fetch",
                                   4096, NULL, 5, NULL, 1);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create fetch task");
        return ESP_ERR_NO_MEM;
    }

    s_initialized = true;
    s_wake_detected = false;
    ESP_LOGI(TAG, "AFE runner initialized — listening for wake word...");
    return ESP_OK;
}

bool afe_runner_is_wake_detected(void)
{
    return s_wake_detected;
}

void afe_runner_clear_wake_flag(void)
{
    s_wake_detected = false;
}

esp_err_t afe_runner_set_multinet_enabled(bool enabled)
{
    s_multinet_enabled = enabled;
    ESP_LOGD(TAG, "MultiNet feed %s", enabled ? "ON" : "OFF");
    return ESP_OK;
}

const int16_t *afe_runner_get_audio_buffer(size_t *out_sample_count)
{
    if (out_sample_count == NULL || s_audio_ringbuf == NULL) {
        return NULL;
    }
    /* Return up to the last 3 seconds of audio */
    *out_sample_count = s_ringbuf_size;
    return s_audio_ringbuf;
}

esp_err_t afe_runner_deinit(void)
{
    if (!s_initialized) return ESP_OK;

    if (s_afe_data && s_afe_iface) {
        s_afe_iface->destroy(s_afe_data);
        s_afe_data = NULL;
    }

    if (s_rx_handle && board_audio_get_rx_handle() != s_rx_handle) {
        i2s_channel_disable(s_rx_handle);
        i2s_del_channel(s_rx_handle);
    } else if (s_rx_handle) {
        i2s_channel_disable(s_rx_handle);
    }
    s_rx_handle = NULL;

    if (s_audio_ringbuf) {
        free(s_audio_ringbuf);
        s_audio_ringbuf = NULL;
    }

    s_initialized = false;
    return ESP_OK;
}
