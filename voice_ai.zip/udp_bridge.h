/**
 * @file udp_bridge.h
 * @brief UDP bridge — WiFi 极速双向通信替代 I2C/UART
 *
 * hello_esp 监听 UDP port 8887，终端发 ALERT 到 8887
 * 终端监听 UDP port 8888，hello_esp 发 CMD 到 8888
 */
#pragma once
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { UDP_ALERT_NONE = 0, UDP_ALERT_POSTURE, UDP_ALERT_PRESS, UDP_ALERT_MUSIC } udp_alert_type_t;

esp_err_t udp_bridge_init(void);
void      udp_bridge_send_cmd(const char *text);
void      udp_bridge_send_intent(int id);
int       udp_bridge_poll_alert(void);
int       udp_bridge_consume_alert(void);

#ifdef __cplusplus
}
#endif
