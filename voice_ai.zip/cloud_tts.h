/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Cloud TTS — Baidu Text-to-Speech (streaming PCM output).
 * Converts text to raw 16-bit mono PCM via HTTPS, streams directly
 * to I2S speaker to minimize memory usage.
 */

#pragma once

#include "esp_err.h"
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Synthesize speech from text and play via audio_output.
 *        Uses streaming: HTTP chunks are played as they arrive.
 *
 * @param text         Text to synthesize (Chinese, max ~2048 bytes UTF-8)
 * @param api_key      Baidu API Key
 * @param secret_key   Baidu Secret Key
 * @return ESP_OK on success.
 *
 * @note This function blocks until synthesis + playback completes.
 */
esp_err_t cloud_tts_synthesize_and_play(const char *text,
                                        const char *api_key,
                                        const char *secret_key);

#ifdef __cplusplus
}
#endif
