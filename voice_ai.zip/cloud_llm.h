/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Cloud LLM — Baidu Qianfan ERNIE Bot chat completion.
 * Sends user text and returns AI reply.
 */

#pragma once

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Send a message to ERNIE Bot and get the AI reply.
 *
 * @param user_text    Input text from ASR
 * @param api_key      Baidu API Key
 * @param secret_key   Baidu Secret Key
 * @param reply_text   Output: malloc'd AI reply text. Caller must free().
 * @return ESP_OK on success.
 */
esp_err_t cloud_llm_chat(const char *user_text,
                         const char *api_key, const char *secret_key,
                         char **reply_text);

#ifdef __cplusplus
}
#endif
