/*
 * SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 *
 * Audio Input — I2S PDM RX microphone (INMP441 / SPH0645).
 * ESP32-S3 I2S PDM RX hardware converts PDM to 16-bit PCM automatically.
 */

#include "audio_input.h"
#include "driver/i2s_pdm.h"
#include "driver/i2s_common.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "audio_input";

static i2s_chan_handle_t s_rx_handle = NULL;

esp_err_t audio_input_init(uint32_t sample_rate_hz,
                           gpio_num_t clk_gpio,
                           gpio_num_t din_gpio)
{
    if (s_rx_handle != NULL) {
        ESP_LOGW(TAG, "Already initialized, deinit first");
        audio_input_deinit();
    }

    ESP_LOGI(TAG, "Init I2S PDM RX: rate=%lu Hz, clk=GPIO%d, din=GPIO%d",
             sample_rate_hz, clk_gpio, din_gpio);

    /* Allocate I2S channel — RX only, I2S_NUM_0, Master */
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    chan_cfg.auto_clear = true; /* Auto-clear DMA on half-full */
    esp_err_t err = i2s_new_channel(&chan_cfg, NULL, &s_rx_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_new_channel failed: %d", err);
        return err;
    }

    /* Combined PDM RX configuration (clock + slot + GPIO) */
    i2s_pdm_rx_config_t pdm_cfg = {
        .clk_cfg = I2S_PDM_RX_CLK_DEFAULT_CONFIG(sample_rate_hz),
        .slot_cfg = {
            .data_bit_width = I2S_DATA_BIT_WIDTH_16BIT,
            .slot_bit_width = I2S_SLOT_BIT_WIDTH_AUTO,
            .slot_mode = I2S_SLOT_MODE_MONO,
            .slot_mask = I2S_PDM_SLOT_LEFT,
        },
        .gpio_cfg = {
            .clk = clk_gpio,
            .din = din_gpio,
            .invert_flags = {
                .clk_inv = false,
            },
        },
    };

    /* Init PDM RX mode */
    err = i2s_channel_init_pdm_rx_mode(s_rx_handle, &pdm_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_channel_init_pdm_rx_mode failed: %d", err);
        i2s_del_channel(s_rx_handle);
        s_rx_handle = NULL;
        return err;
    }

    /* Enable channel */
    err = i2s_channel_enable(s_rx_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_channel_enable failed: %d", err);
        i2s_del_channel(s_rx_handle);
        s_rx_handle = NULL;
        return err;
    }

    ESP_LOGI(TAG, "I2S PDM RX initialized");
    return ESP_OK;
}

esp_err_t audio_input_record(int16_t *buffer, size_t buf_size, uint32_t timeout_ms)
{
    if (s_rx_handle == NULL) {
        ESP_LOGE(TAG, "Not initialized");
        return ESP_ERR_INVALID_STATE;
    }
    if (buffer == NULL || buf_size == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    size_t bytes_read = 0;
    size_t total_read = 0;
    uint32_t elapsed_ms = 0;
    TickType_t start_ticks = xTaskGetTickCount();

    ESP_LOGI(TAG, "Recording started, buf_size=%u bytes", buf_size);

    /* Read in a loop until buffer is full or timeout */
    while (total_read < buf_size) {
        size_t remaining = buf_size - total_read;
        uint32_t chunk_timeout = pdMS_TO_TICKS(100); /* 100ms per chunk */

        esp_err_t err = i2s_channel_read(s_rx_handle,
                                         (uint8_t *)buffer + total_read,
                                         remaining,
                                         &bytes_read,
                                         chunk_timeout);
        if (err == ESP_ERR_TIMEOUT) {
            /* Check global timeout */
            elapsed_ms = (uint32_t)((xTaskGetTickCount() - start_ticks) * portTICK_PERIOD_MS);
            if (elapsed_ms >= timeout_ms) {
                ESP_LOGW(TAG, "Recording timeout after %lu ms", elapsed_ms);
                break;
            }
            continue;
        } else if (err != ESP_OK) {
            ESP_LOGE(TAG, "i2s_channel_read error: %d", err);
            return err;
        }

        total_read += bytes_read;

        /* Check global timeout */
        elapsed_ms = (uint32_t)((xTaskGetTickCount() - start_ticks) * portTICK_PERIOD_MS);
        if (elapsed_ms >= timeout_ms) {
            ESP_LOGW(TAG, "Recording timeout after %lu ms", elapsed_ms);
            break;
        }
    }

    ESP_LOGI(TAG, "Recording done: %u bytes in %lu ms", total_read, elapsed_ms);
    return ESP_OK;
}

esp_err_t audio_input_deinit(void)
{
    if (s_rx_handle == NULL) {
        return ESP_OK;
    }

    i2s_channel_disable(s_rx_handle);
    i2s_del_channel(s_rx_handle);
    s_rx_handle = NULL;

    ESP_LOGI(TAG, "I2S PDM RX deinitialized");
    return ESP_OK;
}
