/**
 * @file app_udp_score_press.c
 * @brief PressPosture 端 — UDP 发送坐姿评分
 *
 * 不依赖终端头文件，裸发送原始字节。
 *   9 floats → 36 字节
 *   alert   →  1 字节 (0/1)
 */
#include "app_udp_score_press.h"
#include "esp_log.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "udp_press";
static int  s_sock = -1;
static char s_term_ip[32] = {0};

void udp_score_press_init(const char *term_ip)
{
    if (!term_ip || !term_ip[0]) {
        ESP_LOGE(TAG, "need terminal IP");
        return;
    }
    strncpy(s_term_ip, term_ip, sizeof(s_term_ip) - 1);

    s_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (s_sock < 0) {
        ESP_LOGE(TAG, "socket fail");
        return;
    }
    ESP_LOGI(TAG, "ready -> %s:%d", s_term_ip, TERM_PORT);
}

void udp_score_press_send_scores(const float *scores)
{
    if (s_sock < 0 || !scores || !s_term_ip[0]) return;

    struct sockaddr_in dest = {
        .sin_family = AF_INET,
        .sin_port   = htons(TERM_PORT),
    };
    inet_aton(s_term_ip, &dest.sin_addr);

    int n = sendto(s_sock, scores, 9 * sizeof(float), 0,
                   (struct sockaddr *)&dest, sizeof(dest));
    if (n < 0) ESP_LOGW(TAG, "send scores err: %d", n);
}

void udp_score_press_send_alert(bool is_bad)
{
    if (s_sock < 0 || !s_term_ip[0]) return;

    struct sockaddr_in dest = {
        .sin_family = AF_INET,
        .sin_port   = htons(TERM_PORT),
    };
    inet_aton(s_term_ip, &dest.sin_addr);

    uint8_t val = is_bad ? 1 : 0;
    sendto(s_sock, &val, 1, 0,
           (struct sockaddr *)&dest, sizeof(dest));
}