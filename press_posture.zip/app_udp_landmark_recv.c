#include "app_udp_landmark_recv.h"
#include "esp_log.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include <string.h>

static const char *TAG = "udp_landmark_recv";

static struct {
    float      landmarks[FACIAL_LANDMARKS_COUNT];
    uint32_t   tick;
    bool       valid;
    SemaphoreHandle_t mutex;
} s_recv = { .valid = false, .mutex = NULL };

static void udp_recv_task(void *arg)
{
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        ESP_LOGE(TAG, "socket fail");
        vTaskDelete(NULL);
        return;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port   = htons(LANDMARK_PORT),
        .sin_addr.s_addr = htonl(INADDR_ANY),
    };
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        ESP_LOGE(TAG, "bind fail");
        close(sock);
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "listening on port %d", LANDMARK_PORT);

    while (1) {
        float buf[FACIAL_LANDMARKS_COUNT];
        int n = recvfrom(sock, buf, sizeof(buf), 0, NULL, NULL);
        if (n == (int)sizeof(buf)) {
            if (xSemaphoreTake(s_recv.mutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                memcpy(s_recv.landmarks, buf, sizeof(buf));
                s_recv.tick = xTaskGetTickCount();
                s_recv.valid = true;
                xSemaphoreGive(s_recv.mutex);
            }
        }
    }
}

void udp_landmark_recv_init(void)
{
    s_recv.mutex = xSemaphoreCreateMutex();
    xTaskCreate(udp_recv_task, "udp_recv", 4096, NULL, 5, NULL);
}

bool udp_landmark_recv_get(float *landmarks, uint32_t *tick)
{
    if (!landmarks || !s_recv.mutex) return false;

    bool valid = false;
    if (xSemaphoreTake(s_recv.mutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        if (s_recv.valid) {
            memcpy(landmarks, s_recv.landmarks, FACIAL_LANDMARKS_COUNT * sizeof(float));
            if (tick) *tick = s_recv.tick;
            valid = true;
        }
        xSemaphoreGive(s_recv.mutex);
    }
    return valid;
}