/**
 * @file posture_inference.cpp
 * @brief TFLite INT8 量化推理实现
 *
 * 流程：
 *   1. 标准化 (StandardScaler / RobustScaler)
 *   2. 量化 float→int8:  int8 = round(float / scale) + zero_point
 *   3. 推理
 *   4. 反量化 int8→float: float = (int8 - zero_point) * scale
 *   5. 放大到 0-100 范围
 */

#include "posture_inference.h"
#include "model_data.h"
#include "scaler_params.h"

#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/kernels/micro_ops.h"
#include "tensorflow/lite/schema/schema_generated.h"

#include "esp_log.h"
#include <string.h>
#include <math.h>

static const char *TAG = "posture_infer";

static const float kVisInputScale   = 0.018494943156838417f;
static const int   kVisInputZp      = 68;
static const float kPressInputScale = 12.2072114944458f;
static const int   kPressInputZp    = -128;
static const float kOutputScale     = 0.00390625f;
static const int   kOutputZp        = -128;

#define TENSOR_ARENA_SIZE  (64 * 1024)
static uint8_t g_tensor_arena[TENSOR_ARENA_SIZE] __attribute__((aligned(16)));

static tflite::MicroInterpreter *g_interpreter = nullptr;
static TfLiteTensor *g_input_vis       = nullptr;
static TfLiteTensor *g_input_press     = nullptr;
static TfLiteTensor *g_outputs[POSTURE_SCORE_COUNT];

bool posture_inference_init(void)
{
    ESP_LOGI(TAG, "Loading TFLite model (%u bytes)...", g_model_data_len);

    const tflite::Model *model = tflite::GetModel(g_model_data);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        ESP_LOGE(TAG, "Model schema version mismatch: got %d, expected %d",
                 model->version(), TFLITE_SCHEMA_VERSION);
        return false;
    }

    static tflite::MicroMutableOpResolver<20> resolver;
    resolver.AddFullyConnected();
    resolver.AddRelu();
    resolver.AddRelu6();
    resolver.AddConcatenation();
    resolver.AddReshape();
    resolver.AddSoftmax();
    resolver.AddAdd();
    resolver.AddMul();
    resolver.AddTanh();
    resolver.AddLogistic();
    resolver.AddQuantize();
    resolver.AddDequantize();
    resolver.AddExpandDims();
    resolver.AddSqueeze();
    resolver.AddPack();
    resolver.AddUnpack();
    resolver.AddMean();
    resolver.AddStridedSlice();
    resolver.AddPad();
    resolver.AddTranspose();
    static tflite::MicroInterpreter static_interpreter(
        model, resolver, g_tensor_arena, TENSOR_ARENA_SIZE);

    g_interpreter = &static_interpreter;

    if (g_interpreter->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "Failed to allocate tensors");
        return false;
    }

    g_input_vis   = g_interpreter->input(0);
    g_input_press = g_interpreter->input(1);

    for (int i = 0; i < POSTURE_SCORE_COUNT; i++) {
        g_outputs[i] = g_interpreter->output(i);
    }

    ESP_LOGI(TAG, "TFLite initialized. Arena used: %d bytes",
             g_interpreter->arena_used_bytes());
    return true;
}

static inline float safe_div(float a, float b)
{
    if (fabsf(b) < 1e-8f) return 0.0f;
    return a / b;
}

static inline int8_t float_to_int8(float val, float scale, int zp)
{
    float q = roundf(val / scale) + (float)zp;
    if (q > 127.0f)  return 127;
    if (q < -128.0f) return -128;
    return (int8_t)q;
}

static inline float int8_to_float(int8_t val, float scale, int zp)
{
    return ((float)(val - zp)) * scale;
}

bool posture_inference_run(const float *vis_raw, const float *press_raw, float *scores_out)
{
    if (!g_interpreter || !vis_raw || !press_raw || !scores_out) {
        return false;
    }

    int8_t *vis_data = g_input_vis->data.int8;
    for (int i = 0; i < POSTURE_VIS_DIM; i++) {
        float std_val = safe_div(vis_raw[i] - g_vis_scaler_mean[i], g_vis_scaler_scale[i]);
        vis_data[i] = float_to_int8(std_val, kVisInputScale, kVisInputZp);
    }

    int8_t *press_data = g_input_press->data.int8;
    for (int i = 0; i < POSTURE_PRESS_DIM; i++) {
        float std_val = safe_div(press_raw[i] - g_press_scaler_center[i], g_press_scaler_scale[i]);
        press_data[i] = float_to_int8(std_val, kPressInputScale, kPressInputZp);
    }

    if (g_interpreter->Invoke() != kTfLiteOk) {
        ESP_LOGE(TAG, "Inference failed");
        return false;
    }

    for (int i = 0; i < POSTURE_SCORE_COUNT; i++) {
        int8_t val = g_outputs[i]->data.int8[0];
        float score = int8_to_float(val, kOutputScale, kOutputZp);
        scores_out[i] = score * 100.0f;
    }

    return true;
}