#pragma once
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LANDMARK_PORT      8890
#define FACIAL_LANDMARKS_COUNT 15

void udp_landmark_recv_init(void);
bool udp_landmark_recv_get(float *landmarks, uint32_t *tick);

#ifdef __cplusplus
}
#endif