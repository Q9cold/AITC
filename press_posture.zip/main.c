/**
 * @file main.c
 * @brief Press ESP32-S3 多模态坐姿评分固件
 *
 * 架构：
 *   - UART 接收压力传感器 M1616 协议数据（16×16 矩阵）
 *   - UDP 接收 Camera ESP32-S3 发来的面部关键点坐标
 *   - UDP 发送坐姿评分给 PostureTerminal 屏幕
 *   - TFLite INT8 模型推理，输出 9 维坐姿评分
 *   - 时间同步：压力/视觉帧均带 FreeRTOS tick，推理前检查 ±100ms 窗口
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "lwip/inet.h"

#include "app_udp_score_press.h"
#include "app_udp_landmark_recv.h"
#include "posture_inference.h"

// =========================
// WiFi 配置
// =========================
#define WIFI_SSID      "what"
#define WIFI_PASSWORD  "200506080612"
#define PRESS_IP       "10.45.232.45"
#define PRESS_GATEWAY  "10.45.232.1"
#define PRESS_NETMASK  "255.255.255.0"
#define TERMINAL_IP    "10.45.232.92"   // PostureTerminal 的 IP 地址

// =========================
// UART 配置
// =========================
#define SENSOR_UART        UART_NUM_1
#define SENSOR_RX_PIN      19
#define SENSOR_TX_PIN      20
#define SENSOR_BAUD        115200
#define BUF_SIZE           1024

// =========================
// M1616 协议
// =========================
#define HEADER_1           0xAA
#define HEADER_2           0xAB
#define HEADER_3           0xAC
#define DATA_LEN           512
#define FRAME_SIZE         (DATA_LEN + 3)

// M1616 数据为 16×16 矩阵，每个单元格 2 字节（大端 uint16）
#define PRESSURE_ROWS      16
#define PRESSURE_COLS      16
#define PRESSURE_VALUES    (PRESSURE_ROWS * PRESSURE_COLS)

// =========================
// 推理间隔（ms）
// =========================
#define INFERENCE_INTERVAL_MS  200

// =========================
// 时间同步窗口（tick）
// =========================
#define SYNC_WINDOW_MS         100
#define SYNC_WINDOW_TICKS      pdMS_TO_TICKS(SYNC_WINDOW_MS)

// =========================
// 坐姿评分阈值
// =========================
#define BAD_POSTURE_THRESHOLD  40.0f

static const char *TAG = "press_main";

// 评分名称
static const char *score_names[POSTURE_SCORE_COUNT] = {
    "forward_lean", "backward_lean", "lateral_lean",
    "head_twist", "pressure_balance", "pressure_center",
    "pressure_uniformity", "posture_stability", "health_score"
};

// 压力帧（16×16 float 矩阵 + 时间戳）
typedef struct {
    float      values[PRESSURE_VALUES];
    TickType_t tick;
} pressure_frame_t;

// UART → 主任务 队列
static QueueHandle_t g_pressure_queue = NULL;

// =========================
// M1616 字节解析状态机
// =========================
typedef enum {
    STATE_FIND_H1,
    STATE_FIND_H2,
    STATE_FIND_H3,
    STATE_READ_DATA
} parse_state_t;

static void parse_byte(uint8_t b)
{
    static parse_state_t st = STATE_FIND_H1;
    static uint8_t buf[DATA_LEN];
    static uint16_t idx = 0;

    switch (st) {
    case STATE_FIND_H1:
        if (b == HEADER_1) st = STATE_FIND_H2;
        break;

    case STATE_FIND_H2:
        if (b == HEADER_2) st = STATE_FIND_H3;
        else if (b == HEADER_1) st = STATE_FIND_H2;
        else st = STATE_FIND_H1;
        break;

    case STATE_FIND_H3:
        if (b == HEADER_3) {
            st = STATE_READ_DATA;
            idx = 0;
        } else {
            st = STATE_FIND_H1;
        }
        break;

    case STATE_READ_DATA:
        buf[idx++] = b;
        if (idx >= DATA_LEN) {
            // 512 字节 → 256 个 uint16（大端）→ float
            pressure_frame_t frame;
            for (int i = 0; i < PRESSURE_VALUES; i++) {
                uint16_t raw = ((uint16_t)buf[i * 2] << 8) | buf[i * 2 + 1];
                frame.values[i] = (float)raw;
            }
            frame.tick = xTaskGetTickCount();

            // 发送到主任务队列（非阻塞，丢弃旧帧）
            xQueueOverwrite(g_pressure_queue, &frame);

            static int press_frame_count = 0;
            press_frame_count++;
            if (press_frame_count == 1) {
                ESP_LOGI(TAG, "First pressure frame received! Sensor is working.");
            } else if (press_frame_count % 25 == 0) {
                ESP_LOGI(TAG, "Pressure frame #%d received (tick=%lu)",
                         press_frame_count, (unsigned long)frame.tick);
            }

            st = STATE_FIND_H1;
            idx = 0;
        }
        break;
    }
}

// =========================
// UART 接收任务
// =========================
static void uart_task(void *arg)
{
    uint8_t *buf = (uint8_t *)malloc(BUF_SIZE);
    if (!buf) {
        ESP_LOGE(TAG, "Failed to allocate UART buffer");
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "UART task started, waiting for pressure sensor data...");

    while (1) {
        int len = uart_read_bytes(SENSOR_UART, buf, BUF_SIZE, pdMS_TO_TICKS(100));
        if (len > 0) {
            for (int i = 0; i < len; i++) {
                parse_byte(buf[i]);
            }
        }
    }
}

// =========================
// 获取压力数据（含时间戳）
// =========================
static bool get_pressure_frame(pressure_frame_t *frame)
{
    if (!g_pressure_queue || !frame) return false;
    return xQueueReceive(g_pressure_queue, frame, 0) == pdTRUE;
}

// =========================
// 判断是否坐姿不良
// =========================
static bool is_bad_posture(const float *scores)
{
    for (int i = 0; i < POSTURE_SCORE_COUNT; i++) {
        if (scores[i] < BAD_POSTURE_THRESHOLD) {
            return true;
        }
    }
    return false;
}

// =========================
// 检查时间戳是否在同步窗口内
// =========================
static bool timestamps_synced(TickType_t tick_a, TickType_t tick_b)
{
    TickType_t diff;
    if (tick_a >= tick_b) {
        diff = tick_a - tick_b;
    } else {
        diff = tick_b - tick_a;
    }
    return diff <= SYNC_WINDOW_TICKS;
}

// =========================
// 主任务：推理循环
// =========================
static void inference_task(void *arg)
{
    pressure_frame_t press_frame;
    float vis_landmarks[FACIAL_LANDMARKS_COUNT];
    float scores[POSTURE_SCORE_COUNT];
    bool  last_alert = false;
    int   inference_count = 0;
    int   sync_miss_count = 0;

    ESP_LOGI(TAG, "Inference task started");

    while (1) {
        // 获取压力数据（含时间戳）
        bool has_pressure = get_pressure_frame(&press_frame);

        // 获取视觉数据（含时间戳）
        uint32_t vis_tick = 0;
        bool has_vis = udp_landmark_recv_get(vis_landmarks, &vis_tick);

        if (has_pressure && has_vis) {
            // 时间同步检查：不同步时降级推理（用最新视觉数据+当前压力数据）
            bool synced = timestamps_synced(press_frame.tick, vis_tick);
            if (!synced) {
                sync_miss_count++;
                if (sync_miss_count % 50 == 0) {
                    ESP_LOGW(TAG, "Timestamp sync miss: press_tick=%lu, vis_tick=%lu, "
                             "diff=%lu ms (count=%d) - using latest visual data",
                             (unsigned long)press_frame.tick,
                             (unsigned long)vis_tick,
                             (unsigned long)((press_frame.tick > vis_tick)
                                 ? ((press_frame.tick - vis_tick) * portTICK_PERIOD_MS)
                                 : ((vis_tick - press_frame.tick) * portTICK_PERIOD_MS)),
                             sync_miss_count);
                }
            }

            // 运行推理
            if (posture_inference_run(vis_landmarks, press_frame.values, scores)) {
                inference_count++;

                // 每 10 次推理打印一次评分
                if (inference_count % 10 == 0) {
                    ESP_LOGI(TAG, "=== Posture Scores #%d (tick=%lu) ===",
                             inference_count, (unsigned long)press_frame.tick);
                    for (int i = 0; i < POSTURE_SCORE_COUNT; i++) {
                        ESP_LOGI(TAG, "  %-20s: %5.1f", score_names[i], scores[i]);
                    }
                }

                // 通过 UDP 发送 9 维评分给 PostureTerminal
                udp_score_press_send_scores(scores);

                // 坐姿告警（带防抖：连续 3 次不良才发送）
                bool bad = is_bad_posture(scores);
                if (bad && !last_alert) {
                    ESP_LOGW(TAG, "Bad posture detected! (health_score=%.1f)", scores[SCORE_HEALTH_SCORE]);
                } else if (!bad && last_alert) {
                    ESP_LOGI(TAG, "Posture recovered (health_score=%.1f)", scores[SCORE_HEALTH_SCORE]);
                }
                last_alert = bad;
            }
        } else {
            // 定期打印数据就绪状态，方便调试
            static int status_cycle = 0;
            if (status_cycle % 10 == 0) {
                ESP_LOGI(TAG, "Data status: pressure=%d, visual=%d, udp_ready=%d",
                         has_pressure, has_vis, 1);
            }
            status_cycle++;
        }

        vTaskDelay(pdMS_TO_TICKS(INFERENCE_INTERVAL_MS));
    }
}

// =========================
// WiFi 初始化
// =========================
static void wifi_event_handler(void *arg, esp_event_base_t base,
                                int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "WiFi connected, IP: " IPSTR, IP2STR(&event->ip_info.ip));
        esp_wifi_set_ps(WIFI_PS_NONE);  // 关闭省电，WiFi/BLE 共存时避免抢 radio
        udp_score_press_init(TERMINAL_IP);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "WiFi disconnected, reconnecting...");
        esp_wifi_connect();
    }
}

static void wifi_init(void)
{
    esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP,
                                                &wifi_event_handler, NULL));

    wifi_config_t wifi_cfg = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASSWORD,
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    esp_netif_ip_info_t ip_info = {0};
    inet_aton(PRESS_IP, &ip_info.ip);
    inet_aton(PRESS_GATEWAY, &ip_info.gw);
    inet_aton(PRESS_NETMASK, &ip_info.netmask);
    ESP_ERROR_CHECK(esp_netif_dhcpc_stop(sta_netif));
    ESP_ERROR_CHECK(esp_netif_set_ip_info(sta_netif, &ip_info));
    ESP_LOGI(TAG, "Static IP: " IPSTR, IP2STR(&ip_info.ip));
}

// =========================
// 主入口
// =========================
void app_main(void)
{
    ESP_LOGI(TAG, "Press ESP32-S3 initialize...");

    // NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }

    // 网络栈初始化（必须在 BLE 和 WiFi 之前）
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // 压力帧队列
    g_pressure_queue = xQueueCreate(1, sizeof(pressure_frame_t));
    if (!g_pressure_queue) {
        ESP_LOGE(TAG, "Failed to create pressure queue");
        return;
    }

    // UART
    uart_config_t uart_cfg = {
        .baud_rate = SENSOR_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT
    };
    ESP_ERROR_CHECK(uart_driver_install(SENSOR_UART, BUF_SIZE * 2, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(SENSOR_UART, &uart_cfg));
    ESP_ERROR_CHECK(uart_set_pin(SENSOR_UART, SENSOR_TX_PIN, SENSOR_RX_PIN,
                                  UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    xTaskCreate(uart_task, "uart_task", 4096, NULL, 10, NULL);

    // UDP 接收面部关键点（来自 PostureCam）
    udp_landmark_recv_init();

    // WiFi + UDP 发送评分给 PostureTerminal
    wifi_init();

    // TFLite 推理引擎
    if (!posture_inference_init()) {
        ESP_LOGE(TAG, "Failed to initialize TFLite inference engine");
        return;
    }

    ESP_LOGI(TAG, "Press ESP32-S3 multimodal posture system ready");
    ESP_LOGI(TAG, "  - UART:  pressure sensor (M1616, 16x16)");
    ESP_LOGI(TAG, "  - UDP:   facial landmarks from PostureCam (port %d)", LANDMARK_PORT);
    ESP_LOGI(TAG, "  - UDP:   posture scores to PostureTerminal (%s:%d)", TERMINAL_IP, TERM_PORT);
    ESP_LOGI(TAG, "  - Model: TFLite INT8 quantized");
    ESP_LOGI(TAG, "  - Sync:  %d ms window (FreeRTOS tick)", SYNC_WINDOW_MS);

    // 推理任务
    xTaskCreate(inference_task, "inference", 8192, NULL, 5, NULL);
}