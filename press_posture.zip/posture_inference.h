/**
 * @file posture_inference.h
 * @brief 多模态坐姿评分 TFLite 推理（INT8 量化模型）
 *
 * 输入：
 *   - 视觉特征 (15 float): 面部关键点 3D 坐标，标准化后量化
 *   - 压力特征 (256 float): 压力传感器 16×16 矩阵，标准化后量化
 * 输出：9 维坐姿评分 (0-100)
 */

#pragma once
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define POSTURE_VIS_DIM       15
#define POSTURE_PRESS_DIM     256
#define POSTURE_SCORE_COUNT   9

enum {
    SCORE_FORWARD_LEAN      = 0,
    SCORE_BACKWARD_LEAN     = 1,
    SCORE_LATERAL_LEAN      = 2,
    SCORE_HEAD_TWIST        = 3,
    SCORE_PRESSURE_BALANCE  = 4,
    SCORE_PRESSURE_CENTER   = 5,
    SCORE_PRESSURE_UNIFORM  = 6,
    SCORE_POSTURE_STABILITY = 7,
    SCORE_HEALTH_SCORE      = 8,
};

/**
 * @brief 初始化 TFLite 推理引擎
 * @return true 成功
 */
bool posture_inference_init(void);

/**
 * @brief 执行推理
 * @param vis_raw       15 维原始视觉特征（未标准化）
 * @param press_raw     256 维原始压力数据（未标准化）
 * @param scores_out    9 维评分输出 (0-100)
 * @return true 推理成功
 */
bool posture_inference_run(const float *vis_raw, const float *press_raw, float *scores_out);

#ifdef __cplusplus
}
#endif