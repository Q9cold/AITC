/**
 * @file app_udp_score_press.h
 * @brief PressPosture 端 — UDP 发送坐姿评分给 PostureTerminal
 *
 * 使用方法：
 *   1. 把 .h / .c 复制到 PressPosture 项目的 main/ 目录
 *   2. 在 CMakeLists.txt 添加 "app_udp_score_press.c"
 *   3. 在 app_main() 调用 udp_score_press_init()
 *   4. 在评分计算完成后调用 udp_score_press_send_scores(scores)
 *   5. TERM_PORT 和终端 app_udp_score.c 里的 SCORE_PORT 保持一致
 */
#pragma once
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// clang-format off
#define TERM_PORT 8889          // ← 与终端 SCORE_PORT 一致
// clang-format on

void udp_score_press_init(const char *term_ip);
void udp_score_press_send_scores(const float *scores);   // 9 floats, 36 bytes
void udp_score_press_send_alert(bool is_bad);

#ifdef __cplusplus
}
#endif